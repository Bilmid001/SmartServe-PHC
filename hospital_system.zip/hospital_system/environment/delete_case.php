<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $pdo->prepare("DELETE FROM environment_cases WHERE id = ?");
        $stmt->execute([$id]);
    }
}

header("Location: cases_list.php"); // or whatever your cases list filename is
exit;
