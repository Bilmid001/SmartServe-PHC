<?php
// doctor/edit_consultation.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

// Validate and sanitize incoming ID
$id = $_GET['id'] ?? 0;
$id = is_numeric($id) ? (int)$id : 0;

if ($id <= 0) {
    die("❌ Invalid consultation ID.");
}

// Test DB connection (will throw error if problem)
try {
    $pdo->query("SELECT 1");
} catch (Exception $e) {
    die("❌ DB connection error: " . $e->getMessage());
}

// Fetch consultation with LEFT JOIN to include patient info if available
$stmt = $pdo->prepare("
    SELECT c.*, p.fullname, p.phone, p.gender, p.dob
    FROM consultations c
    LEFT JOIN patients p ON c.patient_id = p.id
    WHERE c.id = :id
");
$stmt->execute([':id' => $id]);
$consultation = $stmt->fetch(PDO::FETCH_ASSOC);

// DEBUG OUTPUT if consultation not found
if (!$consultation) {
    echo "<pre style='background:#ffe0e0; padding:15px; border:1px solid red;'>";
    echo "❌ DEBUG: No consultation found.\n";
    echo "Used ID: " . htmlspecialchars($id) . "\n";

    // Count total consultations in DB
    $totalConsultations = $pdo->query("SELECT COUNT(*) FROM consultations")->fetchColumn();
    echo "Total consultations in DB: $totalConsultations\n";

    // Check if any consultations with this ID exist without join
    $checkStmt = $pdo->prepare("SELECT * FROM consultations WHERE id = :id");
    $checkStmt->execute([':id' => $id]);
    $rawConsult = $checkStmt->fetch(PDO::FETCH_ASSOC);
    echo "Consultation exists without join? " . ($rawConsult ? "YES" : "NO") . "\n";

    echo "</pre>";
    die("❌ Consultation not found with ID: " . htmlspecialchars($id));
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $diagnosis = trim($_POST['diagnosis'] ?? '');
    $treatment = trim($_POST['treatment'] ?? '');
    $status    = $_POST['status'] ?? 'pending';

    $stmt = $pdo->prepare("
        UPDATE consultations 
        SET diagnosis = :diagnosis, treatment = :treatment, status = :status, updated_at = NOW()
        WHERE id = :id
    ");
    if ($stmt->execute([
        ':diagnosis' => $diagnosis,
        ':treatment' => $treatment,
        ':status'    => $status,
        ':id'        => $id
    ])) {
        $message = "<div class='alert alert-success'>✅ Consultation updated successfully.</div>";
        // Refresh consultation data after update
        $stmt = $pdo->prepare("
            SELECT c.*, p.fullname, p.phone, p.gender, p.dob
            FROM consultations c
            LEFT JOIN patients p ON c.patient_id = p.id
            WHERE c.id = :id
        ");
        $stmt->execute([':id' => $id]);
        $consultation = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        $message = "<div class='alert alert-danger'>❌ Failed to update consultation.</div>";
    }
}

$page_title = "Edit Consultation";
include __DIR__ . '/../includes/header.php';
?>

<div class="container">
  <h2 class="mb-4">Edit Consultation</h2>
  <?= $message ?>

  <div class="card mb-3">
    <div class="card-body">
      <?php if ($consultation['fullname']): ?>
        <h5>Patient: <?= htmlspecialchars($consultation['fullname']) ?> (<?= htmlspecialchars($consultation['phone']) ?>)</h5>
        <p>Gender: <?= htmlspecialchars($consultation['gender']) ?> | DOB: <?= htmlspecialchars($consultation['dob']) ?></p>
      <?php else: ?>
        <div class="alert alert-warning">⚠️ Patient record is missing or deleted.</div>
      <?php endif; ?>
    </div>
  </div>

  <form method="post">
    <div class="mb-3">
      <label class="form-label">Reason for Visit</label>
      <input type="text" class="form-control" value="<?= htmlspecialchars($consultation['notes']) ?>" disabled>
    </div>
    <div class="mb-3">
      <label class="form-label">Diagnosis</label>
      <textarea name="diagnosis" class="form-control" rows="3"><?= htmlspecialchars($consultation['diagnosis']) ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Treatment Plan</label>
      <textarea name="treatment" class="form-control" rows="3"><?= htmlspecialchars($consultation['treatment']) ?></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="pending" <?= $consultation['status']=='pending'?'selected':'' ?>>Pending</option>
        <option value="completed" <?= $consultation['status']=='completed'?'selected':'' ?>>Completed</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Update Consultation</button>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
