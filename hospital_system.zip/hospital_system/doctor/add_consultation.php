<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$page_title = "Add Consultation";
include __DIR__ . '/../includes/header.php';

$message = "";
$patient = null;

// Handle search patient
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $stmt = $pdo->prepare("SELECT * FROM patients WHERE id = :search_id OR phone = :search_phone LIMIT 1");
    $stmt->execute([':search_id' => $search, ':search_phone' => $search]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$patient) {
        $message = "<div class='alert alert-danger'>❌ Patient not found.</div>";
    }
}

// Handle add consultation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'] ?? null;
    $doctor_id  = $_SESSION['user_id'] ?? null;
    $diagnosis  = trim($_POST['diagnosis'] ?? '');
    $notes      = trim($_POST['notes'] ?? '');
    $treatment  = trim($_POST['treatment'] ?? '');
    $status     = $_POST['status'] ?? 'pending';

    if ($patient_id && $doctor_id && $diagnosis) {
        try {
            $pdo->beginTransaction();

            // 1. Create a visit for this patient and doctor
            $visitSql = "INSERT INTO visits (patient_id, doctor_id, created_at) VALUES (:patient_id, :doctor_id, NOW())";
            $visitStmt = $pdo->prepare($visitSql);
            $visitStmt->execute([
                ':patient_id' => $patient_id,
                ':doctor_id' => $doctor_id,
            ]);
            $visit_id = $pdo->lastInsertId();

            // 2. Insert consultation linked to this visit_id
            $consultSql = "INSERT INTO consultations 
                (visit_id, patient_id, doctor_id, diagnosis, notes, treatment, status, created_at) 
                VALUES 
                (:visit_id, :patient_id, :doctor_id, :diagnosis, :notes, :treatment, :status, NOW())";

            $consultStmt = $pdo->prepare($consultSql);
            $ok = $consultStmt->execute([
                ':visit_id'   => $visit_id,
                ':patient_id' => $patient_id,
                ':doctor_id'  => $doctor_id,
                ':diagnosis'  => $diagnosis,
                ':notes'      => $notes,
                ':treatment'  => $treatment,
                ':status'     => $status,
            ]);

            if ($ok) {
                $pdo->commit();
                $message = "<div class='alert alert-success'>✅ Consultation added successfully!</div>";
            } else {
                $pdo->rollBack();
                $message = "<div class='alert alert-danger'>❌ Failed to add consultation.</div>";
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert alert-danger'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    } else {
        $message = "<div class='alert alert-warning'>⚠️ Patient, doctor, or diagnosis missing.</div>";
    }
}
?>

<h2>Add Consultation</h2>

<?= $message ?>

<form method="get" action="">
    <label for="search">Search Patient by ID or Phone:</label>
    <input type="text" name="search" id="search" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
    <button type="submit">Search</button>
</form>

<?php if ($patient): ?>
    <form method="post" action="">
        <input type="hidden" name="patient_id" value="<?= htmlspecialchars($patient['id']) ?>">

        <div class="mb-3">
            <label class="form-label">Patient Name</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($patient['fullname']) ?>" disabled>
        </div>

        <div class="mb-3">
            <label for="diagnosis" class="form-label">Diagnosis</label>
            <textarea name="diagnosis" id="diagnosis" class="form-control" required><?= htmlspecialchars($_POST['diagnosis'] ?? '') ?></textarea>
        </div>

        <div class="mb-3">
            <label for="notes" class="form-label">Notes</label>
            <textarea name="notes" id="notes" class="form-control"><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
        </div>

        <div class="mb-3">
            <label for="treatment" class="form-label">Treatment</label>
            <textarea name="treatment" id="treatment" class="form-control"><?= htmlspecialchars($_POST['treatment'] ?? '') ?></textarea>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" id="status" class="form-select">
                <?php
                $statuses = ['pending', 'in-progress', 'completed', 'referred'];
                $current = $_POST['status'] ?? 'pending';
                foreach ($statuses as $s) {
                    $sel = $s === $current ? 'selected' : '';
                    echo "<option value=\"$s\" $sel>" . ucfirst($s) . "</option>";
                }
                ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Save Consultation</button>
    </form>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
