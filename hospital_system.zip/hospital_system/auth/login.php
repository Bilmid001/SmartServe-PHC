<?php 
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/config.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        session_start();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        switch ($user['role']) {
            case 'admin':       header("Location: ../admin/dashboard.php"); break;
            case 'records':     header("Location: ../records/dashboard.php"); break;
            case 'doctor':      header("Location: ../doctor/dashboard.php"); break;
            case 'lab':         header("Location: ../lab/dashboard.php"); break;
            case 'pharmacy':    header("Location: ../pharmacy/dashboard.php"); break;
            case 'environment': header("Location: ../environment/dashboard.php"); break;
            default:            header("Location: ../index.php"); break;
        }
        exit;
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
     body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #f5f7fa;
    overflow: hidden; /* Prevents scrolling */
}

.hospital-header {
    text-align: center;
    padding: 1rem;
    background: #0d6efd;
    color: white;
    font-size: 1.5rem;
    font-weight: bold;
    letter-spacing: 1px;
}

.login-container {
    height: calc(100vh - 70px);
    overflow: hidden;
}

.carousel-col,
.form-wrapper {
    height: 100%;
}

.carousel,
.carousel-inner,
.carousel-item,
.carousel-img {
    height: 100%;
}

.carousel-img {
    object-fit: cover; /* Ensures no distortion */
}

.form-wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    background: #ffffff;
    padding: 2rem;
}

.login-card {
    width: 100%;
    max-width: 400px;
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    background: #fff;
    animation: fadeIn 1s ease-in-out;
}

.login-card h4 {
    font-weight: bold;
    margin-bottom: 20px;
    color: #0d6efd;
}

.input-group-text {
    background-color: #e9ecef;
    cursor: pointer;
}

.form-control:focus {
    box-shadow: 0 0 0 0.2rem rgba(13,110,253,.25);
}

/* Center carousel caption vertically */
.carousel-caption {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    bottom: auto;
    right: auto;
    background: rgba(0, 0, 0, 0.5);
    padding: 1.2rem;
    border-radius: 12px;
    text-align: center;
    animation: slideUp 1s ease;
}

@media (max-width: 768px) {
    .carousel-col {
        display: none;
    }
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes slideUp {
    from { opacity: 0; transform: translateY(50px); }
    to { opacity: 1; transform: translateY(0); }
}
    </style>
</head>
<body>
    <!-- Hospital Header -->
    <div class="hospital-header">
        SMARTSERVE AI-ENHANCED HOSPITAL SYSTEM
    </div>

    <div class="container-fluid login-container">
        <div class="row h-100">
            <!-- Left: Carousel -->
            <div class="col-md-6 carousel-col p-0">
                <div id="carouselImages" class="carousel slide h-100" data-bs-ride="carousel">
                    <div class="carousel-inner h-100">
                        <div class="carousel-item active h-100">
                            <img src="../assets/img/rec1.jpg" class="d-block w-100 carousel-img" alt="Slide 1">
                            <div class="carousel-caption text-center">
                                <h5 class="fw-bold text-warning">Primary Health Care</h5>
                                <p>Welcome to the future with our AI-Health Assistant, guiding your care anytime, anywhere.</p>
                            </div>
                        </div>
                        <div class="carousel-item h-100">
                            <img src="../assets/img/rec2.jpg" class="d-block w-100 carousel-img" alt="Slide 2">
                            <div class="carousel-caption text-center">
                                <h5 class="fw-bold text-warning">Fast Appointments</h5>
                                <p>Schedule visits and get reminders instantly with smart automation.</p>
                            </div>
                        </div>
                        <div class="carousel-item h-100">
                            <img src="../assets/img/rec3.jpg" class="d-block w-100 carousel-img" alt="Slide 3">
                            <div class="carousel-caption text-center">
                                <h5 class="fw-bold text-warning">Personalized Care</h5>
                                <p>AI insights + doctors’ expertise = better treatment plans for you.</p>
                            </div>
                        </div>
                        <div class="carousel-item h-100">
                            <img src="../assets/img/rec4.jpg" class="d-block w-100 carousel-img" alt="Slide 4">
                            <div class="carousel-caption text-center">
                                <h5 class="fw-bold text-warning">24/7 Access</h5>
                                <p>Login anywhere, anytime with secure access to your records.</p>
                            </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselImages" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselImages" data-bs-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </button>
                </div>
            </div>

            <!-- Right: Login -->
            <div class="col-md-6 form-wrapper">
                <div class="login-card">
                    <h4 class="text-center">Smart-Serve Login</h4>
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    <form method="post" novalidate>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input name="username" id="username" class="form-control" required autofocus>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <input type="password" name="password" id="password" class="form-control" required>
                                <span class="input-group-text" onclick="togglePassword()">
                                    <i class="bi bi-eye" id="toggleIcon"></i>
                                </span>
                            </div>
                        </div>

                        <button class="btn btn-primary w-100">Login</button>
                    </form>
                    <p style="text-align:center; font-size:13px; margin-top:15px; color:#555;">
                    <div style="margin-top:20px; text-align:center; font-size:13px; color:#444;">
                    <p style="margin-bottom:8px; font-weight:bold; color:#0d6efd;">Demo Login Credentials</p>
                    <div style="display:inline-block; text-align:left; background:#f8f9fa; padding:12px 18px; border-radius:10px; box-shadow:0 3px 8px rgba(0,0,0,0.1);">
                        <p style="margin:4px 0;"><strong>Admin: </strong>Username: <span style="color:#0d6efd;">Admin</span>, Password: <span style="color:#dc3545;">Admin123</span></p>
                        <p style="margin:4px 0;"><strong>Records: </strong>Username: <span style="color:#0d6efd;">Record</span>, Password: <span style="color:#dc3545;">123456</span></p>
                        <p style="margin:4px 0;"><strong>Doctor: </strong>Username: <span style="color:#0d6efd;">Doctor</span>, Password: <span style="color:#dc3545;">123456</span></p>
                        <p style="margin:4px 0;"><strong>Lab: </strong>Username: <span style="color:#0d6efd;">Laboratory</span>, Password: <span style="color:#dc3545;">123456</span></p>
                        <p style="margin:4px 0;"><strong>Environment: </strong>Username: <span style="color:#0d6efd;">Environment</span>, Password: <span style="color:#dc3545;">123456</span></p>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const password = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (password.type === "password") {
                password.type = "text";
                icon.classList.remove("bi-eye");
                icon.classList.add("bi-eye-slash");
            } else {
                password.type = "password";
                icon.classList.remove("bi-eye-slash");
                icon.classList.add("bi-eye");
            }
        }
    </script>
</body>
</html>
