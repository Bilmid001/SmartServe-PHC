<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die("Invalid patient ID.");
}

$patient = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
$patient->execute([$id]);
$p = $patient->fetch(PDO::FETCH_ASSOC);

if (!$p) {
    die("Patient not found.");
}

$stmt = $pdo->prepare("SELECT * FROM environment_cases WHERE patient_id = ? ORDER BY date_reported DESC");
$stmt->execute([$id]);
$cases = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Patient Environment Cases";
include __DIR__ . '/../includes/header.php';
?>

<div class="container">
  <h2>Environment History — <?= htmlspecialchars($p['fullname'] ?? '#'.$id) ?></h2>

  <?php if (count($cases) === 0): ?>
    <p>No environment cases found for this patient.</p>
  <?php else: ?>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Date Reported</th>
          <th>Case Type</th>
          <th>Status</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($cases as $c): ?>
          <tr>
            <td><?= htmlspecialchars($c['date_reported']) ?></td>
            <td><?= htmlspecialchars($c['case_type']) ?></td>
            <td><?= htmlspecialchars($c['status']) ?></td>
            <td><?= htmlspecialchars($c['description']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
