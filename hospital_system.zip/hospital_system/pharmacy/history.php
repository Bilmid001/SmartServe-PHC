<?php
// pharmacy/history.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    header('Location: ../records/search.php');
    exit;
}

// fetch patient
$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->execute([$id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$patient) die("Patient not found.");

// fetch prescriptions
$stmt = $pdo->prepare("SELECT pr.*, d.id AS dispense_id, d.dispensed_at FROM prescriptions pr LEFT JOIN pharmacy_dispenses d ON pr.id = d.prescription_id WHERE pr.patient_id = ? ORDER BY pr.created_at DESC");
$stmt->execute([$id]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Pharmacy History";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-3">Pharmacy History — <?= htmlspecialchars($patient['fullname']) ?> <small class="text-muted">#<?= $patient['id'] ?></small></h2>
  <div class="mb-3 small text-muted">
    Phone: <?= htmlspecialchars($patient['phone'] ?? '-') ?> |
    Gender: <?= htmlspecialchars($patient['gender'] ?? '-') ?> |
    DOB: <?= htmlspecialchars($patient['dob'] ?? '-') ?> |
    Status: <?= htmlspecialchars($patient['status'] ?? '-') ?>
  </div>

  <?php if ($history): ?>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Date</th>
          <th>Medicine</th>
          <th>Dosage</th>
          <th>Quantity</th>
          <th>Status</th>
          <th>Dispensed At</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($history as $row): ?>
          <tr>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td><?= htmlspecialchars($row['medicine']) ?></td>
            <td><?= htmlspecialchars($row['dosage'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['quantity'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td><?= htmlspecialchars($row['dispensed_at'] ?? '-') ?></td>
            <td>
              <a class="btn btn-sm btn-secondary" href="edit_prescription.php?id=<?= $row['id'] ?>">Edit</a>
              <?php if ($row['status'] !== 'dispensed'): ?>
                <a class="btn btn-sm btn-success" href="dispense.php?id=<?= $row['id'] ?>">Dispense</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="alert alert-info">No prescription history for this patient.</div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
