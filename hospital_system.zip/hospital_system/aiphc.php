<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>HealthAssist AI</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: #f0f4f8;
    }

    /* Floating Chat Widget */
    #chat-widget {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 360px;
      height: 520px;
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
      display: flex;
      flex-direction: column;
      overflow: hidden;
      border: 2px solid #2e86c1;
    }

    /* Header */
    #chat-header {
      background: linear-gradient(135deg, #2e86c1, #28a745);
      color: #fff;
      padding: 14px;
      text-align: center;
      font-weight: bold;
      font-size: 16px;
    }

    /* Messages area */
    #chat-messages {
      flex: 1;
      padding: 12px;
      overflow-y: auto;
      background: #f9fbfd;
    }

    .message {
      margin: 8px 0;
      padding: 10px 14px;
      border-radius: 14px;
      max-width: 80%;
      font-size: 14px;
      line-height: 1.4em;
    }
    .bot-message {
      background: #e8f4fe;
      color: #333;
      align-self: flex-start;
      border: 1px solid #cce0f7;
    }
    .user-message {
      background: #d1ffd6;
      color: #222;
      align-self: flex-end;
      border: 1px solid #a8e6b5;
    }

    /* Input area */
    #chat-input {
      display: flex;
      border-top: 1px solid #ccc;
      padding: 8px;
      background: #fff;
    }
    #chat-input input {
      flex: 1;
      border: 1px solid #ccc;
      border-radius: 20px;
      padding: 10px 14px;
      font-size: 14px;
      outline: none;
    }
    #chat-input button {
      margin-left: 8px;
      border: none;
      background: #2e86c1;
      color: #fff;
      padding: 0 18px;
      border-radius: 20px;
      cursor: pointer;
      font-weight: bold;
    }
    #chat-input button:hover {
      background: #2569a8;
    }

    /* Footer Quick Actions */
    footer {
      background: #f4f6f8;
      padding: 10px;
      text-align: center;
    }
    footer button {
      margin: 4px;
      padding: 8px 12px;
      border: none;
      border-radius: 20px;
      cursor: pointer;
      font-size: 13px;
      font-weight: bold;
    }
    .quick-btn {
      background: #28a745;
      color: #fff;
    }
    .quick-btn:hover {
      background: #1f7a36;
    }
    .clear-btn {
      background: #dc3545;
      color: #fff;
    }
    .clear-btn:hover {
      background: #b52a37;
    }
  </style>
</head>
<body>

  <div id="chat-widget">
    <div id="chat-header">🤖 HealthAssist AI</div>
    
    <div id="chat-messages">
      <div class="message bot-message">
        👋 Hello! I'm HealthAssist AI, your healthcare assistant. How can I help you today?
      </div>
    </div>

    <div id="chat-input">
      <input type="text" id="user-input" placeholder="Type your message...">
      <button onclick="sendMessage()">Send</button>
    </div>

    <footer>
      <button class="quick-btn" onclick="startFlow('appointment')">📅 Appointment</button>
      <button class="quick-btn" onclick="startFlow('prescription')">💊 Prescription</button>
      <button class="quick-btn" onclick="startFlow('lab')">🧪 Lab Test</button>
      <button class="quick-btn" onclick="startFlow('hours')">⏰ Hours</button>
      <button class="quick-btn" onclick="startFlow('emergency')">🚑 Emergency</button>
      <br>
      <button class="clear-btn" onclick="clearChat()">🧹 Clear</button>
    </footer>
  </div>

  <script>
    const chatMessages = document.getElementById("chat-messages");
    const userInput = document.getElementById("user-input");

    let conversationState = {
      flow: null,
      step: 0,
      data: {}
    };

    function addMessage(text, isUser = false) {
      const msg = document.createElement("div");
      msg.classList.add("message", isUser ? "user-message" : "bot-message");
      msg.innerText = text;
      chatMessages.appendChild(msg);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function sendMessage() {
      const text = userInput.value.trim();
      if (!text) return;
      addMessage(text, true);
      handleUserInput(text);
      userInput.value = "";
    }

    function handleUserInput(input) {
      if (conversationState.flow) {
        handleFlow(input);
      } else {
        addMessage("Sorry, I didn't quite understand. Try using a quick action button below ⬇️");
      }
    }

    function startFlow(flow) {
      conversationState = { flow, step: 0, data: {} };
      if (flow === "appointment") {
        addMessage("📅 Great! Let's book an appointment. What date would you like? (YYYY-MM-DD)");
      } else if (flow === "prescription") {
        addMessage("💊 Sure, let's refill your prescription. Can I have your Patient ID?");
      } else if (flow === "lab") {
        addMessage("🧪 Let's schedule a lab test. Please provide your Patient ID.");
      } else if (flow === "hours") {
        addMessage("⏰ We’re open Mon–Fri: 8AM–8PM, Sat: 9AM–4PM. Emergencies are 24/7.");
        addMessage("Would you like me to check doctor availability for a specific day?");
        resetState();
      } else if (flow === "emergency") {
        addMessage("🚑 In case of emergency, please call 112 or head to the Emergency Department immediately.");
        addMessage("Do you want me to connect you to our hotline?");
        resetState();
      }
    }

    function handleFlow(input) {
      const { flow, step, data } = conversationState;

      if (flow === "appointment") {
        if (step === 0) {
          data.date = input;
          addMessage("⏰ What time?");
          conversationState.step++;
        } else if (step === 1) {
          data.time = input;
          addMessage("👨‍⚕️ Which doctor would you like to see?");
          conversationState.step++;
        } else if (step === 2) {
          data.doctor = input;
          addMessage(`✅ Appointment booked: ${data.date} at ${data.time} with Dr. ${data.doctor}`);
          resetAfterDelay();
        }
      }

      else if (flow === "prescription") {
        if (step === 0) {
          data.patientId = input;
          addMessage("What medication do you need?");
          conversationState.step++;
        } else if (step === 1) {
          data.medication = input;
          addMessage("What dosage?");
          conversationState.step++;
        } else if (step === 2) {
          data.dosage = input;
          addMessage(`✅ Prescription refill request saved: ${data.medication} (${data.dosage}), Patient ID: ${data.patientId}`);
          resetAfterDelay();
        }
      }

      else if (flow === "lab") {
        if (step === 0) {
          data.patientId = input;
          addMessage("What type of lab test?");
          conversationState.step++;
        } else if (step === 1) {
          data.test = input;
          addMessage("What date? (YYYY-MM-DD)");
          conversationState.step++;
        } else if (step === 2) {
          data.date = input;
          addMessage(`✅ Lab test scheduled: ${data.test} on ${data.date}, Patient ID: ${data.patientId}`);
          resetAfterDelay();
        }
      }
    }

    function resetState() {
      conversationState = { flow: null, step: 0, data: {} };
    }

    function clearChat() {
      chatMessages.innerHTML = `<div class="message bot-message">
        👋 Hello! I'm HealthAssist AI, your healthcare assistant. How can I help you today?
      </div>`;
      resetState();
    }

    function resetAfterDelay() {
      setTimeout(clearChat, 3000);
    }
  </script>

</body>
</html>
