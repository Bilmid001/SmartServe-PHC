<?php
// admin/ai_assistant.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$page_title = "AI Assistant";
include __DIR__ . '/../includes/header.php';
?>
<style>
/* Your existing styles are preserved here */
:root {
    --primary: #2a7de1;
    --primary-dark: #1a5bbd;
    --secondary: #4cc9b4;
    --light: #f8f9fa;
    --dark: #343a40;
    --success: #28a745;
    --danger: #dc3545;
    --warning: #ffc107;
    --info: #17a2b8;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}
header {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: white;
    padding: 1rem 2rem;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
.header-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.logo {
    display: flex;
    align-items: center;
    gap: 15px;
}
.logo-icon {
    font-size: 2rem;
    background: white;
    color: var(--primary);
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}
h1 {
    font-size: 1.8rem;
    font-weight: 600;
}
.subtitle {
    font-size: 1rem;
    opacity: 0.9;
    margin-top: 5px;
}
.chat-box {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    display: flex;
    flex-direction: column;
    height: 600px;
}
.chat-header {
    background: var(--primary);
    color: white;
    padding: 15px 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.chat-header img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: white;
    padding: 5px;
}
.chat-messages {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 15px;
}
.message {
    max-width: 80%;
    padding: 12px 16px;
    border-radius: 18px;
    line-height: 1.4;
    position: relative;
}
.bot-message {
    background: #f0f5ff;
    align-self: flex-start;
    border-bottom-left-radius: 5px;
}
.user-message {
    background: var(--primary);
    color: white;
    align-self: flex-end;
    border-bottom-right-radius: 5px;
}
.chat-input {
    display: flex;
    padding: 15px;
    border-top: 1px solid #eee;
    background: #f8f9fa;
}
.chat-input input {
    flex: 1;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 25px;
    outline: none;
    font-size: 1rem;
}
.chat-input button {
    background: var(--primary);
    color: white;
    border: none;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    margin-left: 10px;
    cursor: pointer;
    transition: background 0.3s;
}
.chat-input button:hover {
    background: var(--primary-dark);
}
.suggestions {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    padding: 10px 15px;
    background: #f8f9fa;
    border-top: 1px solid #eee;
}
.suggestion {
    background: white;
    border: 1px solid #ddd;
    padding: 8px 15px;
    border-radius: 18px;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s;
}
.suggestion:hover {
    background: #f0f5ff;
    border-color: var(--primary);
}
.typing-indicator {
    display: flex;
    padding: 5px;
    gap: 5px;
}
.typing-dot {
    width: 8px;
    height: 8px;
    background: #ccc;
    border-radius: 50%;
    animation: typingAnimation 1.4s infinite ease-in-out;
}
.typing-dot:nth-child(1) { animation-delay: 0s; }
.typing-dot:nth-child(2) { animation-delay: 0.2s; }
.typing-dot:nth-child(3) { animation-delay: 0.4s; }
@keyframes typingAnimation {
    0%, 60%, 100% { transform: translateY(0); }
    30% { transform: translateY(-5px); }
}
footer {
    text-align: center;
    margin-top: 30px;
    color: #6c757d;
    font-size: 0.9rem;
}
</style>

<div class="container">
    <header>
        <div class="header-content">
            <div class="logo">
                <div class="logo-icon">⚕️</div>
                <div>
                    <h1>AI HealthAssist</h1>
                    <div class="subtitle">Your intelligent healthcare management assistant</div>
                </div>
            </div>
        </div>
    </header>

    <div class="chat-box">
        <div class="chat-header">
            <img src="https://cdn-icons-png.flaticon.com/512/4712/4712109.png" alt="AI Icon">
            <div>
                <div>HealthAssist AI</div>
                <div style="font-size: 0.8rem; opacity: 0.8;">Online - Ready to help</div>
            </div>
        </div>

        <div class="chat-messages" id="chat-messages">
            <div class="message bot-message">
                Hello! I'm HealthAssist AI, your healthcare assistant. How can I help you today?
            </div>
        </div>

        <div class="suggestions">
            <div class="suggestion" onclick="sendQuickQuestion('appointment')">Schedule an appointment</div>
            <div class="suggestion" onclick="sendQuickQuestion('prescription')">Request prescription refill</div>
            <div class="suggestion" onclick="sendQuickQuestion('billing')">Billing question</div>
            <div class="suggestion" onclick="sendQuickQuestion('doctor')">Find a doctor</div>
        </div>

        <div class="chat-input">
            <input type="text" id="user-input" placeholder="Type your message here..." onkeypress="handleKeyPress(event)">
            <button onclick="sendMessage()">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>

    <footer>
        <p>HealthAssist AI v1.0 | Powered by Bilmid Tech Creative</p>
    </footer>
</div>

<script>
const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');

function addMessage(message, isUser = false) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    messageDiv.classList.add(isUser ? 'user-message' : 'bot-message');
    messageDiv.textContent = message;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.classList.add('typing-indicator');
    typingDiv.id = 'typing-indicator';
    typingDiv.innerHTML = `
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
    `;
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typing-indicator');
    if (typingIndicator) typingIndicator.remove();
}

async function getAIResponse(message) {
    showTypingIndicator();

    try {
        const response = await fetch('/admin/google_gemini_proxy.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query: message })
        });

        const data = await response.json();

        if (data.error) {
            return "Error: " + data.error;
        }

        return data.result || "I'm not sure how to respond to that.";
    } catch (err) {
        console.error("Error:", err);
        return "Something went wrong while contacting the AI service.";
    } finally {
        removeTypingIndicator();
    }
}

async function sendMessage() {
    const message = userInput.value.trim();
    if (!message) return;

    addMessage(message, true);
    userInput.value = '';

    const aiResponse = await getAIResponse(message);
    addMessage(aiResponse, false);
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendQuickQuestion(type) {
    let message = '';
    switch (type) {
        case 'appointment':
            message = 'I need to schedule a doctor\'s appointment.';
            break;
        case 'prescription':
            message = 'Can I get a refill on my prescription?';
            break;
        case 'billing':
            message = 'I have a question about my recent bill.';
            break;
        case 'doctor':
            message = 'Can you help me find a doctor?';
            break;
    }
    userInput.value = message;
    sendMessage();
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
