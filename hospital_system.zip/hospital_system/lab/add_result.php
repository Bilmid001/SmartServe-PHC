<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'] ?? null;
    $consultation_id = $_POST['consultation_id'] ?? null;
    $test_type = $_POST['test_type'] ?? null;
    $result = $_POST['result'] ?? null;
    $status = $_POST['status'] ?? 'pending';

    if ($patient_id && $consultation_id && $test_type) {
        $stmt = $pdo->prepare("
            INSERT INTO lab_results 
            (consultation_id, test_type, result, status, patient_id, requested_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$consultation_id, $test_type, $result, $status, $patient_id]);

        $success = "Lab result added successfully!";
    } else {
        $error = "Please fill in all required fields.";
    }
}

// Fetch patients for dropdown
$patients = $pdo->query("SELECT id, fullname, phone FROM patients ORDER BY fullname ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch consultations for dropdown
$consultations = $pdo->query("
    SELECT c.id, c.diagnosis, p.fullname 
    FROM consultations c
    JOIN patients p ON c.patient_id = p.id
    ORDER BY c.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<?php
function calculateAge($dob) {
    $birthDate = new DateTime($dob);
    $today = new DateTime();
    return $today->diff($birthDate)->y;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Lab Result</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 40px;
            background-color: #f8f9fa;
        }

        h2 {
            color: #343a40;
            margin-bottom: 20px;
        }

        form {
            background: #fff;
            padding: 25px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            max-width: 600px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #333;
        }

        select, input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        button {
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

    <h2>Add Lab Result</h2>

    <?php if (!empty($success)): ?>
        <div class="message success"><?= htmlspecialchars($success) ?></div>
    <?php elseif (!empty($error)): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post">
        <label for="patient_id">Patient:</label>
        <select name="patient_id" id="patient_id" required>
            <option value="">-- Select Patient --</option>
            <?php foreach ($patients as $p): ?>
                <option value="<?= $p['id'] ?>">
                    <?= htmlspecialchars($p['fullname']) ?> 
                    (Age: <?= calculateAge($p['dob']) ?>, 
                    <?= htmlspecialchars($p['phone']) ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <label for="consultation_id">Consultation:</label>
        <select name="consultation_id" id="consultation_id" required>
            <option value="">-- Select Consultation --</option>
            <?php foreach ($consultations as $c): ?>
                <option value="<?= $c['id'] ?>">
                    <?= htmlspecialchars($c['fullname']) ?> - <?= htmlspecialchars($c['diagnosis']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="test_type">Test Type:</label>
        <input type="text" name="test_type" id="test_type" required>

        <label for="result">Result:</label>
        <textarea name="result" id="result"></textarea>

        <label for="status">Status:</label>
        <select name="status" id="status">
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
        </select>

        <button type="submit">Save Result</button>
    </form>

</body>
</html>

<?php include __DIR__ . '/../includes/footer.php'; ?>