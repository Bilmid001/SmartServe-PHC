<?php 
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$sql = "SELECT c.*, p.fullname FROM environment_cases c LEFT JOIN patients p ON c.patient_id = p.id ORDER BY c.date_reported DESC";
$stmt = $pdo->query($sql);  // <-- execute the query and assign to $stmt
$cases = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Environment Cases";
include __DIR__ . '/../includes/header.php';
?>

<div class="container">
  <h2 class="mb-3">Environment Cases</h2>
  <a class="btn btn-success mb-3" href="add_case.php">New Case</a>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Date</th>
        <th>Patient</th>
        <th>Case Type</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($cases as $c): ?>
        <tr>
          <td><?= htmlspecialchars($c['date_reported']) ?></td>
          <td><?= htmlspecialchars($c['fullname'] ?? ('#'.$c['patient_id'])) ?></td>
          <td><?= htmlspecialchars($c['case_type']) ?></td>
          <td><?= htmlspecialchars($c['status']) ?></td>
          <td>
            <a class="btn btn-sm btn-primary" href="edit_case.php?id=<?= $c['id'] ?>">Edit</a>
            <a class="btn btn-sm btn-info" href="patient_history.php?id=<?= $c['patient_id'] ?>">History</a>
            
            <form method="post" action="delete_case.php" style="display:inline" onsubmit="return confirm('Are you sure you want to delete this case?');">
              <input type="hidden" name="id" value="<?= $c['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
