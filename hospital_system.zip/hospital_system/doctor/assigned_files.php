<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['admin','doctor'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$stmt = $pdo->prepare("SELECT v.id,v.status,v.opened_at,p.first_name,p.last_name 
                       FROM visits v 
                       JOIN patients p ON v.patient_id=p.id 
                       WHERE v.doctor_id=? ORDER BY v.id DESC");
$stmt->execute([$_SESSION['user_id']]);
$files = $stmt->fetchAll();

$page_title = "Assigned Files";
include __DIR__ . '/../includes/header.php';
?>
<h2>My Assigned Patient Files</h2>
<table class="table table-bordered">
<thead><tr><th>ID</th><th>Patient</th><th>Status</th><th>Opened</th><th>Action</th></tr></thead>
<tbody>
<?php foreach($files as $f): ?>
<tr>
  <td><?= $f['id'] ?></td>
  <td><?= htmlspecialchars($f['first_name']." ".$f['last_name']) ?></td>
  <td><?= ucfirst($f['status']) ?></td>
  <td><?= $f['opened_at'] ?></td>
  <td><a href="review_file.php?id=<?= $f['id'] ?>" class="btn btn-primary btn-sm">Review</a></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
