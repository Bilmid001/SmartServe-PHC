<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['admin','doctor'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$stmt = $pdo->query("
    SELECT p.*, v.id AS visit_id, v.status, v.doctor_id
    FROM patients p
    LEFT JOIN visits v ON p.id = v.patient_id
    ORDER BY p.id DESC
");
$patients = $stmt->fetchAll();

$page_title = "Patient List";
include __DIR__ . '/../includes/header.php';
?>
<h2>Patient List</h2>
<table class="table">
  <thead><tr><th>Name</th><th>Visit Status</th></tr></thead>
  <tbody>
  <?php foreach ($patients as $pat): ?>
    <tr>
      <td><?= htmlspecialchars($pat['first_name'].' '.$pat['last_name']) ?></td>
      <td><?= $pat['status'] ?? 'No visit yet' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
