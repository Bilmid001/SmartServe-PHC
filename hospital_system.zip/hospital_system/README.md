# Hospital System

Drop this folder into your webserver's htdocs as 'hospital_system'. Edit includes/db.php credentials then run setup_admin.php once to create DB and default admin (admin/Admin@123). Remove setup_admin.php after use.