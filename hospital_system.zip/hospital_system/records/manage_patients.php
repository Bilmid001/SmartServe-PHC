<?php
// records/manage_patients.php
// session_start();
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$page_title = "Manage Patients";
include __DIR__ . '/../includes/header.php';

// Handle delete

if (isset($_GET['msg']) && $_GET['msg'] === 'updated') {
    echo "<div class='alert alert-success'>✅ Patient updated successfully.</div>";
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM patients WHERE id = ?");
    if ($stmt->execute([$id])) {
        echo "<div class='alert alert-success'>✅ Patient deleted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>❌ Error deleting patient.</div>";
    }
    
}

// Fetch all patients
$search = $_GET['search'] ?? '';

if ($search) {
    $stmt = $pdo->prepare("SELECT * FROM patients WHERE fullname LIKE ? OR phone LIKE ? ORDER BY id DESC");
    $likeSearch = "%$search%";
    $stmt->execute([$likeSearch, $likeSearch]);
} else {
    $stmt = $pdo->query("SELECT * FROM patients ORDER BY id DESC");
}

$patients = $stmt->fetchAll();
?>

<div class="container-fluid">
  <h2 class="mb-4">Manage Patients</h2>

  <form method="get" class="row mb-3">
    <div class="col-md-6">
      <input type="text" name="search" class="form-control" placeholder="Search by name or phone..." value="<?= htmlspecialchars($search) ?>">
    </div>
    <div class="col-md-2">
      <button class="btn btn-primary">Search</button>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Full Name</th>
          <th>Sex</th>
          <th>DOB</th>
          <th>Phone</th>
          <th>Address</th>
          <th>Next of Kin</th>
          <th>NOK Phone</th>
          <th>Fingerprint</th>
          <th>Created</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($patients as $row): ?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['fullname']) ?></td>
            <td><?= htmlspecialchars($row['gender']) ?></td>
            <td><?= htmlspecialchars($row['dob']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['address']) ?></td>
            <td><?= htmlspecialchars($row['next_of_kin']) ?></td>
            <td><?= htmlspecialchars($row['nok_phone']) ?></td>
            <td><?= htmlspecialchars($row['fingerprint']) ?></td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td>
              <a href="edit_patient.php?id=<?= htmlspecialchars($row['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
              <a href="?delete=<?= htmlspecialchars($row['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this patient?');">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
