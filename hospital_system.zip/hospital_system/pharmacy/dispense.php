<?php
// pharmacy/dispense.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['pharmacy','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    header('Location: prescriptions.php');
    exit;
}

// load prescription + patient
$stmt = $pdo->prepare("SELECT pr.*, p.fullname, p.phone FROM prescriptions pr LEFT JOIN patients p ON pr.patient_id = p.id WHERE pr.id = ?");
$stmt->execute([$id]);
$presc = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$presc) die("Prescription not found.");

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qty = (int)($_POST['quantity'] ?? $presc['quantity'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');

    $pdo->beginTransaction();
    try {
        // create dispense record
        $ins = $pdo->prepare("INSERT INTO pharmacy_dispenses (prescription_id, dispensed_by, quantity, notes, dispensed_at) VALUES (?,?,?,?,NOW())");
        $ins->execute([$id, $_SESSION['user_id'] ?? null, $qty ?: null, $notes ?: null]);

        // update prescription status to dispensed (and optionally update updated_at)
        $upd = $pdo->prepare("UPDATE prescriptions SET status='dispensed', updated_at=NOW() WHERE id = ?");
        $upd->execute([$id]);

        $pdo->commit();
        $msg = "Prescription dispensed.";
        // reload prescription
        $stmt->execute([$id]);
        $presc = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $pdo->rollBack();
        $msg = "Error: " . $e->getMessage();
    }
}

$page_title = "Dispense Prescription";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-3">Dispense Prescription</h2>

  <?php if ($msg): ?><div class="alert alert-info"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <div class="card mb-3 p-3">
    <h5><?= htmlspecialchars($presc['fullname'] ?? 'Unknown') ?> <small class="text-muted">#<?= $presc['patient_id'] ?></small></h5>
    <div class="small text-muted">Medicine: <?= htmlspecialchars($presc['medicine']) ?> | Prescribed: <?= htmlspecialchars($presc['created_at']) ?></div>
  </div>

  <form method="post" class="row g-3">
    <div class="col-md-4">
      <label class="form-label">Quantity to Dispense</label>
      <input name="quantity" type="number" class="form-control" value="<?= htmlspecialchars($presc['quantity'] ?? '') ?>">
    </div>
    <div class="col-12">
      <label class="form-label">Notes</label>
      <textarea name="notes" class="form-control"></textarea>
    </div>
    <div class="col-12">
      <button class="btn btn-success">Dispense</button>
      <a class="btn btn-secondary" href="prescriptions.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
