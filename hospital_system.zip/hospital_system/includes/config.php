<?php
define('BASE_URL','/hospital_system');
define('APP_NAME','Hospital System');
?>

