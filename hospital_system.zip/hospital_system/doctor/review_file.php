<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT c.*, p.first_name, p.last_name, p.dob, p.gender
    FROM consultations c
    LEFT JOIN patients p ON c.patient_id = p.id
    WHERE c.id = ?
");
$stmt->execute([$id]);
$consult = $stmt->fetch();

if (!$consult) { header("Location: patient_list.php"); exit; }

$page_title = "View Consultation";
include __DIR__ . '/../includes/header.php';
?>
<h2>Consultation for <?= htmlspecialchars($consult['first_name']." ".$consult['last_name']) ?></h2>
<p><strong>Date:</strong> <?= htmlspecialchars($consult['created_at']) ?></p>
<p><strong>Notes:</strong> <?= nl2br(htmlspecialchars($consult['notes'])) ?></p>
<?php include __DIR__ . '/../includes/footer.php'; ?>
