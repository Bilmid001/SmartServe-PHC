<?php 
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM immunizations WHERE id=?");
$stmt->execute([$id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$row) die("Not found.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vaccine = trim($_POST['vaccine_name']);
    $dose = (int)($_POST['dose_number'] ?? 1);
    $date = $_POST['given_at'];  // changed from administered_at to given_at
    // Removed notes because it doesn't exist in the DB
    
    $pdo->prepare("UPDATE immunizations SET vaccine_name=?, dose_number=?, given_at=? WHERE id=?")
        ->execute([$vaccine, $dose, $date, $id]);

    header("Location: immunizations_list.php");
    exit;
}

$page_title = "Edit Immunization";
include __DIR__ . '/../includes/header.php';
?>

<div class="container">
  <h2>Edit Immunization</h2>
  <form method="post" class="row g-3">
    <div class="col-md-3">
      <label>Vaccine</label>
      <input name="vaccine_name" class="form-control" value="<?= htmlspecialchars($row['vaccine_name']) ?>" required>
    </div>
    <div class="col-md-2">
      <label>Dose #</label>
      <input type="number" name="dose_number" class="form-control" value="<?= htmlspecialchars($row['dose_number']) ?>" min="1" required>
    </div>
    <div class="col-md-3">
      <label>Date Given</label>
      <input type="date" name="given_at" class="form-control" value="<?= htmlspecialchars($row['given_at']) ?>" required>
    </div>
    <!-- Removed Notes field since it does not exist in your DB -->

    <div class="col-12">
      <button class="btn btn-primary">Save</button>
    </div>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
