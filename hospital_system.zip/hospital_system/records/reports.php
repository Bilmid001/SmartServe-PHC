<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=patients.csv');

$out=fopen('php://output','w');
fputcsv($out,['ID','First Name','Last Name','Phone','DOB']);
$rows=$pdo->query("SELECT id,first_name,last_name,phone,dob FROM patients");
foreach($rows as $r){
    fputcsv($out,$r);
}
fclose($out);
exit;
