<?php
require_once __DIR__.'/../includes/db.php'; require_once __DIR__.'/../includes/auth_check.php';
if($_SESSION['role']!=='admin'){ header('Location: '.BASE_URL.'/error/403.php'); exit; }
$err=''; $success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $username = trim($_POST['username']); $password = $_POST['password']; $role = $_POST['role'];
    if($username && $password){
        $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?'); $stmt->execute([$username]);
        if($stmt->fetch()){ $err='Username exists'; } else { $hash=password_hash($password,PASSWORD_DEFAULT); $ins=$pdo->prepare('INSERT INTO users (username,password_hash,role) VALUES (?,?,?)'); $ins->execute([$username,$hash,$role]); $success='User created'; }
    } else $err='Provide username and password';
}
$page_title='Register'; include __DIR__.'/../includes/header.php'; ?>
<div class="row"><div class="col-md-6"><h3>Create User</h3><?php if($err): ?><div class="alert alert-danger"><?php echo $err; ?></div><?php endif; ?><?php if($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
<form method="post"><div class="mb-2"><label>Username</label><input name="username" class="form-control" required></div>
<div class="mb-2"><label>Password</label><input name="password" class="form-control" required></div>
<div class="mb-2"><label>Role</label><select name="role" class="form-control"><option value="records">Records</option><option value="doctor">Doctor</option><option value="lab">Lab</option><option value="pharmacy">Pharmacy</option><option value="environment">Environment</option><option value="admin">Admin</option></select></div>
<button class="btn btn-success">Create</button></form></div></div><?php include __DIR__.'/../includes/footer.php'; ?>