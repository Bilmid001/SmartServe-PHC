<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=lab_results.csv');

$out=fopen('php://output','w');
fputcsv($out,['Result ID','Patient ID','Test','Result','Status','Completed']);
$stmt=$pdo->query("SELECT r.id,c.patient_id,r.test_name,r.result,r.status,r.completed_at
                   FROM lab_results r
                   JOIN consultations c ON r.consultation_id=c.id");
foreach($stmt as $row){
    fputcsv($out,$row);
}
fclose($out);
exit;
