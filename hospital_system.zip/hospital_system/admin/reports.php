<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';
if ($_SESSION['role']!=='admin'){ header('Location: '.BASE_URL.'/error/403.php'); exit; }

$which = $_GET['which'] ?? '';

switch($which){
  case 'patients':
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename=patients.csv');
    $out=fopen('php://output','w'); fputcsv($out,['id','first_name','last_name','phone','dob','created_at']);
    foreach($pdo->query("SELECT id,first_name,last_name,phone,dob,created_at FROM patients") as $r) fputcsv($out,$r);
    fclose($out); exit;
  case 'consultations':
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename=consultations.csv');
    $out=fopen('php://output','w'); fputcsv($out,['id','visit_id','doctor_id','diagnosis','notes','created_at']);
    foreach($pdo->query("SELECT id,visit_id,doctor_id,diagnosis,notes,created_at FROM consultations") as $r) fputcsv($out,$r);
    fclose($out); exit;
  case 'lab_results':
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename=lab_results.csv');
    $out=fopen('php://output','w'); fputcsv($out,['id','consultation_id','test_type','result','status','created_at']);
    foreach($pdo->query("SELECT id,consultation_id,test_type,result,status,created_at FROM lab_results") as $r) fputcsv($out,$r);
    fclose($out); exit;
  case 'pharmacy_dispenses':
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename=pharmacy_dispenses.csv');
    $out=fopen('php://output','w'); fputcsv($out,['id','prescription_id','dispensed_by','dispensed_at']);
    foreach($pdo->query("SELECT id,prescription_id,dispensed_by,dispensed_at FROM pharmacy_dispenses") as $r) fputcsv($out,$r);
    fclose($out); exit;
  case 'immunizations':
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename=immunizations.csv');
    $out=fopen('php://output','w'); fputcsv($out,['id','patient_id','vaccine_name','given_at','given_by']);
    foreach($pdo->query("SELECT id,patient_id,vaccine_name,given_at,given_by FROM immunizations") as $r) fputcsv($out,$r);
    fclose($out); exit;
  case 'community_cases':
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename=community_cases.csv');
    $out=fopen('php://output','w'); fputcsv($out,['id','case_type','description','reported_at','reported_by']);
    foreach($pdo->query("SELECT id,case_type,description,reported_at,reported_by FROM community_cases") as $r) fputcsv($out,$r);
    fclose($out); exit;
  case 'audit_logs':
    header('Content-Type: text/csv'); header('Content-Disposition: attachment;filename=audit_logs.csv');
    $out=fopen('php://output','w'); fputcsv($out,['id','user_id','action','table_name','record_id','created_at']);
    foreach($pdo->query("SELECT id,user_id,action,table_name,record_id,created_at FROM audit_logs") as $r) fputcsv($out,$r);
    fclose($out); exit;
  default:
    $page_title='System Reports';
    include __DIR__ . '/../includes/header.php';
    ?>
    <h2>System-wide Reports</h2>
    <ul>
      <li><a href="?which=patients">Export Patients CSV</a></li>
      <li><a href="?which=consultations">Export Consultations CSV</a></li>
      <li><a href="?which=lab_results">Export Lab Results CSV</a></li>
      <li><a href="?which=pharmacy_dispenses">Export Pharmacy Dispenses CSV</a></li>
      <li><a href="?which=immunizations">Export Immunizations CSV</a></li>
      <li><a href="?which=community_cases">Export Community Cases CSV</a></li>
      <li><a href="?which=audit_logs">Export Audit Logs CSV</a></li>
    </ul>
    <?php
    include __DIR__ . '/../includes/footer.php';
    break;
}
