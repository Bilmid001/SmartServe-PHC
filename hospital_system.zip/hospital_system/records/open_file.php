<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['admin', 'records'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$search = $_GET['search'] ?? '';
$msg = '';

// Handle Open / Close actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['patient_id'])) {
        $patient_id = (int)$_POST['patient_id'];
        if ($_POST['action'] === 'open') {
            // open file: insert new visit
            $stmt = $pdo->prepare("INSERT INTO visits (patient_id, opened_at, status) VALUES (?, ?, 'open')");
            $stmt->execute([$patient_id, date("Y-m-d H:i:s")]);
            $msg = "File opened successfully for patient #$patient_id.";
        }
        elseif ($_POST['action'] === 'close' && isset($_POST['visit_id'])) {
            $visit_id = (int)$_POST['visit_id'];
            // close file
            $stmt = $pdo->prepare("UPDATE visits SET status = 'closed', closed_at = NOW() WHERE id = ?");
            $stmt->execute([$visit_id]);
            $msg = "File closed successfully (visit #$visit_id).";
        }
    }
}

// Fetch patients + latest status from visits
if ($search) {
    $like = "%$search%";
    $stmt = $pdo->prepare("
        SELECT p.id, p.fullname, p.phone,
               v.id AS visit_id, v.status, v.opened_at, v.closed_at
        FROM patients p
        LEFT JOIN (
            SELECT * FROM visits
            WHERE status = 'open'
        ) v ON v.patient_id = p.id
        WHERE p.fullname LIKE ? OR p.phone LIKE ?
        ORDER BY p.id DESC
    ");
    $stmt->execute([$like, $like]);
} else {
    $stmt = $pdo->query("
        SELECT p.id, p.fullname, p.phone,
               v.id AS visit_id, v.status, v.opened_at, v.closed_at
        FROM patients p
        LEFT JOIN (
            SELECT * FROM visits
            WHERE status = 'open'
        ) v ON v.patient_id = p.id
        ORDER BY p.id DESC
    ");
}

$rows = $stmt->fetchAll();

$page_title = "Manage Patient Files";
include __DIR__ . '/../includes/header.php';
?>

<div class="container">
  <h2 class="mb-4">Manage Patient Files</h2>

  <?php if ($msg): ?>
    <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <form method="get" class="row mb-3">
    <div class="col-md-6">
      <input type="text" name="search" class="form-control" placeholder="Search by name or phone..." value="<?= htmlspecialchars($search) ?>">
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-primary">Search</button>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>ID</th>
          <th>Full Name</th>
          <th>Phone</th>
          <th>Status</th>
          <th>Opened At</th>
          <th>Closed At</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['id']) ?></td>
            <td><?= htmlspecialchars($r['fullname']) ?></td>
            <td><?= htmlspecialchars($r['phone']) ?></td>
            <td>
              <?= $r['status'] === 'open' ? "<span class='badge bg-success'>Open</span>" 
                    : "<span class='badge bg-secondary'>Closed</span>" ?>
            </td>
            <td><?= $r['opened_at'] ? htmlspecialchars($r['opened_at']) : '-' ?></td>
            <td><?= ($r['status'] === 'closed' && $r['closed_at']) ? htmlspecialchars($r['closed_at']) : '-' ?></td>
            <td>
              <form method="post" style="display:inline;">
                <input type="hidden" name="patient_id" value="<?= htmlspecialchars($r['id']) ?>">
                <?php if ($r['status'] === 'open'): ?>
                  <input type="hidden" name="visit_id" value="<?= htmlspecialchars($r['visit_id']) ?>">
                  <button type="submit" name="action" value="close" class="btn btn-sm btn-danger">Close File</button>
                <?php else: ?>
                  <button type="submit" name="action" value="open" class="btn btn-sm btn-primary">Open File</button>
                <?php endif; ?>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($rows)): ?>
          <tr><td colspan="7" class="text-center">No patients found</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
