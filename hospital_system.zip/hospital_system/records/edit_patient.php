<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$page_title = "Edit Patient";
include __DIR__ . '/../includes/header.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<div class='alert alert-danger'>Invalid patient ID.</div>";
    exit;
}

$id = (int) $_GET['id'];

$message = "";

// Fetch patient data
$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->execute([$id]);
$patient = $stmt->fetch();

if (!$patient) {
    echo "<div class='alert alert-danger'>Patient not found.</div>";
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname    = trim($_POST['fullname'] ?? '');
    $gender      = trim($_POST['gender'] ?? '');
    $dob         = trim($_POST['dob'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $address     = trim($_POST['address'] ?? '');
    $nok         = trim($_POST['nok'] ?? '');
    $nok_phone   = trim($_POST['nok_phone'] ?? '');
    $fingerprint = isset($_POST['fingerprint']) && $_POST['fingerprint'] === 'Yes' ? 'Yes' : 'No';
    $notes       = trim($_POST['notes'] ?? '');

    $update_stmt = $pdo->prepare("UPDATE patients SET 
        fullname = :fullname, 
        gender = :gender, 
        dob = :dob, 
        phone = :phone, 
        address = :address, 
        next_of_kin = :nok, 
        nok_phone = :nok_phone, 
        fingerprint = :fingerprint, 
        notes = :notes
        WHERE id = :id");

    $success = $update_stmt->execute([
        ':fullname'    => $fullname,
        ':gender'      => $gender,
        ':dob'         => $dob,
        ':phone'       => $phone,
        ':address'     => $address,
        ':nok'         => $nok,
        ':nok_phone'   => $nok_phone,
        ':fingerprint' => $fingerprint,
        ':notes'       => $notes,
        ':id'          => $id,
    ]);

    if ($success) {
        // Redirect to manage_patients.php after successful update
        header("Location: manage_patients.php?msg=updated");
        exit();
    } else {
        $message = "<div class='alert alert-danger'>❌ Error updating patient.</div>";
    }
}
?>

<div class="container">
    <h2 class="mb-4">Edit Patient</h2>
    <?= $message ?>

    <form method="post" class="row g-3" novalidate>
        <div class="col-md-6">
            <label class="form-label" for="fullname">Full Name</label>
            <input type="text" id="fullname" name="fullname" class="form-control" value="<?= htmlspecialchars($patient['fullname']) ?>" required>
        </div>
        <div class="col-md-3">
            <label class="form-label" for="gender">Gender</label>
            <select id="gender" name="gender" class="form-select" required>
                <option value="">-- Select --</option>
                <option value="male" <?= $patient['gender'] === 'male' ? 'selected' : '' ?>>Male</option>
                <option value="female" <?= $patient['gender'] === 'female' ? 'selected' : '' ?>>Female</option>
                <option value="other" <?= $patient['gender'] === 'other' ? 'selected' : '' ?>>Other</option>
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label" for="dob">Date of Birth</label>
            <input type="date" id="dob" name="dob" class="form-control" value="<?= htmlspecialchars($patient['dob']) ?>" required>
        </div>
        <div class="col-md-6">
            <label class="form-label" for="phone">Phone Number</label>
            <input type="text" id="phone" name="phone" class="form-control" value="<?= htmlspecialchars($patient['phone']) ?>" required>
        </div>
        <div class="col-md-6">
            <label class="form-label" for="address">Address</label>
            <input type="text" id="address" name="address" class="form-control" value="<?= htmlspecialchars($patient['address']) ?>" required>
        </div>
        <div class="col-md-6">
            <label class="form-label" for="nok">Next of Kin</label>
            <input type="text" id="nok" name="nok" class="form-control" value="<?= htmlspecialchars($patient['next_of_kin']) ?>" required>
        </div>
        <div class="col-md-6">
            <label class="form-label" for="nok_phone">Next of Kin Phone</label>
            <input type="text" id="nok_phone" name="nok_phone" class="form-control" value="<?= htmlspecialchars($patient['nok_phone']) ?>" required>
        </div>
        <div class="col-md-6">
            <label class="form-label">Fingerprint (Simulated)</label><br>
            <input type="checkbox" id="fingerprint" name="fingerprint" value="Yes" <?= $patient['fingerprint'] === 'Yes' ? 'checked' : '' ?>> Captured
        </div>
        <div class="col-md-12">
            <label class="form-label" for="notes">Notes</label>
            <textarea id="notes" name="notes" class="form-control" rows="3"><?= htmlspecialchars($patient['notes']) ?></textarea>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary">Update Patient</button>
        </div>
    </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
