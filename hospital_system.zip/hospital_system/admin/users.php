<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role'];

    if (empty($username) || empty($_POST['password']) || empty($role)) {
        $error = "All fields are required.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        if ($stmt->execute([$username, $password, $role])) {
            header("Location: users.php");
            exit;
        } else {
            $error = "Error adding user.";
        }
    }
}
?>

<div class="container">
  <h2 class="mb-4">Add New User</h2>
  <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
  <form method="post">
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" name="username" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Role</label>
      <select name="role" class="form-select" required>
        <option value="admin">Admin</option>
        <option value="doctor">Doctor</option>
        <option value="lab">Lab</option>
        <option value="pharmacy">Pharmacy</option>
        <option value="immunization">Immunization</option>
        <option value="environmental">Environmental</option>
        <option value="records">Records</option>
      </select>
    </div>
    <button type="submit" class="btn btn-success">Add User</button>
    <a href="users.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>
