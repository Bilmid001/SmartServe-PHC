<?php
// lab/edit_result.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['lab','doctor','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    header('Location: requested.php');
    exit;
}

// load lab record + patient
$stmt = $pdo->prepare("SELECT lr.*, p.fullname, p.phone FROM lab_results lr LEFT JOIN patients p ON lr.patient_id=p.id WHERE lr.id = ?");
$stmt->execute([$id]);
$lab = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$lab) {
    die("Lab record not found.");
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result_text = trim($_POST['result'] ?? '');
    $status = in_array($_POST['status'] ?? 'pending', ['pending','completed','cancelled']) ? $_POST['status'] : 'pending';

    $upd = $pdo->prepare("UPDATE lab_results SET result = :result, status = :status, completed_by = :user, completed_at = CASE WHEN :status = 'completed' THEN NOW() ELSE completed_at END, updated_at = NOW() WHERE id = :id");
    $upd->execute([
        ':result' => $result_text ?: null,
        ':status' => $status,
        ':user' => $_SESSION['user_id'] ?? null,
        ':id' => $id
    ]);

    $msg = "Lab result updated.";
    // reload
    $stmt->execute([$id]);
    $lab = $stmt->fetch(PDO::FETCH_ASSOC);
}

$page_title = "Edit Lab Result";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-3">Edit Lab Result</h2>
  <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <div class="card mb-3 p-3">
    <h5><?= htmlspecialchars($lab['fullname'] ?? 'Unknown') ?> <small class="text-muted">#<?= $lab['patient_id'] ?></small></h5>
    <div class="small text-muted">Test: <?= htmlspecialchars($lab['test_name']) ?> | Requested at: <?= htmlspecialchars($lab['requested_at']) ?></div>
  </div>

  <form method="post" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="pending" <?= $lab['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="completed" <?= $lab['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
        <option value="cancelled" <?= $lab['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
      </select>
    </div>

    <div class="col-12">
      <label class="form-label">Result</label>
      <textarea name="result" class="form-control" rows="8"><?= htmlspecialchars($lab['result'] ?? '') ?></textarea>
    </div>

    <div class="col-12">
      <button class="btn btn-primary">Save Changes</button>
      <a class="btn btn-secondary" href="requested.php">Back to Pending</a>
    </div>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
