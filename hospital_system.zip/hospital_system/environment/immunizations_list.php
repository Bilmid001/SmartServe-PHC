<?php 
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$stmt = $pdo->query("
  SELECT i.*, p.fullname, p.phone
  FROM immunizations i
  LEFT JOIN patients p ON i.patient_id = p.id
  ORDER BY i.given_at DESC
");

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Immunizations";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2>Immunizations</h2>
  <a class="btn btn-success mb-3" href="add_immunization.php">Add Immunization</a>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Date</th>
        <th>Patient</th>
        <th>Vaccine</th>
        <th>Dose</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['given_at']) ?></td>
          <td><?= htmlspecialchars($r['fullname'] ?? ('#'.$r['patient_id'])) ?></td>
          <td><?= htmlspecialchars($r['vaccine_name']) ?></td>
          <td><?= htmlspecialchars($r['dose_number']) ?></td>
          <td>
            <a class="btn btn-sm btn-primary" href="edit_immunization.php?id=<?= $r['id'] ?>">Edit</a>
            <a class="btn btn-sm btn-info" href="immunization_history.php?id=<?= $r['patient_id'] ?>">History</a>

            <form method="post" action="delete_immunization.php" style="display:inline" onsubmit="return confirm('Are you sure you want to delete this immunization?');">
              <input type="hidden" name="id" value="<?= $r['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
