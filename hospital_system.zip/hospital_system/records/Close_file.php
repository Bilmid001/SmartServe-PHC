<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$search = $_GET['search'] ?? '';

if ($search) {
    $like = "%$search%";
    $stmt = $pdo->prepare("
        SELECT id, fullname, gender, dob, phone, address, next_of_kin, nok_phone, fingerprint, status, created_at
        FROM patients
        WHERE fullname LIKE ? OR phone LIKE ? OR address LIKE ? OR next_of_kin LIKE ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$like, $like, $like, $like]);
} else {
    $stmt = $pdo->query("
        SELECT id, fullname, gender, dob, phone, address, next_of_kin, nok_phone, fingerprint, status, created_at
        FROM patients
        ORDER BY created_at DESC
    ");
}

$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Patient List";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-4">All Patients</h2>

  <!-- Search Form -->
  <form method="get" class="row mb-3">
    <div class="col-md-6">
      <input type="text" name="search" class="form-control" placeholder="Search by name, phone, address, or NOK..." value="<?= htmlspecialchars($search) ?>">
    </div>
    <div class="col-md-2">
      <button type="submit" class="btn btn-primary">Search</button>
    </div>
  </form>

  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Fullname</th>
        <th>Gender</th>
        <th>DOB</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Next of Kin</th>
        <th>NOK Phone</th>
        <th>Fingerprint</th>
        <th>Status</th>
        <th>Registered</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($patients as $p): ?>
        <tr>
          <td><?= htmlspecialchars($p['id']) ?></td>
          <td><?= htmlspecialchars($p['fullname']) ?></td>
          <td><?= htmlspecialchars($p['gender']) ?></td>
          <td><?= htmlspecialchars($p['dob']) ?></td>
          <td><?= htmlspecialchars($p['phone']) ?></td>
          <td><?= htmlspecialchars($p['address']) ?></td>
          <td><?= htmlspecialchars($p['next_of_kin']) ?></td>
          <td><?= htmlspecialchars($p['nok_phone']) ?></td>
          <td><?= htmlspecialchars($p['fingerprint']) ?></td>
          <td><?= htmlspecialchars($p['status']) ?></td>
          <td><?= htmlspecialchars($p['created_at']) ?></td>
          <td>
            <?php if ($p['status'] === 'open'): ?>
              <a href="close_patient.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-danger">Close File</a>
            <?php else: ?>
              <span class="badge bg-secondary">Closed</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($patients)): ?>
        <tr><td colspan="12" class="text-center">No patients found</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
