<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM environment_cases WHERE id=?");
$stmt->execute([$id]);
$case = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$case) die("Case not found.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $case_type = trim($_POST['case_type']);
    $desc = trim($_POST['description']);
    $status = $_POST['status'] ?? 'open';
    $pdo->prepare("UPDATE environment_cases SET case_type=?, description=?, status=?, updated_at=NOW() WHERE id=?")
        ->execute([$case_type, $desc, $status, $id]);
    header("Location: cases_list.php");
    exit;
}

$page_title = "Edit Case";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2>Edit Case</h2>
  <form method="post" class="row g-3">
    <div class="col-md-4">
      <label class="form-label">Case Type</label>
      <input name="case_type" class="form-control" value="<?= htmlspecialchars($case['case_type']) ?>" required>
    </div>
    <div class="col-md-4">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="open" <?= $case['status']==='open'?'selected':'' ?>>Open</option>
        <option value="closed" <?= $case['status']==='closed'?'selected':'' ?>>Closed</option>
      </select>
    </div>
    <div class="col-12">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control"><?= htmlspecialchars($case['description']) ?></textarea>
    </div>
    <div class="col-12"><button class="btn btn-primary">Save</button></div>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
