<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['admin','lab'])) {
    header("Location: ../error/403.php");
    exit;
}

$msg="";
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(isset($_POST['add'])){
        $stmt=$pdo->prepare("INSERT INTO lab_tests (name) VALUES (?)");
        $stmt->execute([$_POST['name']]);
        $msg="Test added.";
    }
}

$tests=$pdo->query("SELECT * FROM lab_tests")->fetchAll();

$page_title="Lab Test Catalog";
include __DIR__ . '/../includes/header.php';
?>
<h2>Manage Test Catalog</h2>
<?php if($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
<form method="post" class="mb-3">
  <input type="text" name="name" placeholder="Test Name" class="form-control mb-2" required>
  <button name="add" class="btn btn-primary">Add Test</button>
</form>
<table class="table table-striped">
<thead><tr><th>ID</th><th>Name</th></tr></thead>
<tbody>
<?php foreach($tests as $t): ?>
<tr><td><?= $t['id'] ?></td><td><?= htmlspecialchars($t['name']) ?></td></tr>
<?php endforeach; ?>
</tbody>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
