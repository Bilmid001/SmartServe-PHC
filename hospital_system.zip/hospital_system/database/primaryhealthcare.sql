-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2025 at 05:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `primaryhealthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `ai_logs`
--

CREATE TABLE `ai_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `task` varchar(100) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `input_hash` varchar(128) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `table_name`, `record_id`, `created_at`) VALUES
(1, 1, 'create_user:record', 'users', NULL, '2025-09-17 11:06:19'),
(2, 1, 'delete_user:2', 'users', 2, '2025-09-17 11:07:01'),
(3, 1, 'create_user:record', 'users', NULL, '2025-09-17 11:07:14'),
(4, 1, 'delete_user:2', 'users', 2, '2025-09-17 11:07:14'),
(5, NULL, 'create_user:pharmacy', 'users', NULL, '2025-09-17 11:35:43'),
(6, NULL, 'create_user:lab', 'users', NULL, '2025-09-17 11:41:46'),
(7, 1, 'delete_user:5', 'users', 5, '2025-09-17 11:42:41'),
(8, 1, 'create_user:laboratory', 'users', NULL, '2025-09-17 11:43:07'),
(9, 1, 'create_user:environment', 'users', NULL, '2025-09-17 11:47:26'),
(10, 1, 'create_user:doctor', 'users', NULL, '2025-09-17 11:58:25'),
(11, 1, 'delete_user:8', 'users', 8, '2025-09-17 11:58:50'),
(12, 1, 'create_user:doctor', 'users', NULL, '2025-09-17 11:59:00'),
(13, 1, 'delete_user:8', 'users', 8, '2025-09-17 11:59:01'),
(15, 1, 'create_user:Ahmad', 'users', NULL, '2025-09-17 12:30:38'),
(16, 1, 'delete_user:11', 'users', 11, '2025-09-17 12:30:44'),
(17, 1, 'create_user:Abdullahi Isa', 'users', NULL, '2025-09-18 09:15:26'),
(18, 1, 'delete_user:12', 'users', 12, '2025-09-18 09:15:30'),
(19, 1, 'delete_user:12', 'users', 12, '2025-09-18 14:52:46'),
(20, 1, 'create_user:admin111', 'users', NULL, '2025-09-18 15:12:07'),
(21, 1, 'delete_user:13', 'users', 13, '2025-09-18 15:12:11'),
(22, 1, 'delete_user:13', 'users', 13, '2025-09-18 15:14:29'),
(23, 1, 'delete_user:13', 'users', 13, '2025-09-18 15:14:38'),
(24, 1, 'delete_user:13', 'users', 13, '2025-09-18 15:14:46'),
(25, 1, 'delete_user:13', 'users', 13, '2025-09-18 15:15:02'),
(26, 1, 'delete_user:13', 'users', 13, '2025-09-18 15:15:08');

-- --------------------------------------------------------

--
-- Table structure for table `community_cases`
--

CREATE TABLE `community_cases` (
  `id` int(11) NOT NULL,
  `case_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `reported_at` date DEFAULT NULL,
  `reported_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `consultations`
--

CREATE TABLE `consultations` (
  `id` int(11) NOT NULL,
  `visit_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `patient_id` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `treatment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultations`
--

INSERT INTO `consultations` (`id`, `visit_id`, `doctor_id`, `diagnosis`, `notes`, `created_at`, `patient_id`, `status`, `treatment`) VALUES
(8, 10, 9, 'Malaria', 'Treated', '2025-09-19 04:20:10', 5, 'pending', 'Complete');

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE `drugs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `minimum_threshold` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drugs`
--

INSERT INTO `drugs` (`id`, `name`, `code`, `quantity`, `minimum_threshold`, `updated_at`) VALUES
(2, 'Amoxicillin 500mg', 'AMOX500', 150, 10, '2025-09-17 10:56:59'),
(3, 'Cipro', NULL, 2, 0, '2025-09-19 03:26:27');

-- --------------------------------------------------------

--
-- Table structure for table `environment_cases`
--

CREATE TABLE `environment_cases` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `status` enum('open','closed') NOT NULL,
  `case_details` text DEFAULT NULL,
  `date_reported` datetime DEFAULT current_timestamp(),
  `case_type` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `environment_cases`
--

INSERT INTO `environment_cases` (`id`, `patient_id`, `status`, `case_details`, `date_reported`, `case_type`, `description`, `updated_at`) VALUES
(1, 6, 'open', NULL, '2025-09-20 03:00:07', 'Pollution', 'Air', '2025-09-20 03:08:33');

-- --------------------------------------------------------

--
-- Table structure for table `immunizations`
--

CREATE TABLE `immunizations` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `vaccine_name` varchar(255) DEFAULT NULL,
  `given_at` date DEFAULT NULL,
  `given_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'pending',
  `dose_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `immunizations`
--

INSERT INTO `immunizations` (`id`, `patient_id`, `vaccine_name`, `given_at`, `given_by`, `created_at`, `status`, `dose_number`) VALUES
(2, 6, 'Apollo', '2025-09-19', 7, '2025-09-19 02:17:30', 'pending', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inspections`
--

CREATE TABLE `inspections` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `issue` text DEFAULT NULL,
  `action_taken` text DEFAULT NULL,
  `status` enum('open','closed') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `closed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_requests`
--

CREATE TABLE `lab_requests` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `test_name` varchar(150) NOT NULL,
  `result` text DEFAULT NULL,
  `status` enum('requested','completed') DEFAULT 'requested',
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_results`
--

CREATE TABLE `lab_results` (
  `id` int(11) NOT NULL,
  `consultation_id` int(11) NOT NULL,
  `test_type` varchar(255) DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `result` text DEFAULT NULL,
  `status` enum('pending','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `requested_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lab_results`
--

INSERT INTO `lab_results` (`id`, `consultation_id`, `test_type`, `test_id`, `result`, `status`, `created_at`, `completed_at`, `patient_id`, `requested_at`) VALUES
(1, 8, 'RDT', NULL, 'Positive', 'completed', '2025-09-19 04:23:22', NULL, 5, '2025-09-19 05:23:22'),
(2, 8, 'RDT', NULL, 'Positive', 'completed', '2025-09-19 04:53:06', NULL, 5, '2025-09-19 05:53:06');

-- --------------------------------------------------------

--
-- Table structure for table `lab_tests`
--

CREATE TABLE `lab_tests` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lab_tests`
--

INSERT INTO `lab_tests` (`id`, `name`, `code`, `description`, `created_at`) VALUES
(1, 'Complete Blood Count', 'CBC', 'Complete blood count with differential', '2025-09-17 10:56:59'),
(2, 'Malaria Rapid Test', 'MAL-RDT', 'Malaria rapid diagnostic test', '2025-09-17 10:56:59'),
(3, 'Malaria', NULL, NULL, '2025-09-17 11:57:22');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `fullname` varchar(100) NOT NULL,
  `gender` enum('male','female','other') DEFAULT 'other',
  `dob` date DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `next_of_kin` varchar(100) DEFAULT NULL,
  `nok_phone` varchar(20) DEFAULT NULL,
  `fingerprint` varchar(10) DEFAULT 'No',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'open',
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `first_name`, `last_name`, `fullname`, `gender`, `dob`, `phone`, `address`, `next_of_kin`, `nok_phone`, `fingerprint`, `notes`, `created_at`, `status`, `updated_at`) VALUES
(4, NULL, NULL, 'Ahmad Adam', '', '2002-12-02', '08044784652', 'Ganuwa', 'Ahmad Adamu Ganuwa', '09081366741', 'Yes', 'All', '2025-09-17 13:52:08', 'open', '2025-09-18 16:18:46'),
(5, NULL, NULL, 'Ahmad Abdulhamid', 'male', '2000-05-15', '08069715695', 'Ganuwa', 'Ahmad Adamu', '09081366741', 'Yes', 'All is well patient', '2025-09-17 13:53:49', 'open', '2025-09-18 16:18:46'),
(6, NULL, NULL, 'Attahir Abubakar', 'male', '1999-01-04', '0706986154', 'Keffi-South', 'Halima Aisha', '08163573551', 'No', '', '2025-09-18 15:20:00', 'closed', '2025-09-18 16:30:31');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy_dispenses`
--

CREATE TABLE `pharmacy_dispenses` (
  `id` int(11) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `qty` int(11) DEFAULT 1,
  `dispensed_by` int(11) DEFAULT NULL,
  `dispensed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL,
  `consultation_id` int(11) NOT NULL,
  `drug_name` varchar(255) DEFAULT NULL,
  `dosage` varchar(255) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `status` enum('pending','dispensed','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(4, 'Consultant', NULL),
(5, 'Medical Lab', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `key` varchar(100) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','records','doctor','lab','pharmacy','environment') NOT NULL DEFAULT 'records',
  `full_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `full_name`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$MSWRUtmbPwD3xtJDbDine.NCW8Z/ZbYVU0iAKCLwvFyhj1.a2Zvby', 'admin', 'System Administrator', 'admin@example.com', '2025-09-17 10:56:59'),
(4, 'pharmacy', '$2y$10$21AVno.GnTzqCA7g8VF.o.BSpGfyi8LKsSwKgNPyheJL/W4iGufsy', 'pharmacy', NULL, NULL, '2025-09-17 11:35:43'),
(6, 'laboratory', '$2y$10$B7yI7Cb/QzxqGTsw9hd1nuKve7Ke/pqGJB69/ijm4jA1cZVze.DcS', 'lab', NULL, NULL, '2025-09-17 11:43:07'),
(7, 'environment', '$2y$10$R8s6zS1g81KBiyK8/YENjegT27l28emTITlZJb4cwgs3WkNGixl5e', 'environment', NULL, NULL, '2025-09-17 11:47:26'),
(9, 'doctor', '$2y$10$vPb40LO8z.usMpFhtFtJNed8uVdGiF3FWfjWqJ.OmLfliZaNbGDMy', 'doctor', NULL, NULL, '2025-09-17 11:58:59'),
(10, 'record', '$2y$10$7tX5AxQk71w6DM7tb6q/AeQgUlEnXH6ZPr8BDfvXG833cUjboRYxK', 'records', NULL, NULL, '2025-09-17 12:22:03');

-- --------------------------------------------------------

--
-- Table structure for table `visits`
--

CREATE TABLE `visits` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `opened_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `closed_at` timestamp NULL DEFAULT NULL,
  `opened_by` int(11) DEFAULT NULL,
  `closed_by` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `status` enum('open','closed') DEFAULT 'open',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visits`
--

INSERT INTO `visits` (`id`, `patient_id`, `opened_at`, `closed_at`, `opened_by`, `closed_by`, `doctor_id`, `status`, `notes`, `created_at`) VALUES
(3, 5, '2025-09-17 15:11:15', '2025-09-17 14:14:51', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 04:20:05'),
(4, 5, '2025-09-17 15:14:57', '2025-09-17 14:14:59', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 04:20:05'),
(5, 4, '2025-09-17 15:15:00', '2025-09-17 14:15:01', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 04:20:05'),
(6, 5, '2025-09-17 15:19:21', '2025-09-18 15:30:09', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 04:20:05'),
(7, 6, '2025-09-18 15:30:01', '2025-09-18 15:30:11', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 04:20:05'),
(8, 6, '2025-09-18 16:30:18', '2025-09-18 15:31:53', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 04:20:05'),
(9, 6, '2025-09-18 16:30:18', '2025-09-19 14:13:15', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 04:20:05'),
(10, 5, '2025-09-19 04:20:10', '2025-09-19 14:13:42', NULL, NULL, 9, 'closed', NULL, '2025-09-19 04:20:10'),
(11, 6, '2025-09-19 15:13:33', '2025-09-19 14:13:41', NULL, NULL, NULL, 'closed', NULL, '2025-09-19 14:13:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ai_logs`
--
ALTER TABLE `ai_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `community_cases`
--
ALTER TABLE `community_cases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reported_by` (`reported_by`),
  ADD KEY `reported_at` (`reported_at`);

--
-- Indexes for table `consultations`
--
ALTER TABLE `consultations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `visit_id` (`visit_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `idx_consultations_created_at` (`created_at`);

--
-- Indexes for table `drugs`
--
ALTER TABLE `drugs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `quantity` (`quantity`);

--
-- Indexes for table `environment_cases`
--
ALTER TABLE `environment_cases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `immunizations`
--
ALTER TABLE `immunizations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `given_by` (`given_by`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `given_at` (`given_at`);

--
-- Indexes for table `inspections`
--
ALTER TABLE `inspections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `lab_requests`
--
ALTER TABLE `lab_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `lab_results`
--
ALTER TABLE `lab_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test_id` (`test_id`),
  ADD KEY `consultation_id` (`consultation_id`),
  ADD KEY `status` (`status`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `lab_tests`
--
ALTER TABLE `lab_tests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_patients_created_at` (`created_at`);

--
-- Indexes for table `pharmacy_dispenses`
--
ALTER TABLE `pharmacy_dispenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prescription_id` (`prescription_id`),
  ADD KEY `dispensed_by` (`dispensed_by`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `consultation_id` (`consultation_id`),
  ADD KEY `status` (`status`),
  ADD KEY `idx_prescriptions_created_at` (`created_at`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `visits`
--
ALTER TABLE `visits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `opened_by` (`opened_by`),
  ADD KEY `closed_by` (`closed_by`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `status` (`status`),
  ADD KEY `opened_at` (`opened_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ai_logs`
--
ALTER TABLE `ai_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `community_cases`
--
ALTER TABLE `community_cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `consultations`
--
ALTER TABLE `consultations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `drugs`
--
ALTER TABLE `drugs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `environment_cases`
--
ALTER TABLE `environment_cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `immunizations`
--
ALTER TABLE `immunizations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inspections`
--
ALTER TABLE `inspections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lab_requests`
--
ALTER TABLE `lab_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lab_results`
--
ALTER TABLE `lab_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lab_tests`
--
ALTER TABLE `lab_tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pharmacy_dispenses`
--
ALTER TABLE `pharmacy_dispenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `visits`
--
ALTER TABLE `visits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `community_cases`
--
ALTER TABLE `community_cases`
  ADD CONSTRAINT `community_cases_ibfk_1` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `consultations`
--
ALTER TABLE `consultations`
  ADD CONSTRAINT `consultations_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `consultations_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `immunizations`
--
ALTER TABLE `immunizations`
  ADD CONSTRAINT `immunizations_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `immunizations_ibfk_2` FOREIGN KEY (`given_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `inspections`
--
ALTER TABLE `inspections`
  ADD CONSTRAINT `inspections_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lab_requests`
--
ALTER TABLE `lab_requests`
  ADD CONSTRAINT `lab_requests_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lab_results`
--
ALTER TABLE `lab_results`
  ADD CONSTRAINT `lab_results_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lab_results_ibfk_2` FOREIGN KEY (`test_id`) REFERENCES `lab_tests` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `pharmacy_dispenses`
--
ALTER TABLE `pharmacy_dispenses`
  ADD CONSTRAINT `pharmacy_dispenses_ibfk_1` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pharmacy_dispenses_ibfk_2` FOREIGN KEY (`dispensed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD CONSTRAINT `prescriptions_ibfk_1` FOREIGN KEY (`consultation_id`) REFERENCES `consultations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `visits`
--
ALTER TABLE `visits`
  ADD CONSTRAINT `visits_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `visits_ibfk_2` FOREIGN KEY (`opened_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `visits_ibfk_3` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `visits_ibfk_4` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
