<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$stmt=$pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$_SESSION['user_id']]);
$doc=$stmt->fetch();

$page_title="My Profile";
include __DIR__ . '/../includes/header.php';
?>
<h2>My Profile</h2>
<ul class="list-group">
  <li class="list-group-item"><b>Name:</b> <?= htmlspecialchars($doc['full_name']) ?></li>
  <li class="list-group-item"><b>Email:</b> <?= htmlspecialchars($doc['email']) ?></li>
  <li class="list-group-item"><b>Role:</b> <?= htmlspecialchars($doc['role']) ?></li>
</ul>
<?php include __DIR__ . '/../includes/footer.php'; ?>
