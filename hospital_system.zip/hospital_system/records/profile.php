<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = $_GET['id'] ?? 0;
$stmt=$pdo->prepare("SELECT * FROM patients WHERE id=?");
$stmt->execute([$id]);
$patient=$stmt->fetch();

$page_title="Patient Profile";
include __DIR__ . '/../includes/header.php';
?>
<h2>Patient Profile</h2>
<?php if($patient): ?>
<ul class="list-group">
  <li class="list-group-item"><b>ID:</b> <?= $patient['id'] ?></li>
  <li class="list-group-item"><b>Name:</b> <?= htmlspecialchars($patient['first_name']." ".$patient['last_name']) ?></li>
  <li class="list-group-item"><b>Phone:</b> <?= htmlspecialchars($patient['phone']) ?></li>
  <li class="list-group-item"><b>DOB:</b> <?= htmlspecialchars($patient['dob']) ?></li>
</ul>
<?php else: ?>
<div class="alert alert-danger">Patient not found.</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
