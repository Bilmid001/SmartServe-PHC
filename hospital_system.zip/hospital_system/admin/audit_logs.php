<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';
if($_SESSION['role']!=='admin'){ header('Location: '.BASE_URL.'/error/403.php'); exit; }

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page-1)*$perPage;

$total = (int)$pdo->query("SELECT COUNT(*) FROM audit_logs")->fetchColumn();
$rows = $pdo->prepare("SELECT a.*, u.username FROM audit_logs a LEFT JOIN users u ON a.user_id=u.id ORDER BY a.id DESC LIMIT ? OFFSET ?");
$rows->execute([$perPage, $offset]);
$logs = $rows->fetchAll();

$page_title='Audit Logs';
include __DIR__ . '/../includes/header.php';
?>
<h2>Audit Logs</h2>
<p>Total records: <?= $total ?></p>
<table class="table table-sm"><thead><tr><th>ID</th><th>User</th><th>Action</th><th>Table</th><th>Record</th><th>When</th></tr></thead><tbody>
<?php foreach($logs as $l): ?>
<tr>
  <td><?= $l['id'] ?></td>
  <td><?= htmlspecialchars($l['username'] ?? 'system') ?></td>
  <td><?= htmlspecialchars($l['action']) ?></td>
  <td><?= htmlspecialchars($l['table_name']) ?></td>
  <td><?= htmlspecialchars($l['record_id']) ?></td>
  <td><?= $l['created_at'] ?></td>
</tr>
<?php endforeach; ?>
</tbody></table>

<?php
$totalPages = ceil($total / $perPage);
for($i=1;$i<=$totalPages;$i++){
  echo '<a href="?page='.$i.'" class="btn btn-sm '.($i==$page?'btn-primary':'btn-light').' mx-1">'.$i.'</a>';
}
include __DIR__ . '/../includes/footer.php';
?>
