<?php
// pharmacy/edit_prescription.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['pharmacy','doctor','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    header('Location: prescriptions.php');
    exit;
}

// load prescription + patient
$stmt = $pdo->prepare("SELECT pr.*, p.fullname, p.phone FROM prescriptions pr LEFT JOIN patients p ON pr.patient_id = p.id WHERE pr.id = ?");
$stmt->execute([$id]);
$presc = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$presc) die("Prescription not found.");

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine = trim($_POST['medicine'] ?? '');
    $dosage = trim($_POST['dosage'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $instructions = trim($_POST['instructions'] ?? '');
    $status = in_array($_POST['status'] ?? 'pending', ['pending','active','dispensed','cancelled']) ? $_POST['status'] : 'pending';

    $upd = $pdo->prepare("UPDATE prescriptions SET medicine=:medicine, dosage=:dosage, quantity=:quantity, instructions=:instructions, status=:status, updated_at=NOW() WHERE id=:id");
    $upd->execute([
        ':medicine' => $medicine,
        ':dosage' => $dosage ?: null,
        ':quantity' => $quantity ?: null,
        ':instructions' => $instructions ?: null,
        ':status' => $status,
        ':id' => $id
    ]);
    $msg = "Prescription updated.";
    // reload
    $stmt->execute([$id]);
    $presc = $stmt->fetch(PDO::FETCH_ASSOC);
}

$page_title = "Edit Prescription";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-3">Edit Prescription</h2>
  <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <div class="card mb-3 p-3">
    <h5><?= htmlspecialchars($presc['fullname'] ?? 'Unknown') ?> <small class="text-muted">#<?= $presc['patient_id'] ?></small></h5>
    <div class="small text-muted">Prescribed at: <?= htmlspecialchars($presc['created_at']) ?></div>
  </div>

  <form method="post" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Medicine</label>
      <input name="medicine" class="form-control" value="<?= htmlspecialchars($presc['medicine']) ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Dosage</label>
      <input name="dosage" class="form-control" value="<?= htmlspecialchars($presc['dosage']) ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Quantity</label>
      <input name="quantity" type="number" class="form-control" value="<?= htmlspecialchars($presc['quantity']) ?>">
    </div>
    <div class="col-12">
      <label class="form-label">Instructions</label>
      <textarea name="instructions" class="form-control"><?= htmlspecialchars($presc['instructions']) ?></textarea>
    </div>
    <div class="col-md-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="pending" <?= $presc['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="active" <?= $presc['status'] === 'active' ? 'selected' : '' ?>>Active</option>
        <option value="dispensed" <?= $presc['status'] === 'dispensed' ? 'selected' : '' ?>>Dispensed</option>
        <option value="cancelled" <?= $presc['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
      </select>
    </div>
    <div class="col-12">
      <button class="btn btn-primary">Save</button>
      <a class="btn btn-secondary" href="prescriptions.php">Back</a>
    </div>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
