<?php
require_once __DIR__ . '/../includes/patient_helpers.php';
$patient_id = (int)($_GET['patient_id'] ?? 0);
if (!$patient_id) { die("Missing patient_id"); }
require_patient_file_open_or_die($patient_id);

require_once __DIR__ . '/../includes/patient_helpers.php';
require_once __DIR__ . '/../config.php';
$pdo = db_connect();

$patient_id = (int)($_GET['patient_id'] ?? 0);
if (!$patient_id) { die("Missing patient_id"); }

// fetch patient
$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->execute([$patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$patient) { die("Patient not found"); }

$timeline = get_patient_timeline($patient_id, 500);
?>
<?php include '../includes/header.php'; ?>
<div class="container mt-4">
  <h2>Patient Profile</h2>
  <div class="card mb-3">
    <div class="card-body">
      <h4><?= htmlspecialchars($patient['fullname']) ?></h4>
      <p>
        <b>DOB:</b> <?= htmlspecialchars($patient['dob']) ?> |
        <b>Phone:</b> <?= htmlspecialchars($patient['phone']) ?> |
        <b>Status:</b>
        <span class="badge bg-<?= $patient['file_status']=='open'?'success':'danger' ?>">
          <?= htmlspecialchars($patient['file_status']) ?>
        </span>
      </p>
    </div>
  </div>

  <h4>Timeline</h4>
  <table class="table table-striped">
    <thead><tr><th>Date</th><th>Type</th><th>Summary</th><th>Details</th></tr></thead>
    <tbody>
      <?php foreach ($timeline as $row): ?>
        <tr>
          <td><?= htmlspecialchars($row['event_date']) ?></td>
          <td><?= htmlspecialchars($row['event_type']) ?></td>
          <td><?= htmlspecialchars($row['summary']) ?></td>
          <td><pre><?= htmlspecialchars($row['details']) ?></pre></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include '../includes/footer.php'; ?>
