<?php
// environment/dashboard.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['environment','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

// totals
$total_cases = $pdo->query("SELECT COUNT(*) FROM environment_cases")->fetchColumn();
$open_cases = $pdo->query("SELECT COUNT(*) FROM environment_cases WHERE status='open'")->fetchColumn();
$closed_cases = $pdo->query("SELECT COUNT(*) FROM environment_cases WHERE status='closed'")->fetchColumn();

$total_immunizations = $pdo->query("SELECT COUNT(*) FROM immunizations")->fetchColumn();

// Get recent environmental cases
$recent_cases = $pdo->query("
    SELECT ec.*, p.first_name, p.last_name 
    FROM environment_cases ec 
    LEFT JOIN patients p ON ec.patient_id = p.id 
    ORDER BY ec.created_at DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Get case type distribution
$case_types = $pdo->query("
    SELECT case_type, COUNT(*) as count 
    FROM environment_cases 
    GROUP BY case_type 
    ORDER BY count DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Get immunization status
$immunization_status = $pdo->query("
    SELECT status, COUNT(*) as count 
    FROM immunizations 
    GROUP BY status
")->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Environment Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
  :root {
    --primary: #4361ee;
    --secondary: #3f37c9;
    --success: #4cc9f0;
    --info: #4895ef;
    --warning: #f72585;
    --danger: #e63946;
    --light: #f8f9fa;
    --dark: #212529;
    --environment-gradient: linear-gradient(120deg, #0ba360 0%, #3cba92 100%);
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    --hover-shadow: 0 14px 28px rgba(0, 0, 0, 0.25);
  }

  body {
    background-color: #f5f7fb;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .dashboard-header {
    background: var(--environment-gradient);
    padding: 2rem 0;
    margin-bottom: 2rem;
    border-radius: 0 0 20px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .ai-btn {
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    border: none;
    color: white;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(38, 132, 255, 0.4);
    transition: all 0.3s ease;
    border-radius: 50px;
    padding: 12px 25px;
  }

  .ai-btn:hover {
    background: linear-gradient(90deg, #2575fc, #6a11cb);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(38, 132, 255, 0.6);
  }

  .card {
    border: none;
    border-radius: 15px;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    margin-bottom: 1.5rem;
    overflow: hidden;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
  }

  .stat-card {
    padding: 1.5rem;
    color: white;
    border-radius: 15px;
    text-align: center;
    height: 100%;
  }

  .stat-card h5 {
    font-size: 1rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
  }

  .stat-card .number {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0;
  }

  .chart-container {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    margin-bottom: 1.5rem;
    height: 100%;
  }

  .chart-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
    text-align: center;
  }

  .activity-card {
    padding: 1.5rem;
  }

  .activity-card h5 {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .activity-item {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid #edf2f7;
    transition: background-color 0.2s;
  }

  .activity-item:hover {
    background-color: #f8fafc;
  }

  .activity-item:last-child {
    border-bottom: none;
  }

  .activity-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
    flex-shrink: 0;
  }

  .activity-content {
    flex-grow: 1;
  }

  .activity-title {
    font-weight: 600;
    color: #2d3748;
  }

  .activity-details {
    color: #4a5568;
    font-size: 0.9rem;
  }

  .activity-time {
    color: #718096;
    font-size: 0.8rem;
    text-align: right;
  }

  .quick-links-card {
    padding: 1.5rem;
  }

  .quick-links-card h5 {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .quick-link-item {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid #edf2f7;
    transition: background-color 0.2s;
    text-decoration: none;
    color: inherit;
  }

  .quick-link-item:hover {
    background-color: #f8fafc;
    color: inherit;
    text-decoration: none;
  }

  .quick-link-item:last-child {
    border-bottom: none;
  }

  .quick-link-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
    flex-shrink: 0;
    background-color: rgba(11, 163, 96, 0.2);
  }

  .quick-link-icon svg {
    fill: #0ba360;
  }

  .status-badge {
    padding: 0.35rem 0.65rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
  }

  @media (max-width: 768px) {
    .stat-card .number {
      font-size: 2rem;
    }
    
    .activity-item {
      flex-direction: column;
      align-items: flex-start;
    }
    
    .activity-time {
      margin-top: 0.5rem;
      text-align: left;
    }
  }
</style>

<div class="dashboard-header">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
      <div>
        <h2 class="text-white fw-bold mb-2">🌍 Environment Dashboard</h2>
        <p class="text-white mb-4">
          Welcome to the Environmental Health Dashboard! Monitor cases, track immunizations, and ensure community health safety.
        </p>
      </div>
      
      <!-- AI Assistant Button -->
      <a href="../aiphc.php" class="btn ai-btn px-4 py-3 d-flex align-items-center gap-2" role="button">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-robot" viewBox="0 0 16 16">
          <path d="M5 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM9 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0z"/>
          <path d="M2 8v1h12V8H2zm12-1V6H2v1h12zM1 10v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H1z"/>
        </svg>
        Smart Serve AI Assistant
      </a>
    </div>
  </div>
</div>

<div class="container my-5">
  <div class="row">
    <!-- Stats Cards -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #0ba360, #3cba92);">
        <h5>Total Cases</h5>
        <p class="number"><?= $total_cases ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">All Cases</span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #ff6b6b, #ff9e7d);">
        <h5>Open Cases</h5>
        <p class="number"><?= $open_cases ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-warning text-dark">Needs Attention</span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #7474BF, #348AC7);">
        <h5>Closed Cases</h5>
        <p class="number"><?= $closed_cases ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">Resolved</span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #4facfe, #00f2fe);">
        <h5>Immunizations</h5>
        <p class="number"><?= $total_immunizations ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">Total Administered</span>
        </div>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Case Type Distribution Chart -->
    <div class="col-lg-6 mb-4">
      <div class="chart-container">
        <h5 class="chart-title">Environmental Case Types</h5>
        <canvas id="caseTypeChart"></canvas>
      </div>
    </div>

    <!-- Immunization Status Chart -->
    <div class="col-lg-6 mb-4">
      <div class="chart-container">
        <h5 class="chart-title">Immunization Status</h5>
        <canvas id="immunizationChart"></canvas>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Recent Cases -->
    <div class="col-lg-7 mb-4">
      <div class="card activity-card">
        <h5>Recent Environmental Cases</h5>
        
        <?php if (count($recent_cases) > 0): ?>
          <?php foreach ($recent_cases as $case): ?>
            <div class="activity-item">
              <div class="activity-icon" style="background-color: rgba(11, 163, 96, 0.2);">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#0ba360" class="bi bi-tree" viewBox="0 0 16 16">
                  <path d="M8.416.223a.5.5 0 0 0-.832 0l-3 4.5A.5.5 0 0 0 5 5.5h.098L3.076 8.735A.5.5 0 0 0 3.5 9.5h.191l-1.638 3.276a.5.5 0 0 0 .447.724H7V16h2v-2.5h4.5a.5.5 0 0 0 .447-.724L12.31 9.5h.191a.5.5 0 0 0 .424-.765L10.902 5.5H11a.5.5 0 0 0 .416-.777l-3-4.5zM6.437 4.758A.5.5 0 0 0 6 4.5h-.066L8 1.401 10.066 4.5H10a.5.5 0 0 0-.424.765L11.598 8.5H11.5a.5.5 0 0 0-.447.724L12.38 12.5H3.619l1.327-2.276A.5.5 0 0 0 4.5 9.5h-.098l2.022-3.235a.5.5 0 0 0 .013-.507z"/>
                </svg>
              </div>
              <div class="activity-content">
                <div class="activity-title"><?= htmlspecialchars($case['case_type']) ?></div>
                <div class="activity-details">
                  <?php if ($case['patient_id']): ?>
                    Patient: <?= htmlspecialchars($case['first_name'] . ' ' . $case['last_name']) ?>
                  <?php else: ?>
                    Community Case
                  <?php endif; ?>
                </div>
              </div>
              <div class="activity-time">
                <?php 
                  $date = new DateTime($case['created_at']);
                  echo $date->format('M j, Y');
                ?>
                <br>
                <span class="status-badge <?= $case['status'] == 'closed' ? 'bg-success' : 'bg-warning' ?>">
                  <?= ucfirst($case['status']) ?>
                </span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-muted">No recent environmental cases</p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Quick Links -->
    <div class="col-lg-5 mb-4">
      <div class="card quick-links-card">
        <h5>Quick Actions</h5>
        
        <a href="cases_list.php" class="quick-link-item">
          <div class="quick-link-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list-check" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM3.854 2.146a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708L2 3.293l1.146-1.147a.5.5 0 0 1 .708 0zm0 4a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708L2 7.293l1.146-1.147a.5.5 0 0 1 .708 0zm0 4a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z"/>
            </svg>
          </div>
          <div>
            <div class="activity-title">Manage Cases</div>
            <div class="activity-details">View and manage environmental cases</div>
          </div>
        </a>
        
        <a href="add_case.php" class="quick-link-item">
          <div class="quick-link-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle" viewBox="0 0 16 16">
              <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
              <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
            </svg>
          </div>
          <div>
            <div class="activity-title">Add New Case</div>
            <div class="activity-details">Create a new environmental case</div>
          </div>
        </a>
        
        <a href="immunizations_list.php" class="quick-link-item">
          <div class="quick-link-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-shield-plus" viewBox="0 0 16 16">
              <path d="M5.338 1.59a61.44 61.44 0 0 0-2.837.856.481.481 0 0 0-.328.39c-.554 4.157.726 7.19 2.253 9.188a10.725 10.725 0 0 0 2.287 2.233c.346.244.652.42.893.533.12.057.218.095.293.118a.55.55 0 0 0 .101.025.615.615 0 0 0 .1-.025c.076-.023.174-.061.294-.118.24-.113.547-.29.893-.533a10.726 10.726 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067c-.53 0-1.552.223-2.662.524zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.775 11.775 0 0 1-2.517 2.453 7.159 7.159 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7.158 7.158 0 0 1-1.048-.625 11.777 11.777 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 62.456 62.456 0 0 1 5.072.56z"/>
              <path d="M8 4.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V9a.5.5 0 0 1-1 0V7.5H6a.5.5 0 0 1 0-1h1.5V5a.5.5 0 0 1 .5-.5z"/>
            </svg>
          </div>
          <div>
            <div class="activity-title">Manage Immunizations</div>
            <div class="activity-details">View and manage immunization records</div>
          </div>
        </a>
        
        <a href="add_immunization.php" class="quick-link-item">
          <div class="quick-link-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-medical" viewBox="0 0 16 16">
              <path d="M8.5 4.5a.5.5 0 0 0-1 0v.634l-.549-.317a.5.5 0 1 0-.5.866L7 6l-.549.317a.5.5 0 1 0 .5.866l.549-.317V7.5a.5.5 0 1 0 1 0v-.634l.549.317a.5.5 0 1 0 .5-.866L9 6l.549-.317a.5.5 0 1 0-.5-.866l-.549.317V4.5zM5.5 9a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5zm0 2a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"/>
              <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1z"/>
            </svg>
          </div>
          <div>
            <div class="activity-title">Add Immunization</div>
            <div class="activity-details">Record a new immunization</div>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Case Type Distribution Chart
    const caseTypeCtx = document.getElementById('caseTypeChart').getContext('2d');
    new Chart(caseTypeCtx, {
      type: 'bar',
      data: {
        labels: [<?php foreach($case_types as $type): ?>'<?= $type['case_type'] ?>', <?php endforeach; ?>],
        datasets: [{
          label: 'Number of Cases',
          data: [<?php foreach($case_types as $type): ?><?= $type['count'] ?>, <?php endforeach; ?>],
          backgroundColor: [
            '#0ba360', '#ff6b6b', '#7474BF', '#4facfe', '#ff9e7d'
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      }
    });

    // Immunization Status Chart
    const immunizationCtx = document.getElementById('immunizationChart').getContext('2d');
    new Chart(immunizationCtx, {
      type: 'doughnut',
      data: {
        labels: [<?php foreach($immunization_status as $status): ?>'<?= ucfirst($status['status']) ?>', <?php endforeach; ?>],
        datasets: [{
          data: [<?php foreach($immunization_status as $status): ?><?= $status['count'] ?>, <?php endforeach; ?>],
          backgroundColor: [
            '#0ba360', '#ff6b6b', '#7474BF', '#4facfe'
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>