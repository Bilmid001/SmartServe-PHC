<?php
// includes/auth_check.php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    // Not logged in
    header("Location: " . BASE_URL . "auth/login.php");
    exit();
}

// Optional: restrict access by role
function require_role($roles) {
    if (!in_array($_SESSION['role'], (array)$roles)) {
        header("Location: " . BASE_URL . "error/403.php");
        exit();
    }
}
