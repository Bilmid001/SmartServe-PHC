<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$stmt = $pdo->query("
    SELECT cc.*, p.first_name, p.last_name
    FROM community_cases cc
    LEFT JOIN patients p ON cc.patient_id = p.id
    ORDER BY cc.reported_at DESC
");
$cases = $stmt->fetchAll();

$page_title="Community Cases";
include __DIR__ . '/../includes/header.php';
?>
<h2>Community Cases</h2>
<table class="table">
  <thead><tr><th>Case Type</th><th>Description</th><th>Date</th><th>Patient</th></tr></thead>
  <tbody>
  <?php foreach($cases as $c): ?>
    <tr>
      <td><?= htmlspecialchars($c['case_type']) ?></td>
      <td><?= htmlspecialchars($c['description']) ?></td>
      <td><?= htmlspecialchars($c['reported_at']) ?></td>
      <td><?= $c['first_name'] ? htmlspecialchars($c['first_name'].' '.$c['last_name']) : 'General case' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
