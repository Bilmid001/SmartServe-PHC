<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['pharmacy','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$total_patients = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
$pending_prescriptions = $pdo->query("SELECT COUNT(*) FROM prescriptions WHERE status='pending'")->fetchColumn();
$dispensed = $pdo->query("SELECT COUNT(*) FROM prescriptions WHERE status='dispensed'")->fetchColumn();

// Get recent prescriptions for the activity feed
$recent_prescriptions = $pdo->query("
    SELECT p.*, pt.first_name, pt.last_name
    FROM prescriptions p
    JOIN consultations c ON p.consultation_id = c.id
    JOIN patients pt ON c.patient_id = pt.id
    ORDER BY p.created_at DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// Get medication type distribution for the chart
$medication_types = $pdo->query("
    SELECT drug_name, COUNT(*) as count
    FROM prescriptions
    GROUP BY drug_name
    ORDER BY count DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Pharmacy Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
  :root {
    --primary: #4361ee;
    --secondary: #3f37c9;
    --success: #4cc9f0;
    --info: #4895ef;
    --warning: #f72585;
    --danger: #e63946;
    --light: #f8f9fa;
    --dark: #212529;
    --pharmacy-gradient: linear-gradient(120deg, #6a11cb 0%, #2575fc 100%);
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    --hover-shadow: 0 14px 28px rgba(0, 0, 0, 0.25);
  }

  body {
    background-color: #f5f7fb;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .dashboard-header {
    background: var(--pharmacy-gradient);
    padding: 2rem 0;
    margin-bottom: 2rem;
    border-radius: 0 0 20px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .ai-btn {
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    border: none;
    color: white;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(38, 132, 255, 0.4);
    transition: all 0.3s ease;
    border-radius: 50px;
    padding: 12px 25px;
  }

  .ai-btn:hover {
    background: linear-gradient(90deg, #2575fc, #6a11cb);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(38, 132, 255, 0.6);
  }

  .card {
    border: none;
    border-radius: 15px;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    margin-bottom: 1.5rem;
    overflow: hidden;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
  }

  .stat-card {
    padding: 1.5rem;
    color: white;
    border-radius: 15px;
    text-align: center;
    height: 100%;
  }

  .stat-card h5 {
    font-size: 1rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
  }

  .stat-card .number {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0;
  }

  .chart-container {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    margin-bottom: 1.5rem;
    height: 100%;
  }

  .chart-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
    text-align: center;
  }

  .activity-card {
    padding: 1.5rem;
  }

  .activity-card h5 {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .activity-item {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid #edf2f7;
    transition: background-color 0.2s;
  }

  .activity-item:hover {
    background-color: #f8fafc;
  }

  .activity-item:last-child {
    border-bottom: none;
  }

  .activity-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
    flex-shrink: 0;
  }

  .activity-content {
    flex-grow: 1;
  }

  .activity-patient {
    font-weight: 600;
    color: #2d3748;
  }

  .activity-medication {
    color: #4a5568;
    font-size: 0.9rem;
  }

  .activity-time {
    color: #718096;
    font-size: 0.8rem;
    text-align: right;
  }

  .search-section {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: var(--card-shadow);
  }

  .search-title {
    font-size: 1.3rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .status-badge {
    padding: 0.35rem 0.65rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
  }

  .urgent-badge {
    background-color: #fee2e2;
    color: #dc2626;
  }

  @media (max-width: 768px) {
    .stat-card .number {
      font-size: 2rem;
    }
    
    .activity-item {
      flex-direction: column;
      align-items: flex-start;
    }
    
    .activity-time {
      margin-top: 0.5rem;
      text-align: left;
    }
  }
</style>

<div class="dashboard-header">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
      <div>
        <h2 class="text-white fw-bold mb-2">Pharmacy Dashboard</h2>
        <p class="text-white mb-4">
          Welcome to the Pharmacy Dashboard! Manage prescriptions, track inventory, and serve patients efficiently.
        </p>
      </div>
      
      <!-- AI Assistant Button -->
      <a href="../aiphc.php" class="btn ai-btn px-4 py-3 d-flex align-items-center gap-2" role="button">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-robot" viewBox="0 0 16 16">
          <path d="M5 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM9 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0z"/>
          <path d="M2 8v1h12V8H2zm12-1V6H2v1h12zM1 10v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H1z"/>
        </svg>
        Smart Serve AI Assistant
      </a>
    </div>
  </div>
</div>

<div class="container my-5">
  <div class="row">
    <!-- Stats Cards -->
    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #6a11cb, #2575fc);">
        <h5>Total Patients</h5>
        <p class="number"><?= $total_patients ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">All Time</span>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #ff6b6b, #ff9e7d);">
        <h5>Pending Prescriptions</h5>
        <p class="number"><?= $pending_prescriptions ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-warning text-dark">Needs Attention</span>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #1dd1a1, #10ac84);">
        <h5>Dispensed Prescriptions</h5>
        <p class="number"><?= $dispensed ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">Processed</span>
        </div>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Medication Distribution Chart -->
    <div class="col-lg-6 mb-4">
      <div class="chart-container">
        <h5 class="chart-title">Most Prescribed Medications</h5>
        <canvas id="medicationChart"></canvas>
      </div>
    </div>

    <!-- Recent Activity -->
    <div class="col-lg-6 mb-4">
      <div class="card activity-card">
        <h5>Recent Prescription Requests</h5>
        
        <?php if (count($recent_prescriptions) > 0): ?>
          <?php foreach ($recent_prescriptions as $prescription): ?>
            <div class="activity-item">
              <div class="activity-icon" style="background-color: rgba(29, 209, 161, 0.2);">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#1dd1a1" class="bi bi-capsule" viewBox="0 0 16 16">
                  <path d="M3.5 8.5a5 5 0 0 1 5-5h1a5 5 0 0 1 5 5v1a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5v-1Z"/>
                  <path d="M8.5 3.5a5 5 0 0 1 5 5v1a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5v-1a5 5 0 0 1 5-5h1Z"/>
                </svg>
              </div>
              <div class="activity-content">
                <div class="activity-patient"><?= htmlspecialchars($prescription['first_name'] . ' ' . $prescription['last_name']) ?></div>
                <div class="activity-medication"><?= htmlspecialchars($prescription['medication']) ?></div>
              </div>
              <div class="activity-time">
                <?php 
                  $date = new DateTime($prescription['created_at']);
                  echo $date->format('M j, Y');
                ?>
                <br>
                <span class="status-badge <?= $prescription['status'] == 'dispensed' ? 'bg-success' : 'bg-warning' ?>">
                  <?= ucfirst($prescription['status']) ?>
                </span>
                <?php if ($prescription['is_urgent']): ?>
                  <span class="status-badge urgent-badge">Urgent</span>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-muted">No recent prescription requests</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Quick Actions -->
  <div class="row mt-4">
    <div class="col-md-4 mb-4">
      <div class="card text-center h-100">
        <div class="card-body">
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#6a11cb" class="bi bi-search-heart" viewBox="0 0 16 16">
              <path d="M6.5 4.482c1.664-1.673 5.825 1.254 0 5.018-5.825-3.764-1.664-6.69 0-5.018Z"/>
              <path d="M13 6.5a6.471 6.471 0 0 1-1.258 3.844c.04.03.078.062.115.098l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1.007 1.007 0 0 1-.1-.115h.002A6.5 6.5 0 1 1 13 6.5ZM6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11Z"/>
            </svg>
          </div>
          <h5>Check Inventory</h5>
          <p class="text-muted">View current stock levels and medication availability</p>
          <a href="<?= BASE_URL ?>/pharmacy/inventory.php" class="btn btn-outline-primary">View Inventory</a>
        </div>
      </div>
    </div>
    
    <div class="col-md-4 mb-4">
      <div class="card text-center h-100">
        <div class="card-body">
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#6a11cb" class="bi bi-file-medical" viewBox="0 0 16 16">
              <path d="M8.5 4.5a.5.5 0 0 0-1 0v.634l-.549-.317a.5.5 0 1 0-.5.866L7 6l-.549.317a.5.5 0 1 0 .5.866l.549-.317V7.5a.5.5 0 1 0 1 0v-.634l.549.317a.5.5 0 1 0 .5-.866L9 6l.549-.317a.5.5 0 1 0-.5-.866l-.549.317V4.5zM5.5 9a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5zm0 2a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"/>
              <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1z"/>
            </svg>
          </div>
          <h5>Pending Prescriptions</h5>
          <p class="text-muted">Review and process waiting prescription requests</p>
          <a href="<?= BASE_URL ?>/pharmacy/prescriptions.php?status=pending" class="btn btn-outline-primary">View Pending</a>
        </div>
      </div>
    </div>
    
    <div class="col-md-4 mb-4">
      <div class="card text-center h-100">
        <div class="card-body">
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#6a11cb" class="bi bi-clock-history" viewBox="0 0 16 16">
              <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022l-.074.997zm2.004.45a7.003 7.003 0 0 0-.985-.299l.219-.976c.383.086.76.2 1.126.342l-.36.933zm1.37.71a7.01 7.01 0 0 0-.439-.27l.493-.87a8.025 8.025 0 0 1 .979.654l-.615.789a6.996 6.996 0 0 0-.418-.302zm1.834 1.79a6.99 6.99 0 0 0-.653-.796l.724-.69c.27.285.52.59.747.91l-.818.576zm.744 1.352a7.08 7.08 0 0 0-.214-.468l.893-.45a7.976 7.976 0 0 1 .45 1.088l-.95.313a7.023 7.023 0 0 0-.179-.483zm.53 2.507a6.991 6.991 0 0 0-.1-1.025l.985-.17c.067.386.106.778.116 1.17l-1 .025zm-.131 1.538c.033-.17.06-.339.081-.51l.993.123a7.957 7.957 0 0 1-.23 1.155l-.964-.267c.046-.165.086-.332.12-.501zm-.952 2.379c.184-.29.346-.594.486-.908l.914.405c-.16.36-.345.706-.555 1.038l-.845-.535zm-.964 1.205c.122-.122.239-.248.35-.378l.758.653a8.073 8.073 0 0 1-.401.432l-.707-.707z"/>
              <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0v1z"/>
              <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5z"/>
            </svg>
          </div>
          <h5>Dispensation History</h5>
          <p class="text-muted">View records of previously dispensed medications</p>
          <a href="<?= BASE_URL ?>/pharmacy/history.php" class="btn btn-outline-primary">View History</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Search Section -->
  <div class="row mt-4">
    <div class="col-12">
      <div class="search-section">
        <h4 class="search-title">Find Patient</h4>
        <form method="get" action="<?= BASE_URL ?>/records/search.php" class="row g-3">
          <div class="col-md-8">
            <input type="text" name="q" class="form-control form-control-lg" placeholder="Enter Patient ID, Name, or Phone Number">
          </div>
          <div class="col-md-4">
            <button type="submit" class="btn btn-primary btn-lg w-100">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search me-2" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
              Search Patient
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Medication Distribution Chart
    const medicationCtx = document.getElementById('medicationChart').getContext('2d');
    new Chart(medicationCtx, {
      type: 'bar',
      data: {
        labels: [<?php foreach($medication_types as $type): ?>'<?= $type['medication'] ?>', <?php endforeach; ?>],
        datasets: [{
          label: 'Number of Prescriptions',
          data: [<?php foreach($medication_types as $type): ?><?= $type['count'] ?>, <?php endforeach; ?>],
          backgroundColor: [
            '#6a11cb', '#2575fc', '#1dd1a1', '#ff6b6b', '#ff9e7d'
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      }
    });
  });
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>