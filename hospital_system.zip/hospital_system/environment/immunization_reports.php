<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT p.*, i.vaccine_name, i.given_at
    FROM patients p
    LEFT JOIN immunizations i ON p.id = i.patient_id
    WHERE p.id = ?
    ORDER BY i.given_at DESC
");
$stmt->execute([$id]);
$history = $stmt->fetchAll();

$page_title="Immunization History";
include __DIR__ . '/../includes/header.php';
?>
<h2>Immunization History</h2>
<table class="table">
  <thead><tr><th>Vaccine</th><th>Date</th></tr></thead>
  <tbody>
  <?php foreach($history as $row): ?>
    <tr>
      <td><?= htmlspecialchars($row['vaccine_name'] ?? '-') ?></td>
      <td><?= htmlspecialchars($row['given_at'] ?? '-') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
