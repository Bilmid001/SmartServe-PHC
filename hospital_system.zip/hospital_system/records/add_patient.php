<?php
// records/add_patient.php

require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$page_title = "Add Patient";
include __DIR__ . '/../includes/header.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname    = trim($_POST['fullname'] ?? '');
    $gender      = trim($_POST['gender'] ?? '');
    $dob         = trim($_POST['dob'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $address     = trim($_POST['address'] ?? '');
    $nok         = trim($_POST['nok'] ?? '');
    $nok_phone   = trim($_POST['nok_phone'] ?? '');
    $fingerprint = isset($_POST['fingerprint']) && $_POST['fingerprint'] === 'Yes' ? 'Yes' : 'No';
    $notes       = trim($_POST['notes'] ?? '');
    $status      = 'open'; // default status

    // Basic validation
    if (empty($fullname) || empty($gender) || empty($dob) || empty($phone)) {
        $message = "<div class='alert alert-warning'>❗ Please fill in all required fields.</div>";
    } else {
        // Prepare and execute insert
        $sql = "INSERT INTO patients 
                (fullname, gender, dob, phone, address, next_of_kin, nok_phone, fingerprint, notes, status, created_at)
                VALUES 
                (:fullname, :gender, :dob, :phone, :address, :nok, :nok_phone, :fingerprint, :notes, :status, NOW())";

        $stmt = $pdo->prepare($sql);

        $params = [
            ':fullname'    => $fullname,
            ':gender'      => $gender,
            ':dob'         => $dob,
            ':phone'       => $phone,
            ':address'     => $address,
            ':nok'         => $nok,
            ':nok_phone'   => $nok_phone,
            ':fingerprint' => $fingerprint,
            ':notes'       => $notes,
            ':status'      => $status,
        ];

        if ($stmt->execute($params)) {
            $message = "<div class='alert alert-success'>✅ Patient registered successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>❌ Error: Failed to register patient.</div>";
        }
    }
}
?>

<div class="container">
  <h2 class="mb-4">Register New Patient</h2>
  <?= $message ?>

  <form method="post" class="row g-3" novalidate>
    <div class="col-md-6">
      <label class="form-label" for="fullname">Full Name</label>
      <input type="text" id="fullname" name="fullname" class="form-control" required>
    </div>
    <div class="col-md-3">
      <label class="form-label" for="gender">Gender</label>
      <select id="gender" name="gender" class="form-select" required>
        <option value="">-- Select --</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="other">Other</option>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label" for="dob">Date of Birth</label>
      <input type="date" id="dob" name="dob" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label" for="phone">Phone Number</label>
      <input type="text" id="phone" name="phone" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label" for="address">Address</label>
      <input type="text" id="address" name="address" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label" for="nok">Next of Kin</label>
      <input type="text" id="nok" name="nok" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label" for="nok_phone">Next of Kin Phone</label>
      <input type="text" id="nok_phone" name="nok_phone" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Fingerprint (Simulated)</label><br>
      <input type="checkbox" id="fingerprint" name="fingerprint" value="Yes">
      <label for="fingerprint">Captured</label>
    </div>
    <div class="col-md-12">
      <label class="form-label" for="notes">Notes</label>
      <textarea id="notes" name="notes" class="form-control" rows="3"></textarea>
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Register Patient</button>
    </div>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
