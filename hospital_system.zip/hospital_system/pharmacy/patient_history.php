<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT p.*, pr.id AS prescription_id, pr.drug_name, pr.status, pr.created_at
    FROM patients p
    LEFT JOIN consultations c ON p.id = c.patient_id
    LEFT JOIN prescriptions pr ON c.id = pr.consultation_id
    WHERE p.id = ?
    ORDER BY pr.created_at DESC
");
$stmt->execute([$id]);
$history = $stmt->fetchAll();

$page_title="Pharmacy History";
include __DIR__ . '/../includes/header.php';
?>
<h2>Pharmacy History</h2>
<table class="table">
  <thead><tr><th>Drug</th><th>Status</th><th>Date</th></tr></thead>
  <tbody>
  <?php foreach($history as $row): ?>
    <tr>
      <td><?= htmlspecialchars($row['drug_name'] ?? '-') ?></td>
      <td><?= htmlspecialchars($row['status'] ?? '-') ?></td>
      <td><?= htmlspecialchars($row['created_at'] ?? '-') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
