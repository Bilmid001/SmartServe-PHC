<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $vaccine = trim($_POST['vaccine_name'] ?? '');
    $dose = (int)($_POST['dose_number'] ?? 1);
    $date = $_POST['given_at'] ?? '';

    if ($patient_id && $vaccine && $date) {
        $stmt = $pdo->prepare("INSERT INTO immunizations (patient_id, vaccine_name, dose_number, given_by, given_at) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $patient_id,
            $vaccine,
            $dose,
            $_SESSION['user_id'] ?? null,
            $date
        ]);
        header("Location: immunizations_list.php");
        exit;
    } else {
        $error = "Please fill in all required fields.";
    }
}

$page_title = "Add Immunization";
include __DIR__ . '/../includes/header.php';
?>

<style>
  
  
  h1 {
    margin-bottom: 24px;
    font-weight: 700;
    color: #2c3e50;
    text-align: center;
  }
  label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
  }
  input[type="text"],
  input[type="number"],
  input[type="date"] {
    width: 100%;
    padding: 10px 14px;
    margin-bottom: 20px;
    border: 1.8px solid #ccc;
    border-radius: 5px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
  }
  input[type="text"]:focus,
  input[type="number"]:focus,
  input[type="date"]:focus {
    border-color: #3498db;
    outline: none;
  }
  input[type="submit"] {
    width: 100%;
    padding: 14px;
    background-color: #3498db;
    border: none;
    border-radius: 6px;
    color: white;
    font-weight: 700;
    font-size: 1.1rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  input[type="submit"]:hover {
    background-color: #2980b9;
  }
  .error {
    background-color: #ffe6e6;
    border: 1px solid #ff4d4d;
    color: #cc0000;
    padding: 12px 15px;
    border-radius: 5px;
    margin-bottom: 20px;
    font-weight: 600;
  }
</style>

<div class="container">
  <h1><?php echo htmlspecialchars($page_title); ?></h1>

  <?php if (!empty($error)): ?>
    <div class="error"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>

  <form method="post" action="">
    <label for="patient_id">Patient ID:</label>
    <input type="number" name="patient_id" id="patient_id" required min="1" placeholder="Enter Patient ID">

    <label for="vaccine_name">Vaccine Name:</label>
    <input type="text" name="vaccine_name" id="vaccine_name" required placeholder="Enter Vaccine Name">

    <label for="dose_number">Dose Number:</label>
    <input type="number" name="dose_number" id="dose_number" value="1" min="1">

    <label for="given_at">Date Given:</label>
    <input type="date" name="given_at" id="given_at" required>

    <input type="submit" value="Add Immunization">
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
