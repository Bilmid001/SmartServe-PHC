<?php
// pharmacy/add_prescription.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['pharmacy','doctor','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$patient_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$msg = '';

// Load patient if id provided
$patient = null;
if ($patient_id) {
    $stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
    $stmt->execute([$patient_id]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Inline search
$search_results = [];
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search']) && trim($_GET['search']) !== '') {
    $q = trim($_GET['search']);
    $stmt = $pdo->prepare("SELECT id, fullname, phone, gender, dob 
                           FROM patients 
                           WHERE id = :q_id OR phone = :q_phone OR fullname LIKE :name 
                           LIMIT 50");
    $stmt->execute([
        ':q_id' => $q,
        ':q_phone' => $q,
        ':name' => "%$q%"
    ]);
    $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Handle POST for adding prescription
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $posted_patient_id = (int)($_POST['patient_id'] ?? 0);
    $drug_name = trim($_POST['medicine'] ?? '');
    $dosage = trim($_POST['dosage'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);
    $instructions = trim($_POST['instructions'] ?? '');
    $status = $_POST['status'] ?? 'pending';

    // Validate status
    $allowed_statuses = ['pending', 'active', 'dispensed', 'cancelled'];
    if (!in_array($status, $allowed_statuses)) {
        $status = 'pending';
    }

    if (!$posted_patient_id || !$drug_name) {
        $msg = "Please select a patient and enter a medicine.";
    } else {
        // Get latest consultation for patient
        $stmt = $pdo->prepare("SELECT id FROM consultations WHERE patient_id = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$posted_patient_id]);
        $consultation_id = $stmt->fetchColumn();

        if (!$consultation_id) {
            $msg = "No consultation found for this patient. Cannot add prescription.";
        } else {
            // Insert prescription with consultation_id and correct columns
            $stmt = $pdo->prepare("INSERT INTO prescriptions 
                (consultation_id, doctor_id, drug_name, dosage, quantity, instructions, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");

            $success = $stmt->execute([
                $consultation_id,
                $_SESSION['user_id'] ?? null,
                $drug_name,
                $dosage !== '' ? $dosage : null,
                $quantity > 0 ? $quantity : null,
                $instructions !== '' ? $instructions : null,
                $status
            ]);

            if ($success) {
                header("Location: prescriptions.php");
                exit;
            } else {
                $msg = "Failed to add prescription. Please try again.";
            }
        }
    }
}

$page_title = "Add Prescription";
include __DIR__ . '/../includes/header.php';
?>

<h2>Add Prescription</h2>

<?php if ($msg): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<form method="post" action="">
    <div class="mb-3">
        <label for="patient_id" class="form-label">Select Patient</label>
        <select name="patient_id" id="patient_id" class="form-select" required>
            <option value="">-- Select Patient --</option>
            <?php if ($patient): ?>
                <option value="<?= $patient['id'] ?>" selected>
                    <?= htmlspecialchars($patient['fullname']) ?> (ID: <?= $patient['id'] ?>)
                </option>
            <?php endif; ?>
            <?php foreach ($search_results as $p): ?>
                <option value="<?= $p['id'] ?>">
                    <?= htmlspecialchars($p['fullname']) ?> - <?= htmlspecialchars($p['phone']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <small class="form-text text-muted">Use the search box above to find a patient.</small>
    </div>

    <div class="mb-3">
        <label for="medicine" class="form-label">Medicine</label>
        <input type="text" id="medicine" name="medicine" class="form-control" required value="<?= htmlspecialchars($_POST['medicine'] ?? '') ?>">
    </div>

    <div class="mb-3">
        <label for="dosage" class="form-label">Dosage</label>
        <input type="text" id="dosage" name="dosage" class="form-control" value="<?= htmlspecialchars($_POST['dosage'] ?? '') ?>">
    </div>

    <div class="mb-3">
        <label for="quantity" class="form-label">Quantity</label>
        <input type="number" id="quantity" name="quantity" class="form-control" min="0" value="<?= (int)($_POST['quantity'] ?? 0) ?>">
    </div>

    <div class="mb-3">
        <label for="instructions" class="form-label">Instructions</label>
        <textarea id="instructions" name="instructions" class="form-control"><?= htmlspecialchars($_POST['instructions'] ?? '') ?></textarea>
    </div>

    <div class="mb-3">
        <label for="status" class="form-label">Status</label>
        <select id="status" name="status" class="form-select">
            <?php
            $statuses = ['pending', 'active', 'dispensed', 'cancelled'];
            $current_status = $_POST['status'] ?? 'pending';
            foreach ($statuses as $st) {
                $sel = $st === $current_status ? 'selected' : '';
                echo "<option value=\"$st\" $sel>" . ucfirst($st) . "</option>";
            }
            ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Add Prescription</button>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>
