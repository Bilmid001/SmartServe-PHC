<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['records','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

// Total patients
$total_patients = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();

// Today's open files
$open_today = $pdo->prepare("SELECT COUNT(*) FROM patients WHERE DATE(created_at) = CURDATE()");
$open_today->execute();
$open_today = $open_today->fetchColumn();

// Today's closed files
$closed_today = $pdo->prepare("SELECT COUNT(*) FROM patients WHERE status='closed' AND DATE(updated_at) = CURDATE()");
$closed_today->execute();
$closed_today = $closed_today->fetchColumn();

// Monthly patient registration trend
$monthly_trend = $pdo->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
    FROM patients 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) 
    GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
    ORDER BY month
")->fetchAll(PDO::FETCH_ASSOC);

// Patient status distribution
$status_distribution = $pdo->query("
    SELECT status, COUNT(*) as count 
    FROM patients 
    GROUP BY status
")->fetchAll(PDO::FETCH_ASSOC);

// Recent patient registrations
$recent_patients = $pdo->query("
    SELECT id, first_name, last_name, created_at, status 
    FROM patients 
    ORDER BY created_at DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Records Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
  :root {
    --primary: #4361ee;
    --secondary: #3f37c9;
    --success: #4cc9f0;
    --info: #4895ef;
    --warning: #f72585;
    --danger: #e63946;
    --light: #f8f9fa;
    --dark: #212529;
    --records-gradient: linear-gradient(120deg, #0ba360 0%, #3cba92 100%);
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    --hover-shadow: 0 14px 28px rgba(0, 0, 0, 0.25);
  }

  body {
    background-color: #f5f7fb;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .dashboard-header {
    background: var(--records-gradient);
    padding: 2rem 0;
    margin-bottom: 2rem;
    border-radius: 0 0 20px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .ai-btn {
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    border: none;
    color: white;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(38, 132, 255, 0.4);
    transition: all 0.3s ease;
    border-radius: 50px;
    padding: 12px 25px;
  }

  .ai-btn:hover {
    background: linear-gradient(90deg, #2575fc, #6a11cb);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(38, 132, 255, 0.6);
  }

  .card {
    border: none;
    border-radius: 15px;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    margin-bottom: 1.5rem;
    overflow: hidden;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
  }

  .stat-card {
    padding: 1.5rem;
    color: white;
    border-radius: 15px;
    text-align: center;
    height: 100%;
  }

  .stat-card h5 {
    font-size: 1rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
  }

  .stat-card .number {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0;
  }

  .chart-container {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    margin-bottom: 1.5rem;
    height: 100%;
  }

  .chart-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
    text-align: center;
  }

  .activity-card {
    padding: 1.5rem;
  }

  .activity-card h5 {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .activity-item {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid #edf2f7;
    transition: background-color 0.2s;
  }

  .activity-item:hover {
    background-color: #f8fafc;
  }

  .activity-item:last-child {
    border-bottom: none;
  }

  .activity-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
    flex-shrink: 0;
  }

  .activity-content {
    flex-grow: 1;
  }

  .activity-patient {
    font-weight: 600;
    color: #2d3748;
  }

  .activity-id {
    color: #4a5568;
    font-size: 0.9rem;
  }

  .activity-time {
    color: #718096;
    font-size: 0.8rem;
    text-align: right;
  }

  .search-section {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: var(--card-shadow);
  }

  .search-title {
    font-size: 1.3rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .status-badge {
    padding: 0.35rem 0.65rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
  }

  .quick-action-card {
    text-align: center;
    height: 100%;
    padding: 1.5rem;
  }

  .quick-action-card .icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    color: #0ba360;
  }

  @media (max-width: 768px) {
    .stat-card .number {
      font-size: 2rem;
    }
    
    .activity-item {
      flex-direction: column;
      align-items: flex-start;
    }
    
    .activity-time {
      margin-top: 0.5rem;
      text-align: left;
    }
  }
</style>

<div class="dashboard-header">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
      <div>
        <h2 class="text-white fw-bold mb-2">Records Dashboard</h2>
        <p class="text-white mb-4">
          Welcome to the Records Dashboard! Manage patient records, track file status, and maintain accurate health information.
        </p>
      </div>
      
      <!-- AI Assistant Button -->
      <a href="../aiphc.php" class="btn ai-btn px-4 py-3 d-flex align-items-center gap-2" role="button">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-robot" viewBox="0 0 16 16">
          <path d="M5 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM9 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0z"/>
          <path d="M2 8v1h12V8H2zm12-1V6H2v1h12zM1 10v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H1z"/>
        </svg>
        Smart Serve AI Assistant
      </a>
    </div>
  </div>
</div>

<div class="container my-5">
  <div class="row">
    <!-- Stats Cards -->
    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #0ba360, #3cba92);">
        <h5>Total Patients</h5>
        <p class="number"><?= $total_patients ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">All Records</span>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #ff7e5f, #feb47b);">
        <h5>Open Files (Today)</h5>
        <p class="number"><?= $open_today ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">New Registrations</span>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #7474BF, #348AC7);">
        <h5>Closed Files (Today)</h5>
        <p class="number"><?= $closed_today ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">Completed</span>
        </div>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Registration Trend Chart -->
    <div class="col-lg-6 mb-4">
      <div class="chart-container">
        <h5 class="chart-title">Patient Registration Trend (Last 6 Months)</h5>
        <canvas id="registrationChart"></canvas>
      </div>
    </div>

    <!-- Status Distribution Chart -->
    <div class="col-lg-6 mb-4">
      <div class="chart-container">
        <h5 class="chart-title">Patient Status Distribution</h5>
        <canvas id="statusChart"></canvas>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Recent Activity -->
    <div class="col-lg-8 mb-4">
      <div class="card activity-card">
        <h5>Recent Patient Registrations</h5>
        
        <?php if (count($recent_patients) > 0): ?>
          <?php foreach ($recent_patients as $patient): ?>
            <div class="activity-item">
              <div class="activity-icon" style="background-color: rgba(11, 163, 96, 0.2);">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#0ba360" class="bi bi-person-plus" viewBox="0 0 16 16">
                  <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                  <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
                </svg>
              </div>
              <div class="activity-content">
                <div class="activity-patient"><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></div>
                <div class="activity-id">ID: <?= htmlspecialchars($patient['id']) ?></div>
              </div>
              <div class="activity-time">
                <?php 
                  $date = new DateTime($patient['created_at']);
                  echo $date->format('M j, Y');
                ?>
                <br>
                <span class="status-badge <?= $patient['status'] == 'active' ? 'bg-success' : ($patient['status'] == 'closed' ? 'bg-danger' : 'bg-warning') ?>">
                  <?= ucfirst($patient['status']) ?>
                </span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-muted">No recent patient registrations</p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="col-lg-4 mb-4">
      <div class="card activity-card">
        <h5>Quick Actions</h5>
        
        <div class="d-grid gap-2">
          <a href="<?= BASE_URL ?>/records/register.php" class="btn btn-outline-primary btn-lg mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus me-2" viewBox="0 0 16 16">
              <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
              <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
            </svg>
            Register New Patient
          </a>
          
          <a href="<?= BASE_URL ?>/records/view_all.php" class="btn btn-outline-secondary btn-lg mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list-ul me-2" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M5 11.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm-3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
            </svg>
            View All Patients
          </a>
          
          <a href="<?= BASE_URL ?>/records/reports.php" class="btn btn-outline-info btn-lg mb-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-graph-up me-2" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M0 0h1v15h15v1H0V0Zm14.817 3.113a.5.5 0 0 1 .07.704l-4.5 5.5a.5.5 0 0 1-.74.037L7.06 6.767l-3.656 5.027a.5.5 0 0 1-.808-.588l4-5.5a.5.5 0 0 1 .758-.06l2.609 2.61 4.15-5.073a.5.5 0 0 1 .704-.07Z"/>
            </svg>
            Generate Reports
          </a>
          
          <a href="<?= BASE_URL ?>/records/archives.php" class="btn btn-outline-warning btn-lg">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-archive me-2" viewBox="0 0 16 16">
              <path d="M0 2a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1v7.5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 1 12.5V5a1 1 0 0 1-1-1V2zm2 3v7.5A1.5 1.5 0 0 0 3.5 14h9a1.5 1.5 0 0 0 1.5-1.5V5H2zm13-3H1v2h14V2zM5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5z"/>
            </svg>
            Access Archives
          </a>
        </div>
      </div>
    </div>
  </div>

  <!-- Search Section -->
  <div class="row mt-4">
    <div class="col-12">
      <div class="search-section">
        <h4 class="search-title">Find Patient Record</h4>
        <form method="get" action="<?= BASE_URL ?>/records/search.php" class="row g-3">
          <div class="col-md-8">
            <input type="text" name="q" class="form-control form-control-lg" placeholder="Enter Patient ID, Name, Phone Number, or Email">
          </div>
          <div class="col-md-4">
            <button type="submit" class="btn btn-primary btn-lg w-100">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search me-2" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
              Search Records
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Registration Trend Chart
    const registrationCtx = document.getElementById('registrationChart').getContext('2d');
    new Chart(registrationCtx, {
      type: 'line',
      data: {
        labels: [<?php foreach($monthly_trend as $month): ?>'<?= date('M Y', strtotime($month['month'] . '-01')) ?>', <?php endforeach; ?>],
        datasets: [{
          label: 'Patient Registrations',
          data: [<?php foreach($monthly_trend as $month): ?><?= $month['count'] ?>, <?php endforeach; ?>],
          backgroundColor: 'rgba(11, 163, 96, 0.2)',
          borderColor: 'rgba(11, 163, 96, 1)',
          borderWidth: 2,
          tension: 0.3,
          fill: true
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      }
    });

    // Status Distribution Chart
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    new Chart(statusCtx, {
      type: 'doughnut',
      data: {
        labels: [<?php foreach($status_distribution as $status): ?>'<?= ucfirst($status['status']) ?>', <?php endforeach; ?>],
        datasets: [{
          data: [<?php foreach($status_distribution as $status): ?><?= $status['count'] ?>, <?php endforeach; ?>],
          backgroundColor: [
            '#0ba360', '#ff7e5f', '#7474BF', '#feb47b', '#348AC7'
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>