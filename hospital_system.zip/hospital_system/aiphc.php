<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>AI HealthAssist</title>
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    rel="stylesheet"
  />
  <style>
    /* === Basic styling for your container and chat === */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f4f8fb;
      margin: 0;
      display: flex;
      flex-direction: column;
      height: 100vh;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      flex: 1;
      display: flex;
      flex-direction: column;
      background: white;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      overflow: hidden;
    }
    header {
      background: #007bff;
      color: white;
      padding: 15px 25px;
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .logo-icon {
      font-size: 2.2rem;
    }
    .header-content h1 {
      margin: 0;
      font-size: 1.7rem;
      font-weight: 700;
    }
    .subtitle {
      font-size: 0.9rem;
      opacity: 0.85;
      margin-top: 2px;
    }

    .chat-container {
      display: flex;
      flex: 1;
      min-height: 0;
    }
    .sidebar {
      width: 260px;
      background: #f1f5f9;
      padding: 15px;
      border-right: 1px solid #ddd;
      display: flex;
      flex-direction: column;
    }
    .sidebar h2 {
      margin-top: 0;
      font-weight: 700;
      color: #333;
      margin-bottom: 15px;
      user-select: none;
    }
    .quick-actions {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .action-btn {
      background: white;
      border: 1px solid #ddd;
      border-radius: 6px;
      padding: 10px 12px;
      cursor: pointer;
      font-weight: 600;
      color: #007bff;
      display: flex;
      align-items: center;
      gap: 10px;
      transition: background-color 0.2s, border-color 0.2s;
      user-select: none;
      text-align: left;
    }
    .action-btn:hover {
      background-color: #007bff;
      color: white;
      border-color: #007bff;
    }
    .action-btn i {
      font-size: 1.2rem;
    }
    .action-btn a {
      text-decoration: none;
      color: inherit;
      width: 100%;
      display: inline-block;
    }
    botton {
      margin-top: 20px;
    }

    .chat-box {
      flex: 1;
      display: flex;
      flex-direction: column;
      background: white;
      padding: 15px 20px;
    }
    .chat-header {
      display: flex;
      align-items: center;
      gap: 15px;
      border-bottom: 1px solid #eee;
      padding-bottom: 12px;
      margin-bottom: 12px;
    }
    .chat-header img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      object-fit: cover;
      background-color: #eee;
    }
    .chat-header > div {
      display: flex;
      flex-direction: column;
      font-weight: 600;
      user-select: none;
    }
    .chat-header > div > div:first-child {
      font-size: 1.1rem;
      color: #007bff;
    }
    .chat-header > div > div:last-child {
      font-size: 0.8rem;
      color: #555;
    }

    .chat-messages {
      flex: 1;
      overflow-y: auto;
      padding-right: 10px;
      margin-bottom: 15px;
      scroll-behavior: smooth;
    }
    .message {
      max-width: 70%;
      margin-bottom: 12px;
      padding: 12px 16px;
      border-radius: 15px;
      line-height: 1.4;
      white-space: pre-line;
      user-select: text;
    }
    .user-message {
      background-color: #007bff;
      color: white;
      align-self: flex-end;
      border-bottom-right-radius: 3px;
    }
    .bot-message {
      background-color: #e2e6ea;
      color: #333;
      align-self: flex-start;
      border-bottom-left-radius: 3px;
    }

    .typing-indicator {
      display: flex;
      gap: 5px;
      margin-bottom: 12px;
      align-self: flex-start;
    }
    .typing-dot {
      width: 8px;
      height: 8px;
      background-color: #999;
      border-radius: 50%;
      animation: blink 1.4s infinite ease-in-out;
    }
    .typing-dot:nth-child(2) {
      animation-delay: 0.2s;
    }
    .typing-dot:nth-child(3) {
      animation-delay: 0.4s;
    }
    @keyframes blink {
      0%, 80%, 100% { opacity: 0; }
      40% { opacity: 1; }
    }

    .suggestions {
      display: flex;
      gap: 15px;
      margin-bottom: 15px;
      flex-wrap: wrap;
    }
    .suggestion {
      background: #007bff;
      color: white;
      padding: 8px 14px;
      border-radius: 20px;
      cursor: pointer;
      font-weight: 600;
      user-select: none;
      transition: background-color 0.3s;
    }
    .suggestion:hover {
      background-color: #0056b3;
    }

    .chat-input {
      display: flex;
      gap: 8px;
      border-top: 1px solid #ddd;
      padding-top: 10px;
      user-select: none;
    }
    #user-input {
      flex: 1;
      padding: 10px 14px;
      border-radius: 25px;
      border: 1px solid #ccc;
      font-size: 1rem;
      outline-offset: 2px;
    }
    #user-input:focus {
      border-color: #007bff;
      outline: none;
    }
    .chat-input button {
      background: #007bff;
      border: none;
      color: white;
      border-radius: 50%;
      width: 42px;
      height: 42px;
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      transition: background-color 0.2s ease-in-out;
    }
    .chat-input button:hover {
      background: #0056b3;
    }
    .chat-input button:disabled {
      background: #ccc;
      cursor: default;
    }
    .chat-input button i {
      font-size: 1.3rem;
      pointer-events: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="header-content">
        <div class="logo">
          <div class="logo-icon">⚕️</div>
          <div>
            <h1>AI HealthAssist</h1>
            <div class="subtitle">Your intelligent healthcare management assistant</div>
          </div>
        </div>
      </div>
    </header>

    <div class="chat-container">
      <div class="sidebar">
        <h2>Quick Actions</h2>
        <div class="quick-actions">
          <button class="action-btn" onclick="sendQuickQuestion('appointment')">
            <i class="fas fa-calendar-check"></i> Schedule Appointment
          </button>
          <button class="action-btn" onclick="sendQuickQuestion('prescription')">
            <i class="fas fa-pills"></i> Prescription Refill
          </button>
          <button class="action-btn" onclick="sendQuickQuestion('billing')">
            <i class="fas fa-money-bill-wave"></i> Billing Inquiry
          </button>
          <button class="action-btn" onclick="sendQuickQuestion('doctor')">
            <i class="fas fa-user-md"></i> Find a Doctor
          </button>
          <button class="action-btn" onclick="sendQuickQuestion('hours')">
            <i class="fas fa-clock"></i> Operating Hours
          </button>
          <button class="action-btn" onclick="sendQuickQuestion('emergency')">
            <i class="fas fa-ambulance"></i> Emergency Services
          </button>
          <!-- <botton>
            <a href="/hospital_system/admin/dashboard.php" class="action-btn">
              <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
          </botton> -->
        </div>
      </div>

      <div class="chat-box">
        <div class="chat-header">
          <img src="https://cdn-icons-png.flaticon.com/512/2921/2921222.png" alt="AI Icon" />
          <div>
            <div>HealthAssist AI</div>
            <div style="font-size: 0.8rem; opacity: 0.8;">Online - Ready to help</div>
          </div>
        </div>

        <div class="chat-messages" id="chat-messages">
          <div class="message bot-message">
            Hello! I'm HealthAssist AI, your healthcare assistant. How can I help you today?
          </div>
        </div>

        <div class="suggestions">
          <div class="suggestion" onclick="sendQuickQuestion('appointment')">Schedule an appointment</div>
          <div class="suggestion" onclick="sendQuickQuestion('prescription')">Request prescription refill</div>
          <div class="suggestion" onclick="sendQuickQuestion('billing')">Billing question</div>
          <div class="suggestion" onclick="sendQuickQuestion('doctor')">Find a doctor</div>
        </div>

        <div class="chat-input">
          <input
            type="text"
            id="user-input"
            placeholder="Type your message here..."
            onkeypress="handleKeyPress(event)"
            autocomplete="off"
          />
          <button title="Send message" onclick="sendMessage()">
            <i class="fas fa-paper-plane"></i>
          </button>
          <button
            id="voice-btn"
            title="Start voice input"
            onclick="toggleVoiceRecognition()"
            aria-pressed="false"
          >
            <i class="fas fa-microphone"></i>
          </button>
        </div>
      </div>
    </div>

    <footer style="text-align:center; padding: 10px 0; font-size: 0.9rem; color: #666;">
      HealthAssist AI v1.0 | Powered by Bilmid Tech Creative
    </footer>
  </div>

  <script>
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const voiceBtn = document.getElementById('voice-btn');

    let recognition;
    let recognizing = false;

    // Check if browser supports SpeechRecognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        recognizing = true;
        voiceBtn.setAttribute('aria-pressed', 'true');
        voiceBtn.style.backgroundColor = '#d9534f'; // Red when recording
      };

      recognition.onend = () => {
        recognizing = false;
        voiceBtn.setAttribute('aria-pressed', 'false');
        voiceBtn.style.backgroundColor = ''; // reset
      };

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        userInput.value = transcript;
        sendMessage();
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        alert('Voice recognition error: ' + event.error);
        recognizing = false;
        voiceBtn.setAttribute('aria-pressed', 'false');
        voiceBtn.style.backgroundColor = '';
      };
    } else {
      // Disable voice button if not supported
      voiceBtn.disabled = true;
      voiceBtn.title = 'Voice input not supported in this browser';
    }

    function toggleVoiceRecognition() {
      if (!recognition) return;
      if (recognizing) {
        recognition.stop();
      } else {
        recognition.start();
      }
    }

    function addMessage(message, isUser = false) {
      const messageDiv = document.createElement('div');
      messageDiv.classList.add('message', isUser ? 'user-message' : 'bot-message');
      messageDiv.textContent = message;
      chatMessages.appendChild(messageDiv);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function showTypingIndicator() {
      const typingDiv = document.createElement('div');
      typingDiv.classList.add('typing-indicator');
      typingDiv.id = 'typing-indicator';
      typingDiv.innerHTML = `
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
      `;
      chatMessages.appendChild(typingDiv);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function removeTypingIndicator() {
      const typingIndicator = document.getElementById('typing-indicator');
      if (typingIndicator) typingIndicator.remove();
    }

    async function getAIResponse(message) {
      showTypingIndicator();
      await new Promise(resolve => setTimeout(resolve, 800)); // simulate delay

      const lowerMessage = message.toLowerCase();

      const responses = [
        { keywords: ['appointment', 'schedule', 'booking'], reply: "You can schedule an appointment by telling me your preferred date, time, and specialty." },
        { keywords: ['prescription', 'refill', 'medication'], reply: "To request a prescription refill, please provide your Patient ID and the medication name." },
        { keywords: ['billing', 'payment', 'invoice', 'bill'], reply: "Billing inquiries can be addressed by providing your Patient ID or invoice number." },
        { keywords: ['doctor', 'physician', 'specialist'], reply: "We have doctors in various specialties. What kind of doctor are you looking for?" },
        { keywords: ['emergency', 'urgent'], reply: "In case of emergency, visit the Emergency Department or call emergency services immediately." },
        { keywords: ['hours', 'time', 'open'], reply: "We’re open Mon–Fri: 8AM–8PM, Sat: 9AM–4PM. Emergencies are 24/7." },
        { keywords: ['vaccine', 'immunization'], reply: "We offer vaccines for COVID-19, flu, hepatitis, and more. Let us know which one you need." },
        { keywords: ['test result', 'lab', 'result'], reply: "You can access your test results through our patient portal or request them here." },
        { keywords: ['x-ray', 'mri', 'scan'], reply: "Diagnostic services like X-rays and MRIs are available. Do you have a referral or request?" },
        { keywords: ['covid', 'coronavirus'], reply: "COVID-19 info: Testing, vaccination, and safety protocols are updated regularly. Ask me anything!" },
        { keywords: ['insurance', 'coverage'], reply: "We accept most major insurance providers. Would you like to check your coverage?" },
        { keywords: ['follow-up', 'check-up'], reply: "Scheduling a follow-up or routine check-up? Please share your preferred date and doctor." },
        { keywords: ['cancel appointment', 'reschedule'], reply: "To cancel or reschedule, please provide your appointment ID or date/time." },
        { keywords: ['health tips', 'wellness'], reply: "Looking for health tips? I can provide advice on diet, exercise, and general wellness." },
        { keywords: ['pharmacy', 'medications'], reply: "Our in-house pharmacy is open Mon-Fri 9AM-6PM. You can request your meds here." },
        { keywords: ['contact', 'phone', 'email'], reply: "You can contact us at (555) 123-4567 or email support@healthassist.com." },
        { keywords: ['covid vaccine', 'flu shot'], reply: "Vaccines are available by appointment. Would you like to book one?" },
        { keywords: ['mental health', 'counseling'], reply: "We offer mental health counseling services. Need help scheduling a session?" },
        { keywords: ['nutrition', 'diet'], reply: "Our nutritionist can help you with diet plans. Would you like to book a consultation?" },
        { keywords: ['physical therapy', 'rehab'], reply: "Physical therapy services are available by referral. Want to know more?" }
      ];

      // Find matching response
      let reply = "Sorry, I didn't quite understand. Could you please rephrase or ask another question?";

      for (const r of responses) {
        for (const kw of r.keywords) {
          if (lowerMessage.includes(kw)) {
            reply = r.reply;
            break;
          }
        }
        if (reply !== "Sorry, I didn't quite understand. Could you please rephrase or ask another question?") break;
      }

      removeTypingIndicator();
      addMessage(reply, false);
    }

    function sendMessage() {
      const message = userInput.value.trim();
      if (!message) return;
      addMessage(message, true);
      userInput.value = '';
      getAIResponse(message);
    }

    function handleKeyPress(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    }

    function sendQuickQuestion(topic) {
      let question = '';
      switch (topic) {
        case 'appointment':
          question = 'I want to schedule an appointment.';
          break;
        case 'prescription':
          question = 'I need a prescription refill.';
          break;
        case 'billing':
          question = 'I have a question about my bill.';
          break;
        case 'doctor':
          question = 'Can you help me find a doctor?';
          break;
        case 'hours':
          question = 'What are your operating hours?';
          break;
        case 'emergency':
          question = 'What do I do in an emergency?';
          break;
        default:
          question = 'Hello!';
      }
      addMessage(question, true);
      getAIResponse(question);
    }
  </script>
</body>
</html>

<!-- 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 -->