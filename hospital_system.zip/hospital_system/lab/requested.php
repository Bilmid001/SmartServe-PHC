<?php
// lab/requested.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['lab','doctor','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

// Paging optional
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;

// Fetch pending lab tests joined to patients
$stmt = $pdo->prepare("
    SELECT lr.*, p.fullname, p.phone, p.dob, p.gender
    FROM lab_results lr
    LEFT JOIN patients p ON lr.patient_id = p.id
    WHERE lr.status = 'pending'
    ORDER BY lr.requested_at DESC
    LIMIT :limit OFFSET :offset
");

$stmt->bindValue(':limit', 10, PDO::PARAM_INT);
$stmt->bindValue(':offset', 0, PDO::PARAM_INT);
$stmt->execute();
$pending = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Requested Lab Tests";


include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-3">Pending Lab Tests</h2>
  <form method="get" action="<?= BASE_URL ?>/records/search.php" class="row g-3 mb-3">
    <div class="col-md-5">
      <input type="text" name="q" class="form-control" placeholder="Search patient by ID, phone or name">
    </div>
    <div class="col-md-2"><button class="btn btn-primary">Search</button></div>
  </form>

  <?php if ($pending): ?>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Requested At</th>
          <th>Patient</th>
          <th>Phone</th>
          <th>Test</th>
          <th>Requested By</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($pending as $row): ?>
          <tr>
            <td><?= htmlspecialchars($row['requested_at']) ?></td>
            <td>
              <?php if ($row['patient_id']): ?>
                <a href="patient_history.php?id=<?= $row['patient_id'] ?>"><?= htmlspecialchars($row['fullname'] ?: ('#'.$row['patient_id'])) ?></a>
              <?php else: ?>
                <span class="text-muted">Unknown patient</span>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['phone'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['test_name']) ?></td>
            <td><?= htmlspecialchars($row['requested_by'] ?? '-') ?></td>
            <td>
              <?php if ($row['id']): ?>
                <a class="btn btn-sm btn-primary" href="add_result.php?id=<?= $row['patient_id'] ?? '' ?>&lab_id=<?= $row['id'] ?>">Add / Edit Result</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="alert alert-info">No pending lab tests.</div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
