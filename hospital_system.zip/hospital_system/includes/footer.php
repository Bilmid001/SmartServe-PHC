<style>
/* Make the entire page use flex layout to push footer down */
html, body {
  height: 100%;
  margin: 0;
  display: flex;
  flex-direction: column;
}

.container {
  flex: 1 0 auto; /* Allow main content to grow and push footer down */
}

/* Footer styling */
footer {
  flex-shrink: 0;
  background-color: #f8f9fa; /* light gray */
  border-top: 1px solid #dee2e6; /* subtle border */
  padding: 1rem 0;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  font-size: 0.9rem;
  color: #495057;
}

footer a {
  text-decoration: none;
  transition: color 0.3s ease;
}

footer a:hover {
  color: #0d6efd; /* Bootstrap primary color on hover */
}

footer i {
  vertical-align: middle;
}

/* Spacing for icon links */
footer a.mx-2 {
  margin-left: 0.5rem;
  margin-right: 0.5rem;
}

/* Responsive flex container inside footer */
footer .container {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  text-align: center;
}

/* On smaller screens, stack footer content */
@media (max-width: 576px) {
  footer .container {
    flex-direction: column;
    gap: 0.5rem;
  }
}
</style>

<hr>
<footer class="text-center py-3 bg-light">
  <div class="container d-flex flex-column flex-md-row justify-content-center align-items-center gap-3">
    <p class="mb-0">&copy; <?= date('Y') ?> Hospital System. All rights reserved.</p>
    <div>
      Developed by <strong>Bilmid Tech Creative</strong>
    </div>
    <div>
      <a href="https://wa.me/+2348069715695" target="_blank" aria-label="WhatsApp" class="mx-2 text-success fs-4">
        <i class="fab fa-whatsapp"></i>
      </a>
      <!-- <a href="https://facebook.com/yourpage" target="_blank" aria-label="Facebook" class="mx-2 text-primary fs-4">
        <i class="fab fa-facebook-f"></i>
      </a> -->
    </div>
  </div>
</footer>
