<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json');

$patient_id = $_GET['patient_id'] ?? '';

if (!$patient_id || !is_numeric($patient_id)) {
    echo json_encode(['success' => false, 'visits' => []]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, visit_date FROM visits WHERE patient_id = :pid ORDER BY visit_date DESC");
$stmt->execute([':pid' => $patient_id]);

$visits = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'visits' => $visits]);
