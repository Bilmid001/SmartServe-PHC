<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$msg = "";

// Handle Add
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $stmt = $pdo->prepare("INSERT INTO drugs(name, quantity) VALUES (?, ?)");
        $stmt->execute([$_POST['name'], $_POST['quantity']]);
        $msg = "Drug added.";
    }
    // Handle Delete
    if (isset($_POST['delete'])) {
        $stmt = $pdo->prepare("DELETE FROM drugs WHERE id = ?");
        $stmt->execute([$_POST['delete']]);
        $msg = "Drug deleted.";
    }
}

$drugs = $pdo->query("SELECT * FROM drugs ORDER BY name ASC")->fetchAll();

$page_title = "Manage Stock";
include __DIR__ . '/../includes/header.php';
?>

<h2>Drug Stock</h2>

<?php if ($msg): ?>
  <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<!-- Add Drug Form -->
<form method="post" class="mb-3">
  <input type="text" name="name" placeholder="Drug Name" class="form-control mb-2" required>
  <input type="number" name="quantity" placeholder="Quantity" class="form-control mb-2" required>
  <button name="add" class="btn btn-primary">Add Drug</button>
</form>

<!-- Drugs Table -->
<table class="table table-striped">
  <thead>
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Quantity</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($drugs as $d): ?>
    <tr data-id="<?= $d['id'] ?>" data-name="<?= htmlspecialchars($d['name'], ENT_QUOTES) ?>" data-quantity="<?= $d['quantity'] ?>">
      <td><?= $d['id'] ?></td>
      <td><?= htmlspecialchars($d['name']) ?></td>
      <td><?= $d['quantity'] ?></td>
      <td>
        <button class="btn btn-info btn-sm btn-view" data-bs-toggle="modal" data-bs-target="#viewModal">View</button>
        <button class="btn btn-warning btn-sm btn-edit" data-bs-toggle="modal" data-bs-target="#editModal">Edit</button>

        <form method="post" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this drug?');">
          <button name="delete" value="<?= $d['id'] ?>" class="btn btn-danger btn-sm">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"> 
        <h5 class="modal-title" id="viewModalLabel">View Drug Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p><strong>ID:</strong> <span id="view-id"></span></p>
        <p><strong>Name:</strong> <span id="view-name"></span></p>
        <p><strong>Quantity:</strong> <span id="view-quantity"></span></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form id="editForm" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editModalLabel">Edit Drug</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <input type="hidden" name="id" id="edit-id" />
          <div class="mb-3">
            <label for="edit-name" class="form-label">Drug Name</label>
            <input type="text" class="form-control" id="edit-name" name="name" required />
          </div>
          <div class="mb-3">
            <label for="edit-quantity" class="form-label">Quantity</label>
            <input type="number" class="form-control" id="edit-quantity" name="quantity" required />
          </div>
          <div id="edit-msg" class="alert alert-danger d-none"></div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Save Changes</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  // View button click: populate view modal
  document.querySelectorAll('.btn-view').forEach(btn => {
    btn.addEventListener('click', function () {
      const tr = this.closest('tr');
      document.getElementById('view-id').textContent = tr.dataset.id;
      document.getElementById('view-name').textContent = tr.dataset.name;
      document.getElementById('view-quantity').textContent = tr.dataset.quantity;
    });
  });

  // Edit button click: populate edit modal
  document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', function () {
      const tr = this.closest('tr');
      document.getElementById('edit-id').value = tr.dataset.id;
      document.getElementById('edit-name').value = tr.dataset.name;
      document.getElementById('edit-quantity').value = tr.dataset.quantity;
      document.getElementById('edit-msg').classList.add('d-none');
    });
  });

  // Handle edit form submission with AJAX
  document.getElementById('editForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const form = this;
    const data = new FormData(form);
    data.append('edit_ajax', '1');

    fetch('manage_stock.php', {
      method: 'POST',
      body: data,
    })
    .then(res => res.json())
    .then(response => {
      if (response.success) {
        // Update the row in the table
        const tr = document.querySelector(`tr[data-id='${response.data.id}']`);
        tr.dataset.name = response.data.name;
        tr.dataset.quantity = response.data.quantity;
        tr.children[1].textContent = response.data.name;
        tr.children[2].textContent = response.data.quantity;

        // Close modal
        const editModal = bootstrap.Modal.getInstance(document.getElementById('editModal'));
        editModal.hide();
      } else {
        // Show error message
        const msgDiv = document.getElementById('edit-msg');
        msgDiv.textContent = response.message;
        msgDiv.classList.remove('d-none');
      }
    })
    .catch(() => {
      const msgDiv = document.getElementById('edit-msg');
      msgDiv.textContent = 'An error occurred. Please try again.';
      msgDiv.classList.remove('d-none');
    });
  });
});
</script>

<!-- Bootstrap 5 Bundle with Popper (for modals, dropdowns, etc.) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php
// AJAX handler for editing drug
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_ajax'])) {
    header('Content-Type: application/json');

    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $quantity = (int)($_POST['quantity'] ?? 0);

    if ($id <= 0 || empty($name) || $quantity < 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid input.']);
        exit;
    }

    // Update the drug in DB
    $stmt = $pdo->prepare("UPDATE drugs SET name = ?, quantity = ? WHERE id = ?");
    $success = $stmt->execute([$name, $quantity, $id]);

    if ($success) {
        echo json_encode([
          'success' => true,
          'data' => ['id' => $id, 'name' => htmlspecialchars($name, ENT_QUOTES), 'quantity' => $quantity]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update drug.']);
    }
    exit;
}

include __DIR__ . '/../includes/footer.php';
?>
