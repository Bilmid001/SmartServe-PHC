<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$pid = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("
    SELECT i.*, p.fullname, p.phone
    FROM immunizations i
    JOIN patients p ON i.patient_id = p.id
    WHERE p.id = :pid
    ORDER BY i.created_at DESC
");
$stmt->execute([':pid' => $pid]);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Patient Immunization History";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-4">Immunization History</h2>
  <?php if ($records): ?>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Vaccine</th>
        <th>Status</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($records as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['vaccine']) ?></td>
          <td><?= htmlspecialchars($r['status']) ?></td>
          <td><?= htmlspecialchars($r['created_at']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-info">No immunization records found for this patient.</div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
