<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';
if($_SESSION['role']!=='admin'){ header('Location: '.BASE_URL.'/error/403.php'); exit; }

$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    foreach($_POST as $k=>$v){
        $k = preg_replace('/[^a-z0-9_]/','',strtolower($k));
        $stmt = $pdo->prepare("SELECT id FROM settings WHERE `key`=?");
        $stmt->execute([$k]);
        if($stmt->fetch()){
            $pdo->prepare("UPDATE settings SET `value`=? WHERE `key`=?")->execute([$v,$k]);
        } else {
            $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?)")->execute([$k,$v]);
        }
    }
    $msg='Settings saved.';
}

// load settings as assoc
$rows = $pdo->query("SELECT `key`,`value` FROM settings")->fetchAll();
$settings = [];
foreach($rows as $r) $settings[$r['key']] = $r['value'];

$page_title='Hospital Settings';
include __DIR__ . '/../includes/header.php';
?>
<h2>Settings</h2>
<?php if($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<form method="post">
  <div class="mb-2"><label>Hospital Name</label><input name="hospital_name" class="form-control" value="<?= htmlspecialchars($settings['hospital_name'] ?? '') ?>"></div>
  <div class="mb-2"><label>Default Timezone</label><input name="timezone" class="form-control" value="<?= htmlspecialchars($settings['timezone'] ?? 'Africa/Lagos') ?>"></div>
  <div class="mb-2"><label>Records Dept Email</label><input name="records_email" class="form-control" value="<?= htmlspecialchars($settings['records_email'] ?? '') ?>"></div>
  <button class="btn btn-primary">Save Settings</button>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
