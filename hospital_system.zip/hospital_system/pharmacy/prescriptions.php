<?php
// pharmacy/prescriptions.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['pharmacy','doctor','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;

// Fetch prescriptions joined to patient
$stmt = $pdo->prepare("
    SELECT pr.*, p.fullname, p.phone, p.dob
    FROM prescriptions pr
    LEFT JOIN consultations c ON pr.consultation_id = c.id
    LEFT JOIN patients p ON c.patient_id = p.id
    ORDER BY pr.created_at DESC
    LIMIT :limit OFFSET :offset
");

$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Prescriptions";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-3">Prescriptions</h2>

  <form method="get" action="<?= BASE_URL ?>/records/search.php" class="row g-3 mb-3">
    <div class="col-md-5">
      <input type="text" name="q" class="form-control" placeholder="Search patient by ID, phone or name">
    </div>
    <div class="col-md-2"><button class="btn btn-primary">Search</button></div>
    <div class="col-md-3 text-end">
      <a class="btn btn-success" href="add_prescription.php">Create Prescription</a>
    </div>
  </form>

  <?php if ($prescriptions): ?>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Date</th>
          <th>Patient</th>
          <th>Phone</th>
          <th>Medicine</th>
          <th>Dosage</th>
          <th>Qty</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($prescriptions as $row): ?>
          <tr>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td>
              <?php if ($row['patient_id']): ?>
                <a href="../records/search.php?q=<?= urlencode($row['patient_id']) ?>"><?= htmlspecialchars($row['fullname'] ?: ('#'.$row['patient_id'])) ?></a>
              <?php else: ?>
                <span class="text-muted">Unknown</span>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['phone'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['medicine']) ?></td>
            <td><?= htmlspecialchars($row['dosage'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['quantity'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td>
              <a class="btn btn-sm btn-secondary" href="edit_prescription.php?id=<?= $row['id'] ?>">Edit</a>
              <a class="btn btn-sm btn-success" href="dispense.php?id=<?= $row['id'] ?>">Dispense</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="alert alert-info">No prescriptions found.</div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
