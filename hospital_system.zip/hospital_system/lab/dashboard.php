<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['lab','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$total_patients = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
$pending_labs = $pdo->query("SELECT COUNT(*) FROM lab_results WHERE status='pending'")->fetchColumn();
$completed_labs = $pdo->query("SELECT COUNT(*) FROM lab_results WHERE status='completed'")->fetchColumn();

// Get recent lab requests for the activity feed
$recent_labs = $pdo->query("SELECT lr.*, p.first_name, p.last_name 
                           FROM lab_results lr 
                           JOIN patients p ON lr.patient_id = p.id 
                           ORDER BY lr.created_at DESC 
                           LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Get test type distribution for the chart
$test_types = $pdo->query("SELECT test_type, COUNT(*) as count 
                          FROM lab_results 
                          GROUP BY test_type 
                          ORDER BY count DESC 
                          LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Lab Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
  :root {
    --primary: #4361ee;
    --secondary: #3f37c9;
    --success: #4cc9f0;
    --info: #4895ef;
    --warning: #f72585;
    --danger: #e63946;
    --light: #f8f9fa;
    --dark: #212529;
    --lab-gradient: linear-gradient(120deg, #667eea 0%, #764ba2 100%);
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    --hover-shadow: 0 14px 28px rgba(0, 0, 0, 0.25);
  }

  body {
    background-color: #f5f7fb;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .dashboard-header {
    background: var(--lab-gradient);
    padding: 2rem 0;
    margin-bottom: 2rem;
    border-radius: 0 0 20px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .ai-btn {
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    border: none;
    color: white;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(38, 132, 255, 0.4);
    transition: all 0.3s ease;
    border-radius: 50px;
    padding: 12px 25px;
  }

  .ai-btn:hover {
    background: linear-gradient(90deg, #2575fc, #6a11cb);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(38, 132, 255, 0.6);
  }

  .card {
    border: none;
    border-radius: 15px;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    margin-bottom: 1.5rem;
    overflow: hidden;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
  }

  .stat-card {
    padding: 1.5rem;
    color: white;
    border-radius: 15px;
    text-align: center;
    height: 100%;
  }

  .stat-card h5 {
    font-size: 1rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
  }

  .stat-card .number {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0;
  }

  .chart-container {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    margin-bottom: 1.5rem;
    height: 100%;
  }

  .chart-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
    text-align: center;
  }

  .activity-card {
    padding: 1.5rem;
  }

  .activity-card h5 {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .activity-item {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid #edf2f7;
    transition: background-color 0.2s;
  }

  .activity-item:hover {
    background-color: #f8fafc;
  }

  .activity-item:last-child {
    border-bottom: none;
  }

  .activity-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
    flex-shrink: 0;
  }

  .activity-content {
    flex-grow: 1;
  }

  .activity-patient {
    font-weight: 600;
    color: #2d3748;
  }

  .activity-test {
    color: #4a5568;
    font-size: 0.9rem;
  }

  .activity-time {
    color: #718096;
    font-size: 0.8rem;
    text-align: right;
  }

  .search-section {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: var(--card-shadow);
  }

  .search-title {
    font-size: 1.3rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .status-badge {
    padding: 0.35rem 0.65rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
  }

  @media (max-width: 768px) {
    .stat-card .number {
      font-size: 2rem;
    }
    
    .activity-item {
      flex-direction: column;
      align-items: flex-start;
    }
    
    .activity-time {
      margin-top: 0.5rem;
      text-align: left;
    }
  }
</style>

<div class="dashboard-header">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
      <div>
        <h2 class="text-white fw-bold mb-2">Lab Dashboard</h2>
        <p class="text-white mb-4">
          Welcome to the Lab Dashboard! Manage lab tests, view results, and track pending requests.
        </p>
      </div>
      
      <!-- AI Assistant Button -->
      <a href="#" class="btn ai-btn px-4 py-3 d-flex align-items-center gap-2" role="button" data-bs-toggle="modal" data-bs-target="#aiModal">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-robot" viewBox="0 0 16 16">
          <path d="M5 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM9 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0z"/>
          <path d="M2 8v1h12V8H2zm12-1V6H2v1h12zM1 10v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H1z"/>
        </svg>
        Smart Serve AI Assistant
      </a>

      <!-- Modal -->
      <div class="modal fade" id="aiModal" tabindex="-1" aria-labelledby="aiModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl"> <!-- modal-xl = big popup -->
          <div class="modal-content" style="height: 90vh;">
            <div class="modal-header">
              <h5 class="modal-title" id="aiModalLabel">🤖 Smart Serve AI Assistant</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
              <!-- Load your AI assistant page -->
              <iframe src="../aiphc.php" style="width:100%; height:100%; border:none; border-radius: 0 0 10px 10px;"></iframe>
            </div>
          </div>
        </div>
      </div>


<div class="container my-5">
  <div class="row">
    <!-- Stats Cards -->
    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #667eea, #764ba2);">
        <h5>Total Patients</h5>
        <p class="number"><?= $total_patients ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">All Time</span>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #f093fb, #f5576c);">
        <h5>Pending Tests</h5>
        <p class="number"><?= $pending_labs ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-warning text-dark">Needs Attention</span>
        </div>
      </div>
    </div>

    <div class="col-lg-4 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #4facfe, #00f2fe);">
        <h5>Completed Tests</h5>
        <p class="number"><?= $completed_labs ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">Processed</span>
        </div>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Test Distribution Chart -->
    <div class="col-lg-6 mb-4">
      <div class="chart-container">
        <h5 class="chart-title">Test Type Distribution</h5>
        <canvas id="testTypeChart"></canvas>
      </div>
    </div>

    <!-- Recent Activity -->
    <div class="col-lg-6 mb-4">
      <div class="card activity-card">
        <h5>Recent Lab Requests</h5>
        
        <?php if (count($recent_labs) > 0): ?>
          <?php foreach ($recent_labs as $lab): ?>
            <div class="activity-item">
              <div class="activity-icon" style="background-color: rgba(79, 172, 254, 0.2);">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#4facfe" class="bi bi-droplet" viewBox="0 0 16 16">
                  <path fill-rule="evenodd" d="M7.21.8C7.69.295 8 0 8 0c.109.363.234.708.371 1.038.812 1.946 2.073 3.35 3.197 4.6C12.878 7.096 14 8.345 14 10a6 6 0 0 1-12 0C2 6.668 5.58 2.517 7.21.8zm.413 1.021A31.25 31.25 0 0 0 5.794 3.99c-.726.95-1.436 2.008-1.96 3.07C3.304 8.133 3 9.138 3 10a5 5 0 0 0 10 0c0-1.201-.796-2.157-2.181-3.7l-.03-.032C9.75 5.11 8.5 3.72 7.623 1.82z"/>
                  <path fill-rule="evenodd" d="M4.553 7.776c.82-1.641 1.717-2.753 2.093-3.13l.708.708c-.29.29-1.128 1.311-1.907 2.87l-.894-.448z"/>
                </svg>
              </div>
              <div class="activity-content">
                <div class="activity-patient"><?= htmlspecialchars($lab['first_name'] . ' ' . $lab['last_name']) ?></div>
                <div class="activity-test"><?= htmlspecialchars($lab['test_type']) ?></div>
              </div>
              <div class="activity-time">
                <?php 
                  $date = new DateTime($lab['created_at']);
                  echo $date->format('M j, Y');
                ?>
                <br>
                <span class="status-badge <?= $lab['status'] == 'completed' ? 'bg-success' : 'bg-warning' ?>">
                  <?= ucfirst($lab['status']) ?>
                </span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-muted">No recent lab requests</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Search Section -->
  <div class="row mt-4">
    <div class="col-12">
      <div class="search-section">
        <h4 class="search-title">Find Patient</h4>
        <form method="get" action="<?= BASE_URL ?>/records/search.php" class="row g-3">
          <div class="col-md-8">
            <input type="text" name="q" class="form-control form-control-lg" placeholder="Enter Patient ID, Name, or Phone Number">
          </div>
          <div class="col-md-4">
            <button type="submit" class="btn btn-primary btn-lg w-100">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search me-2" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
              Search Patient
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Test Type Distribution Chart
    const testTypeCtx = document.getElementById('testTypeChart').getContext('2d');
    new Chart(testTypeCtx, {
      type: 'pie',
      data: {
        labels: [<?php foreach($test_types as $type): ?>'<?= $type['test_type'] ?>', <?php endforeach; ?>],
        datasets: [{
          data: [<?php foreach($test_types as $type): ?><?= $type['count'] ?>, <?php endforeach; ?>],
          backgroundColor: [
            '#4361ee', '#4cc9f0', '#f72585', '#7209b7', '#3a0ca3'
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>