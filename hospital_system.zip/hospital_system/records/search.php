<?php
// records/search.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$q = trim($_GET['q'] ?? '');


$q = trim($_GET['q'] ?? '');

$patients = [];
if ($q !== '') {
    $stmt = $pdo->prepare("
        SELECT id, fullname, gender, dob, phone, address, next_of_kin, nok_phone, fingerprint, notes, status, created_at
        FROM patients
        WHERE id = :id OR phone = :phone OR fullname LIKE :name
    ");
    $stmt->execute([
        ':id' => $q,
        ':phone' => $q,
        ':name' => "%$q%"
    ]);
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$page_title = "Search Patients";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-4">Search Patients</h2>

  <form method="get" class="row g-3 mb-3">
    <div class="col-md-6">
      <input type="text" name="q" class="form-control" placeholder="Enter Patient ID, Phone, or Name" value="<?= htmlspecialchars($q) ?>">
    </div>
    <div class="col-md-3">
      <button type="submit" class="btn btn-primary">Search</button>
    </div>
  </form>

  <?php if ($q !== ''): ?>
    <h5>Search Results</h5>
    <?php if ($patients): ?>
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Fullname</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Next of Kin</th>
            <th>NOK Phone</th>
            <th>Fingerprint</th>
            <th>Status</th>
            <th>Notes</th>
            <th>Registered</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($patients as $p): ?>
            <tr>
              <td><?= htmlspecialchars($p['id']) ?></td>
              <td><?= htmlspecialchars($p['fullname']) ?></td>
              <td><?= htmlspecialchars($p['gender']) ?></td>
              <td><?= htmlspecialchars($p['dob']) ?></td>
              <td><?= htmlspecialchars($p['phone']) ?></td>
              <td><?= htmlspecialchars($p['address']) ?></td>
              <td><?= htmlspecialchars($p['next_of_kin']) ?></td>
              <td><?= htmlspecialchars($p['nok_phone']) ?></td>
              <td><?= htmlspecialchars($p['fingerprint']) ?></td>
              <td><?= htmlspecialchars($p['status']) ?></td>
              <td><?= htmlspecialchars($p['notes']) ?></td>
              <td><?= htmlspecialchars($p['created_at']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <div class="alert alert-warning">No patients found for "<?= htmlspecialchars($q) ?>"</div>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
