<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hospital System - Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: url('assets/img/hospital.jpg') center/cover no-repeat;
      color: white; text-align: center;
      padding: 100px 20px;
    }
    .hero h1 { font-size: 3rem; font-weight: bold; }
    .services .card { transition: transform 0.3s; }
    .services .card:hover { transform: translateY(-5px); }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="#">Hospital System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
        <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
        <li class="nav-item"><a class="nav-link" href="auth/login.php">Login</a></li>
      </ul>
    </div>
  </div>
</nav>

<section class="hero">
  <h1>Welcome to Primary Healthcare System</h1>
  <p>Comprehensive digital healthcare records and services for your community.</p>
  <a href="auth/login.php" class="btn btn-light btn-lg">Staff Login</a>
</section>

<section id="about" class="container py-5">
  <h2 class="text-center mb-4">About Us</h2>
  <p class="text-center">This hospital system integrates records, doctors, lab, pharmacy, and community health into one seamless platform. It improves efficiency, tracking, and patient care in local communities.</p>
</section>

<section id="services" class="services bg-light py-5">
  <div class="container">
    <h2 class="text-center mb-4">Our Services</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card text-center p-3">
          <h5>Patient Records</h5>
          <p>Secure and centralized patient file management.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card text-center p-3">
          <h5>Laboratory</h5>
          <p>Track and manage lab tests efficiently.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card text-center p-3">
          <h5>Pharmacy</h5>
          <p>Manage prescriptions and drug stock with ease.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="contact" class="container py-5">
  <h2 class="text-center mb-4">Contact Us</h2>
  <p class="text-center">123 Health Street, Community Hospital<br>Email: info@hospital.com | Phone: +234 800 123 4567</p>
</section>

<footer class="bg-primary text-white text-center p-3">
  <p>&copy; <?= date('Y') ?> Hospital System. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
