<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$stmt = $pdo->query("
    SELECT i.*, p.fullname, p.phone, p.gender, p.dob
    FROM immunizations i
    JOIN patients p ON i.patient_id = p.id
    WHERE i.status = 'pending'
    ORDER BY i.created_at DESC
");
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Pending Immunizations";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-4">Pending Immunizations</h2>
  <?php if ($requests): ?>
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Patient</th>
        <th>Vaccine</th>
        <!-- <th>Status</th> -->
        <th>Date Requested</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($requests as $r): ?>
      <tr>
        <td><?= htmlspecialchars($r['fullname']) ?> (<?= htmlspecialchars($r['phone']) ?>)</td>
        <td><?= htmlspecialchars($r['vaccine_name']) ?></td>
        <!-- <td><span class="badge bg-warning">Pending</span></td> -->
        <td><?= htmlspecialchars($r['created_at']) ?></td>
        <td>
          <a href="edit_immunization.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-primary">Update</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php else: ?>
    <div class="alert alert-info">No pending immunizations found.</div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
