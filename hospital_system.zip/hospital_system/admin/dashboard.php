<?php
// admin/dashboard.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$page_title = "Admin Dashboard";
include __DIR__ . '/../includes/header.php';

// Patients
$total_patients = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();

// Consultations
$pending_consultations = $pdo->query("SELECT COUNT(*) FROM consultations WHERE status='pending'")->fetchColumn();
$completed_consultations = $pdo->query("SELECT COUNT(*) FROM consultations WHERE status='completed'")->fetchColumn();

// Lab Requests
$requested_tests = $pdo->query("SELECT COUNT(*) FROM lab_requests WHERE status='requested'")->fetchColumn();
$completed_tests = $pdo->query("SELECT COUNT(*) FROM lab_requests WHERE status='completed'")->fetchColumn();

// Prescriptions
$pending_rx = $pdo->query("SELECT COUNT(*) FROM prescriptions WHERE status='pending'")->fetchColumn();
$dispensed_rx = $pdo->query("SELECT COUNT(*) FROM prescriptions WHERE status='dispensed'")->fetchColumn();

// Immunizations
$pending_vaccines = $pdo->query("SELECT COUNT(*) FROM immunizations WHERE status='pending'")->fetchColumn();
$given_vaccines = $pdo->query("SELECT COUNT(*) FROM immunizations WHERE status='given'")->fetchColumn();

// Inspections
$open_inspections = $pdo->query("SELECT COUNT(*) FROM inspections WHERE status='open'")->fetchColumn();
$closed_inspections = $pdo->query("SELECT COUNT(*) FROM inspections WHERE status='closed'")->fetchColumn();

// Get data for charts
$consultation_data = [$pending_consultations, $completed_consultations];
$lab_data = [$requested_tests, $completed_tests];
$prescription_data = [$pending_rx, $dispensed_rx];
$immunization_data = [$pending_vaccines, $given_vaccines];
$inspection_data = [$open_inspections, $closed_inspections];
?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
  :root {
    --primary: #4361ee;
    --secondary: #3f37c9;
    --success: #4cc9f0;
    --info: #4895ef;
    --warning: #f72585;
    --danger: #e63946;
    --light: #f8f9fa;
    --dark: #212529;
    --bg-gradient: linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%);
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    --hover-shadow: 0 14px 28px rgba(0, 0, 0, 0.25);
  }

  body {
    background-color: #f5f7fb;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .dashboard-header {
    background: var(--bg-gradient);
    padding: 2rem 0;
    margin-bottom: 2rem;
    border-radius: 0 0 20px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .ai-btn {
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    border: none;
    color: white;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(38, 132, 255, 0.4);
    transition: all 0.3s ease;
    border-radius: 50px;
    padding: 12px 25px;
  }

  .ai-btn:hover {
    background: linear-gradient(90deg, #2575fc, #6a11cb);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(38, 132, 255, 0.6);
  }

  .dashboard-intro {
    font-size: 1.1rem;
    color: #4a5568;
    line-height: 1.6;
    max-width: 800px;
  }

  .card {
    border: none;
    border-radius: 15px;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    margin-bottom: 1.5rem;
    overflow: hidden;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
  }

  .card-title {
    font-weight: 700;
    font-size: 1.1rem;
    color: #2d3748;
    margin-bottom: 1rem;
  }

  .stat-card {
    padding: 1.5rem;
    color: white;
    border-radius: 15px;
  }

  .stat-card h5 {
    font-size: 1rem;
    margin-bottom: 0.5rem;
  }

  .stat-card .number {
    font-size: 2.2rem;
    font-weight: 700;
    margin-bottom: 0;
  }

  .chart-container {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    margin-bottom: 1.5rem;
    height: 100%;
  }

  .chart-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
    text-align: center;
  }

  .summary-card {
    padding: 1.5rem;
  }

  .summary-card h6 {
    font-weight: 600;
    color: #4a5568;
    margin-bottom: 1rem;
  }

  .summary-item {
    display: flex;
    justify-content: space-between;
    padding: 0.5rem 0;
    border-bottom: 1px solid #edf2f7;
  }

  .summary-item:last-child {
    border-bottom: none;
  }

  .badge {
    padding: 0.5rem 0.8rem;
    border-radius: 50px;
    font-weight: 600;
  }

  @media (max-width: 768px) {
    .stat-card .number {
      font-size: 1.8rem;
    }
    
    .dashboard-intro {
      font-size: 1rem;
    }
  }
</style>

<div class="dashboard-header">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
      <div>
        <h2 class="text-white fw-bold mb-2">Admin Dashboard</h2>
        <p class="dashboard-intro text-white mb-4">
          Welcome to the Admin Dashboard! Here you can efficiently manage user accounts,
          monitor system activity, and configure application settings to ensure smooth operation.
        </p>
      </div>
      
      <!-- AI Button -->
      <a href="#" class="btn ai-btn px-4 py-3 d-flex align-items-center gap-2" role="button" data-bs-toggle="modal" data-bs-target="#aiModal">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-robot" viewBox="0 0 16 16">
          <path d="M5 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM9 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0z"/>
          <path d="M2 8v1h12V8H2zm12-1V6H2v1h12zM1 10v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H1z"/>
        </svg>
        Smart Serve AI Assistant
      </a>

      <!-- Modal -->
      <div class="modal fade" id="aiModal" tabindex="-1" aria-labelledby="aiModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl"> <!-- modal-xl = big popup -->
          <div class="modal-content" style="height: 90vh;">
            <div class="modal-header">
              <h5 class="modal-title" id="aiModalLabel">🤖 Smart Serve AI Assistant</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
              <!-- Load your AI assistant page -->
              <iframe src="../aiphc.php" style="width:100%; height:100%; border:none; border-radius: 0 0 10px 10px;"></iframe>
            </div>
          </div>
        </div>
      </div>

<div class="container my-5">
  <div class="row">
    <!-- Main Stats Cards -->
    <div class="col-lg-3 col-md-6">
      <div class="stat-card" style="background: linear-gradient(120deg, #4361ee, #3a0ca3);">
        <h5>Total Patients</h5>
        <p class="number"><?= $total_patients ?></p>
        <div class="d-flex align-items-center">
          <span class="badge bg-light text-dark">Registered</span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6">
      <div class="stat-card" style="background: linear-gradient(120deg, #7209b7, #560bad);">
        <h5>Consultations</h5>
        <p class="number"><?= $pending_consultations + $completed_consultations ?></p>
        <div class="d-flex align-items-center gap-2">
          <span class="badge bg-warning text-dark">Pending: <?= $pending_consultations ?></span>
          <span class="badge bg-success">Completed: <?= $completed_consultations ?></span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6">
      <div class="stat-card" style="background: linear-gradient(120deg, #f72585, #b5179e);">
        <h5>Lab Tests</h5>
        <p class="number"><?= $requested_tests + $completed_tests ?></p>
        <div class="d-flex align-items-center gap-2">
          <span class="badge bg-warning text-dark">Requested: <?= $requested_tests ?></span>
          <span class="badge bg-success">Completed: <?= $completed_tests ?></span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6">
      <div class="stat-card" style="background: linear-gradient(120deg, #4cc9f0, #4895ef);">
        <h5>Prescriptions</h5>
        <p class="number"><?= $pending_rx + $dispensed_rx ?></p>
        <div class="d-flex align-items-center gap-2">
          <span class="badge bg-warning text-dark">Pending: <?= $pending_rx ?></span>
          <span class="badge bg-success">Dispensed: <?= $dispensed_rx ?></span>
        </div>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Charts Section -->
    <div class="col-lg-8">
      <div class="row">
      <div class="col-md-6">
          <div class="chart-container">
            <h5 class="chart-title">Immunizations</h5>
            <canvas id="immunizationChart"></canvas>
          </div>
        </div>
        <div class="col-md-6">
          <div class="chart-container">
            <h5 class="chart-title">Consultations</h5>
            <canvas id="consultationChart"></canvas>
          </div>
        </div>
        <div class="col-md-6">
          <div class="chart-container">
            <h5 class="chart-title">Lab Tests</h5>
            <canvas id="labChart"></canvas>
          </div>
        </div>
        <div class="col-md-6">
          <div class="chart-container">
            <h5 class="chart-title">Prescriptions</h5>
            <canvas id="prescriptionChart"></canvas>
          </div>
        </div>
      </div>
    </div>

    <!-- Summary Section -->
    <div class="col-lg-4">
      <div class="card summary-card">
        <h6>Activity Summary</h6>
        
        <div class="summary-item">
          <span>Patients</span>
          <span class="fw-bold"><?= $total_patients ?></span>
        </div>
        
        <div class="summary-item">
          <span>Pending Consultations</span>
          <span class="fw-bold text-warning"><?= $pending_consultations ?></span>
        </div>
        
        <div class="summary-item">
          <span>Completed Consultations</span>
          <span class="fw-bold text-success"><?= $completed_consultations ?></span>
        </div>
        
        <div class="summary-item">
          <span>Requested Lab Tests</span>
          <span class="fw-bold text-warning"><?= $requested_tests ?></span>
        </div>
        
        <div class="summary-item">
          <span>Completed Lab Tests</span>
          <span class="fw-bold text-success"><?= $completed_tests ?></span>
        </div>
        
        <div class="summary-item">
          <span>Pending Prescriptions</span>
          <span class="fw-bold text-warning"><?= $pending_rx ?></span>
        </div>
        
        <div class="summary-item">
          <span>Dispensed Prescriptions</span>
          <span class="fw-bold text-success"><?= $dispensed_rx ?></span>
        </div>
        
        <div class="summary-item">
          <span>Pending Immunizations</span>
          <span class="fw-bold text-warning"><?= $pending_vaccines ?></span>
        </div>
        
        <div class="summary-item">
          <span>Given Immunizations</span>
          <span class="fw-bold text-success"><?= $given_vaccines ?></span>
        </div>
        
        <div class="summary-item">
          <span>Open Inspections</span>
          <span class="fw-bold text-warning"><?= $open_inspections ?></span>
        </div>
        
        <div class="summary-item">
          <span>Closed Inspections</span>
          <span class="fw-bold text-success"><?= $closed_inspections ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Consultation Chart
    const consultationCtx = document.getElementById('consultationChart').getContext('2d');
    new Chart(consultationCtx, {
      type: 'doughnut',
      data: {
        labels: ['Pending', 'Completed'],
        datasets: [{
          data: [<?= $pending_consultations ?>, <?= $completed_consultations ?>],
          backgroundColor: ['#ffc107', '#28a745'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

    // Lab Chart
    const labCtx = document.getElementById('labChart').getContext('2d');
    new Chart(labCtx, {
      type: 'doughnut',
      data: {
        labels: ['Requested', 'Completed'],
        datasets: [{
          data: [<?= $requested_tests ?>, <?= $completed_tests ?>],
          backgroundColor: ['#ffc107', '#28a745'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

    // Prescription Chart
    const prescriptionCtx = document.getElementById('prescriptionChart').getContext('2d');
    new Chart(prescriptionCtx, {
      type: 'doughnut',
      data: {
        labels: ['Pending', 'Dispensed'],
        datasets: [{
          data: [<?= $pending_rx ?>, <?= $dispensed_rx ?>],
          backgroundColor: ['#ffc107', '#28a745'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });

    // Immunization Chart
    const immunizationCtx = document.getElementById('immunizationChart').getContext('2d');
    new Chart(immunizationCtx, {
      type: 'doughnut',
      data: {
        labels: ['Pending', 'Given'],
        datasets: [{
          data: [<?= $pending_vaccines ?>, <?= $given_vaccines ?>],
          backgroundColor: ['#ffc107', '#28a745'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>
