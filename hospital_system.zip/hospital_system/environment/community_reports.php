<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['admin','environment'])) {
    header("Location: ../error/403.php");
    exit;
}

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="community_cases.csv"');

$out = fopen('php://output', 'w');
fputcsv($out, ['id','case_type','description','reported_at','reported_by']);
foreach ($pdo->query("SELECT id, case_type, description, reported_at, reported_by FROM community_cases ORDER BY reported_at DESC") as $r) {
    fputcsv($out, [$r['id'], $r['case_type'], $r['description'], $r['reported_at'], $r['reported_by']]);
}
fclose($out);
exit;
