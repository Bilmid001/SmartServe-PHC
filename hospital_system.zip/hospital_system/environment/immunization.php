<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['admin','environment'])) {
    header("Location: ../error/403.php");
    exit;
}

$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = (int)($_POST['patient_id'] ?? 0);
    $vaccine = trim($_POST['vaccine'] ?? '');
    $date = $_POST['date'] ?? null;

    if ($patient_id && $vaccine && $date) {
        $stmt = $pdo->prepare("INSERT INTO immunizations (patient_id, vaccine_name, given_at, given_by) VALUES (?,?,?,?)");
        $stmt->execute([$patient_id, $vaccine, $date, $_SESSION['user_id']]);
        $msg = "Immunization recorded.";
    } else {
        $msg = "Please provide patient, vaccine and date.";
    }
}

// show ALL patients (no limit)
$patients = $pdo->query("SELECT id, first_name, last_name FROM patients ORDER BY id DESC")->fetchAll();

$page_title = "Record Immunization";
include __DIR__ . '/../includes/header.php';
?>
<h2>Record Immunization</h2>
<?php if($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<form method='post'>
  <div class='mb-3'>
    <label>Patient</label>
    <select name='patient_id' class='form-control' required>
      <?php foreach($patients as $p): ?>
        <option value='<?= $p['id'] ?>'><?= htmlspecialchars($p['first_name'].' '.$p['last_name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class='mb-3'>
    <label>Vaccine</label>
    <input type='text' name='vaccine' class='form-control' required>
  </div>
  <div class='mb-3'>
    <label>Date</label>
    <input type='date' name='date' class='form-control' required>
  </div>
  <button class='btn btn-primary'>Save</button>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
