<?php
// lab/patient_history.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$page_title = "Patient Lab History";
include __DIR__ . '/../includes/header.php';

$patient_id = $_GET['patient_id'] ?? null;
if (!$patient_id) {
    echo "<div class='alert alert-danger'>No patient selected.</div>";
    include __DIR__ . '/../includes/footer.php';
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = :id");
$stmt->execute([':id' => $patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    echo "<div class='alert alert-danger'>Patient not found.</div>";
    include __DIR__ . '/../includes/footer.php';
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM lab_requests WHERE patient_id = :id ORDER BY created_at DESC");
$stmt->execute([':id' => $patient_id]);
$lab_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container">
  <h2 class="mb-4">Lab History for <?= htmlspecialchars($patient['fullname']) ?></h2>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Date</th>
        <th>Test</th>
        <th>Result</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php if (empty($lab_results)): ?>
      <tr><td colspan="5" class="text-center">No lab records found.</td></tr>
    <?php else: ?>
      <?php foreach ($lab_results as $row): ?>
        <tr id="labrow-<?= $row['id'] ?>">
          <td><?= htmlspecialchars($row['created_at']) ?></td>
          <td><?= htmlspecialchars($row['test_name']) ?></td>
          <td><?= nl2br(htmlspecialchars($row['result'] ?? '-')) ?></td>
          <td><?= htmlspecialchars($row['status']) ?></td>
          <td>
            <a class="btn btn-sm btn-secondary" href="edit_result.php?id=<?= $row['id'] ?>">Edit</a>
            <?php if ($row['status'] === 'pending'): ?>
              <a class="btn btn-sm btn-success" href="add_result.php?lab_id=<?= $row['id'] ?>">Add Result</a>
            <?php endif; ?>
            <button class="btn btn-sm btn-info ai-explain-btn"
              data-lab-id="<?= $row['id'] ?>"
              data-test="<?= htmlspecialchars($row['test_name'], ENT_QUOTES) ?>"
              data-result="<?= htmlspecialchars($row['result'] ?? '', ENT_QUOTES) ?>">
              Explain Result
            </button>
          </td>
        </tr>
        <tr id="labrow-explain-<?= $row['id'] ?>" style="display:none;">
          <td colspan="5">
            <div class="card card-body">
              <strong>AI Explanation:</strong>
              <div id="ai-explain-output-<?= $row['id'] ?>">Loading...</div>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<script>
document.querySelectorAll('.ai-explain-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const labId = btn.dataset.labId;
    const test = btn.dataset.test || '';
    const result = btn.dataset.result || '';
    const input = `Test: ${test}\nResult: ${result}`;

    const explainRow = document.getElementById('labrow-explain-' + labId);
    const outputDiv = document.getElementById('ai-explain-output-' + labId);
    explainRow.style.display = '';
    outputDiv.textContent = 'Sending to AI...';

    try {
      const res = await fetch('/includes/hf_proxy.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({task:'lab_explain', input: input, options: {max_tokens: 300}})
      });

      if (!res.ok) {
        const err = await res.json();
        outputDiv.textContent = 'Error: ' + (err.error || res.status);
        return;
      }

      const body = await res.text();
      let parsed, out;
      try { parsed = JSON.parse(body); } catch(e) { parsed = body; }
      if (Array.isArray(parsed)) {
        out = parsed[0].generated_text || JSON.stringify(parsed, null, 2);
      } else if (typeof parsed === 'object') {
        out = JSON.stringify(parsed, null, 2);
      } else {
        out = String(parsed);
      }
      out += "\n\n[Disclaimer] This explanation is informational only and not a medical diagnosis.";
      outputDiv.textContent = out;
    } catch (err) {
      outputDiv.textContent = 'Request failed: ' + err;
    }
  });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
