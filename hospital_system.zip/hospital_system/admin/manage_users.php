<?php
require_once __DIR__ . '/../includes/config.php';       // load config first (defines BASE_URL)
require_once __DIR__ . '/../includes/auth_check.php';   // then auth_check (uses BASE_URL)
require_once __DIR__ . '/../includes/db.php';           // then db


if ($_SESSION['role'] !== 'admin') {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$err = '';
$msg = '';

// Verify session user is valid (exists in DB)
$userId = $_SESSION['user_id'] ?? null;
if ($userId) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    if (!$stmt->fetch()) {
        // User in session no longer exists - force logout
        session_destroy();
        header('Location: ' . BASE_URL . '/auth/login.php?error=SessionExpired');
        exit;
    }
} else {
    // No user id in session - force login
    header('Location: ' . BASE_URL . '/auth/login.php');
    exit;
}

// create user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    if ($username && $password && $role) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username=?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $err = 'Username already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)")
                ->execute([$username, $hash, $role]);
            $msg = 'User created.';

            // log action safely
            try {
                $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id) VALUES (?, ?, ?, ?)")
                    ->execute([$userId, "create_user:{$username}", 'users', null]);
            } catch (PDOException $e) {
                // Optional: log error somewhere else or ignore
                error_log("Audit log insert failed: " . $e->getMessage());
            }
        }
    } else {
        $err = 'Provide username, password and role.';
    }
}

// delete user
if (isset($_GET['delete'])) {
    $del = (int)$_GET['delete'];
    if ($del === $userId) {
        $err = 'Cannot delete yourself.';
    } else {
        $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$del]);
        $msg = 'User deleted.';

        try {
            $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id) VALUES (?, ?, ?, ?)")
                ->execute([$userId, "delete_user:{$del}", 'users', $del]);
        } catch (PDOException $e) {
            error_log("Audit log insert failed: " . $e->getMessage());
        }
    }
}

// fetch users
$users = $pdo->query("SELECT id,username,role,created_at FROM users ORDER BY id DESC")->fetchAll();
$roles = ['admin', 'records', 'doctor', 'lab', 'pharmacy', 'environment'];

$page_title = 'Manage Users';
include __DIR__ . '/../includes/header.php';
?>

<h2>Manage Staff Users</h2>
<?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>
<?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<div class="row">
  <div class="col-md-5">
    <h5>Create Staff</h5>
    <form method="post">
      <input type="hidden" name="create" value="1">
      <div class="mb-2"><label>Username</label><input name="username" class="form-control" required></div>
      <div class="mb-2"><label>Password</label><input name="password" type="password" class="form-control" required></div>
      <div class="mb-2"><label>Role</label><select name="role" class="form-control"><?php foreach ($roles as $r) echo "<option value=\"$r\">$r</option>"; ?></select></div>
      <button class="btn btn-success">Create</button>
    </form>
  </div>
  <div class="col-md-7">
    <h5>Existing Users</h5>
    <table class="table table-sm">
      <thead>
        <tr><th>ID</th><th>Username</th><th>Role</th><th>Created</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['username']) ?></td>
            <td><?= htmlspecialchars($u['role']) ?></td>
            <td><?= $u['created_at'] ?></td>
            <td>
              <?php if ($u['id'] != $userId): ?>
                <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete user?')">Delete</a>
              <?php else: ?>
                <span class="text-muted">You</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
