<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

if (!in_array($_SESSION['role'], ['doctor','admin'])) {
    header('Location: ' . BASE_URL . '/error/403.php');
    exit;
}

$total_patients = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();

$my_consults = $pdo->prepare("SELECT COUNT(*) FROM consultations WHERE doctor_id=?");
$my_consults->execute([$_SESSION['user_id']]);
$my_consults = $my_consults->fetchColumn();

$pending_labs = $pdo->query("SELECT COUNT(*) FROM lab_results WHERE status='pending'")->fetchColumn();
$active_prescriptions = $pdo->query("SELECT COUNT(*) FROM prescriptions WHERE status='active'")->fetchColumn();

// Get today's appointments
$today_appointments = $pdo->prepare("
    SELECT c.*, p.first_name, p.last_name, p.dob 
    FROM consultations c 
    JOIN patients p ON c.patient_id = p.id 
    WHERE c.doctor_id = ? 
      AND DATE(c.created_at) = CURDATE() 
    ORDER BY c.created_at
");


$today_appointments->execute([$_SESSION['user_id']]);
$today_appointments = $today_appointments->fetchAll(PDO::FETCH_ASSOC);

// Get consultation statistics
$consultation_stats = $pdo->prepare("
    SELECT status, COUNT(*) as count 
    FROM consultations 
    WHERE doctor_id = ? 
    GROUP BY status
");
$consultation_stats->execute([$_SESSION['user_id']]);
$consultation_stats = $consultation_stats->fetchAll(PDO::FETCH_ASSOC);

// Get upcoming appointments (next 7 days)
$upcoming_appointments = $pdo->prepare("
    SELECT COUNT(*) as count 
    FROM consultations 
    WHERE doctor_id = ? 
      AND DATE(created_at) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
");

$upcoming_appointments->execute([$_SESSION['user_id']]);
$upcoming_appointments = $upcoming_appointments->fetchColumn();

$page_title = "Doctor Dashboard";
include __DIR__ . '/../includes/header.php';
?>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
  :root {
    --primary: #4361ee;
    --secondary: #3f37c9;
    --success: #4cc9f0;
    --info: #4895ef;
    --warning: #f72585;
    --danger: #e63946;
    --light: #f8f9fa;
    --dark: #212529;
    --doctor-gradient: linear-gradient(120deg, #667eea 0%, #764ba2 100%);
    --card-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
    --hover-shadow: 0 14px 28px rgba(0, 0, 0, 0.25);
  }

  body {
    background-color: #f5f7fb;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .dashboard-header {
    background: var(--doctor-gradient);
    padding: 2rem 0;
    margin-bottom: 2rem;
    border-radius: 0 0 20px 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }

  .ai-btn {
    background: linear-gradient(90deg, #6a11cb, #2575fc);
    border: none;
    color: white;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(38, 132, 255, 0.4);
    transition: all 0.3s ease;
    border-radius: 50px;
    padding: 12px 25px;
  }

  .ai-btn:hover {
    background: linear-gradient(90deg, #2575fc, #6a11cb);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(38, 132, 255, 0.6);
  }

  .card {
    border: none;
    border-radius: 15px;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    margin-bottom: 1.5rem;
    overflow: hidden;
  }

  .card:hover {
    transform: translateY(-5px);
    box-shadow: var(--hover-shadow);
  }

  .stat-card {
    padding: 1.5rem;
    color: white;
    border-radius: 15px;
    text-align: center;
    height: 100%;
  }

  .stat-card h5 {
    font-size: 1rem;
    margin-bottom: 0.5rem;
    font-weight: 600;
  }

  .stat-card .number {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0;
  }

  .chart-container {
    background: white;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
    margin-bottom: 1.5rem;
    height: 100%;
  }

  .chart-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
    text-align: center;
  }

  .appointment-card {
    padding: 1.5rem;
  }

  .appointment-card h5 {
    font-size: 1.2rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .appointment-item {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid #edf2f7;
    transition: background-color 0.2s;
  }

  .appointment-item:hover {
    background-color: #f8fafc;
  }

  .appointment-item:last-child {
    border-bottom: none;
  }

  .appointment-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 1rem;
    flex-shrink: 0;
  }

  .appointment-content {
    flex-grow: 1;
  }

  .appointment-patient {
    font-weight: 600;
    color: #2d3748;
  }

  .appointment-time {
    color: #4a5568;
    font-size: 0.9rem;
  }

  .appointment-status {
    color: #718096;
    font-size: 0.8rem;
    text-align: right;
  }

  .search-section {
    background: white;
    border-radius: 15px;
    padding: 2rem;
    box-shadow: var(--card-shadow);
  }

  .search-title {
    font-size: 1.3rem;
    font-weight: 600;
    color: #2d3748;
    margin-bottom: 1.5rem;
  }

  .status-badge {
    padding: 0.35rem 0.65rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
  }

  .quick-action-card {
    text-align: center;
    height: 100%;
    padding: 1.5rem;
  }

  .quick-action-card .icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    color: #667eea;
  }

  @media (max-width: 768px) {
    .stat-card .number {
      font-size: 2rem;
    }
    
    .appointment-item {
      flex-direction: column;
      align-items: flex-start;
    }
    
    .appointment-status {
      margin-top: 0.5rem;
      text-align: left;
    }
  }
</style>

<div class="dashboard-header">
  <div class="container">
    <div class="d-flex justify-content-between align-items-center flex-wrap">
      <div>
        <h2 class="text-white fw-bold mb-2">Doctor Dashboard</h2>
        <p class="text-white mb-4">
          Welcome, Doctor! Manage your consultations, review patient records, and provide quality healthcare.
        </p>
      </div>
      
      <!-- AI Assistant Button -->
      <a href="#" class="btn ai-btn px-4 py-3 d-flex align-items-center gap-2" role="button" data-bs-toggle="modal" data-bs-target="#aiModal">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-robot" viewBox="0 0 16 16">
          <path d="M5 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM9 4a1 1 0 1 1 2 0 1 1 0 0 1-2 0z"/>
          <path d="M2 8v1h12V8H2zm12-1V6H2v1h12zM1 10v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H1z"/>
        </svg>
        Smart Serve AI Assistant
      </a>

      <!-- Modal -->
      <div class="modal fade" id="aiModal" tabindex="-1" aria-labelledby="aiModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl"> <!-- modal-xl = big popup -->
          <div class="modal-content" style="height: 90vh;">
            <div class="modal-header">
              <h5 class="modal-title" id="aiModalLabel">🤖 Smart Serve AI Assistant</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
              <!-- Load your AI assistant page -->
              <iframe src="../aiphc.php" style="width:100%; height:100%; border:none; border-radius: 0 0 10px 10px;"></iframe>
            </div>
          </div>
        </div>
      </div>


<div class="container my-5">
  <div class="row">
    <!-- Stats Cards -->
    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #667eea, #764ba2);">
        <h5>Total Patients</h5>
        <p class="number"><?= $total_patients ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">All Patients</span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #4facfe, #00f2fe);">
        <h5>My Consultations</h5>
        <p class="number"><?= $my_consults ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">All Time</span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #ff6b6b, #ff9e7d);">
        <h5>Pending Lab Results</h5>
        <p class="number"><?= $pending_labs ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-warning text-dark">Awaiting Results</span>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 mb-4">
      <div class="stat-card" style="background: linear-gradient(120deg, #1dd1a1, #10ac84);">
        <h5>Active Prescriptions</h5>
        <p class="number"><?= $active_prescriptions ?></p>
        <div class="d-flex justify-content-center">
          <span class="badge bg-light text-dark">Current</span>
        </div>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Consultation Stats Chart -->
    <div class="col-lg-6 mb-4">
      <div class="chart-container">
        <h5 class="chart-title">Consultation Status Distribution</h5>
        <canvas id="consultationChart"></canvas>
      </div>
    </div>

    <!-- Today's Appointments -->
    <div class="col-lg-6 mb-4">
      <div class="card appointment-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5>Today's Appointments</h5>
          <span class="badge bg-primary"><?= count($today_appointments) ?></span>
        </div>
        
        <?php if (count($today_appointments) > 0): ?>
          <?php foreach ($today_appointments as $appointment): ?>
            <div class="appointment-item">
              <div class="appointment-icon" style="background-color: rgba(102, 126, 234, 0.2);">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#667eea" class="bi bi-calendar-check" viewBox="0 0 16 16">
                  <path d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
                  <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/>
                </svg>
              </div>
              <div class="appointment-content">
                <div class="appointment-patient"><?= htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']) ?></div>
                <div class="appointment-time">
                <?php 
                if (!empty($appointment['appointment_date'])) {
                    $appointmentTime = new DateTime($appointment['appointment_date']);
                    echo $appointmentTime->format('h:i A');
                } else {
                    echo "No appointment date set";
                }
                ?>
                </div>
              </div>
              <div class="appointment-status">
                <span class="status-badge <?= $appointment['status'] == 'completed' ? 'bg-success' : ($appointment['status'] == 'cancelled' ? 'bg-danger' : 'bg-warning') ?>">
                  <?= ucfirst($appointment['status']) ?>
                </span>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <p class="text-muted text-center py-3">No appointments scheduled for today</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="row mt-4">
    <!-- Quick Actions -->
    <div class="col-md-4 mb-4">
      <div class="card text-center h-100">
        <div class="card-body">
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#667eea" class="bi bi-search-heart" viewBox="0 0 16 16">
              <path d="M6.5 4.482c1.664-1.673 5.825 1.254 0 5.018-5.825-3.764-1.664-6.69 0-5.018Z"/>
              <path d="M13 6.5a6.471 6.471 0 0 1-1.258 3.844c.04.03.078.062.115.098l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1.007 1.007 0 0 1-.1-.115h.002A6.5 6.5 0 1 1 13 6.5ZM6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11Z"/>
            </svg>
          </div>
          <h5>Patient Lookup</h5>
          <p class="text-muted">Find patient records and medical history</p>
          <a href="<?= BASE_URL ?>/records/search.php" class="btn btn-outline-primary">Search Patients</a>
        </div>
      </div>
    </div>
    
    <div class="col-md-4 mb-4">
      <div class="card text-center h-100">
        <div class="card-body">
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#667eea" class="bi bi-file-medical" viewBox="0 0 16 16">
              <path d="M8.5 4.5a.5.5 0 0 0-1 0v.634l-.549-.317a.5.5 0 1 0-.5.866L7 6l-.549.317a.5.5 0 1 0 .5.866l.549-.317V7.5a.5.5 0 1 0 1 0v-.634l.549.317a.5.5 0 1 0 .5-.866L9 6l.549-.317a.5.5 0 1 0-.5-.866l-.549.317V4.5zM5.5 9a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5zm0 2a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"/>
              <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1z"/>
            </svg>
          </div>
          <h5>New Consultation</h5>
          <p class="text-muted">Start a new patient consultation</p>
          <a href="<?= BASE_URL ?>/doctor/consultation.php" class="btn btn-outline-primary">Start Consultation</a>
        </div>
      </div>
    </div>
    
    <div class="col-md-4 mb-4">
      <div class="card text-center h-100">
        <div class="card-body">
          <div class="mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="#667eea" class="bi bi-prescription" viewBox="0 0 16 16">
              <path d="M5.5 6a.5.5 0 0 0-.5.5v4a.5.5 0 0 0 1 0V9h.5l1.5 3 1.5-3H12v1.5a.5.5 0 1 0 1 0v-4a.5.5 0 0 0-.5-.5h-7zm0 1h4.5L9 10.5 7.5 8.5 5.5 7z"/>
              <path d="M2 3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3zm1 0v10h10V3H3z"/>
            </svg>
          </div>
          <h5>Write Prescription</h5>
          <p class="text-muted">Create a new medication prescription</p>
          <a href="<?= BASE_URL ?>/doctor/prescription.php" class="btn btn-outline-primary">Create Prescription</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Search Section -->
  <div class="row mt-4">
    <div class="col-12">
      <div class="search-section">
        <h4 class="search-title">Find Patient</h4>
        <form method="get" action="<?= BASE_URL ?>/records/search.php" class="row g-3">
          <div class="col-md-8">
            <input type="text" name="q" class="form-control form-control-lg" placeholder="Enter Patient ID, Name, Phone Number, or Email">
          </div>
          <div class="col-md-4">
            <button type="submit" class="btn btn-primary btn-lg w-100">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search me-2" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
              Search Patient
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Consultation Status Chart
    const consultationCtx = document.getElementById('consultationChart').getContext('2d');
    new Chart(consultationCtx, {
      type: 'doughnut',
      data: {
        labels: [<?php foreach($consultation_stats as $stat): ?>'<?= ucfirst($stat['status']) ?>', <?php endforeach; ?>],
        datasets: [{
          data: [<?php foreach($consultation_stats as $stat): ?><?= $stat['count'] ?>, <?php endforeach; ?>],
          backgroundColor: [
            '#667eea', '#4facfe', '#1dd1a1', '#ff6b6b', '#ff9e7d'
          ],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
  });
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>