<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=doctor_files.csv');

$out=fopen('php://output','w');
fputcsv($out,['File ID','Patient','Status','Notes','Opened','Closed']);
$stmt=$pdo->prepare("SELECT v.id,CONCAT(p.first_name,' ',p.last_name) as patient,v.status,v.notes,v.opened_at,v.closed_at
                     FROM visits v JOIN patients p ON v.patient_id=p.id
                     WHERE v.doctor_id=?");
$stmt->execute([$_SESSION['user_id']]);
foreach($stmt as $row){
    fputcsv($out,$row);
}
fclose($out);
exit;
