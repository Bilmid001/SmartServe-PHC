<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=pharmacy_dispenses.csv');

$out=fopen('php://output','w');
fputcsv($out,['Dispense ID','Drug','Quantity','Dispensed By','Date']);
$stmt=$pdo->query("SELECT d.id,pr.drug_name,d.qty,u.full_name,d.created_at
                   FROM pharmacy_dispenses d
                   JOIN prescriptions pr ON d.prescription_id=pr.id
                   JOIN users u ON d.dispensed_by=u.id");
foreach($stmt as $row){
    fputcsv($out,$row);
}
fclose($out);
exit;
