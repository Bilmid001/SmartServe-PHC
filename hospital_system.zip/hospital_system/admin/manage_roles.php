<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';
if ($_SESSION['role']!=='admin'){ header('Location: '.BASE_URL.'/error/403.php'); exit; }

$err=''; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add'])){
    $name = trim($_POST['name']);
    if($name){
        $pdo->prepare("INSERT INTO roles (name) VALUES (?)")->execute([$name]);
        $msg='Role added.';
    } else $err='Role name needed.';
}
if(isset($_GET['delete'])){
    $pdo->prepare("DELETE FROM roles WHERE id=?")->execute([(int)$_GET['delete']]);
    $msg='Role deleted.';
}
$roles = $pdo->query("SELECT * FROM roles ORDER BY id DESC")->fetchAll();

$page_title='Manage Roles';
include __DIR__ . '/../includes/header.php';
?>
<h2>Manage Roles</h2>
<?php if($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>
<?php if($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<form method="post" class="mb-3"><div class="row"><div class="col-md-6"><input name="name" class="form-control" placeholder="Role name"></div><div class="col-md-2"><button name="add" class="btn btn-primary">Add</button></div></div></form>

<table class="table"><thead><tr><th>ID</th><th>Name</th><th>Action</th></tr></thead><tbody>
<?php foreach($roles as $r): ?>
<tr><td><?= $r['id'] ?></td><td><?= htmlspecialchars($r['name']) ?></td><td><a href="?delete=<?= $r['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete role?')">Delete</a></td></tr>
<?php endforeach; ?>
</tbody></table>

<?php include __DIR__ . '/../includes/footer.php'; ?>
