<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$role = $_SESSION['role'] ?? 'guest';
$page_title = $page_title ?? "Hospital System";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($page_title) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet"/>
<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap CSS -->




  <style>
    body { display: flex; min-height: 100vh; overflow-x: hidden; }
    .sidebar {
      min-width: 220px;
      max-width: 220px;
      background: #1d3557;
      color: #fff;
      flex-shrink: 0;
      display: flex;
      flex-direction: column;
      height: 100vh;
      position: fixed;
    }
    .sidebar h4 { padding: 1rem; margin: 0; background: #457b9d; }
    .sidebar a {
      color: #fff; padding: 0.75rem 1rem; display: block; text-decoration: none;
    }
    .sidebar a:hover, .sidebar a.active { background: #2a9d8f; }
    .content { margin-left: 220px; padding: 1rem; flex-grow: 1; }
    @media (max-width: 768px) {
      .sidebar { position: fixed; left: -220px; transition: left 0.3s; }
      .sidebar.active { left: 0; }
      .content { margin-left: 0; width: 100%; }
      .menu-toggle { display: block; margin: 1rem; }
    }
    .menu-toggle { display: none; }
  </style>
</head>
<body>
<div class="sidebar" id="sidebar">
  <h4>SMARTSERVE-AI</h4>

  <?php if ($role === 'admin'): ?>
    <a href="/hospital_system/admin/dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Admin Dashboard</a>
    <!-- <a href="/hospital_system/admin/ai_assistant.php"><i class="bi bi-people me-2"></i>Ai-Assistant</a> -->
    <!-- <a href="/hospital_system/aiphc.php"><i class="bi bi-people me-2"></i>Ai-Health Assistant</a> -->
    <a href="/hospital_system/admin/manage_users.php"><i class="bi bi-people me-2"></i>Manage Users</a>
    <a href="/hospital_system/admin/manage_roles.php"><i class="bi bi-person-gear me-2"></i>Manage Roles</a>
    <!-- <a href="/hospital_system/admin/users.php"><i class="bi bi-person-gear me-2"></i>User</a>
    <a href="/hospital_system/admin/delete_user.php"><i class="bi bi-person-gear me-2"></i>Delete User</a>
    <a href="/hospital_system/admin/edit_user.php"><i class="bi bi-person-gear me-2"></i>Edit User</a> -->
    <a href="/hospital_system/admin/audit_logs.php"><i class="bi bi-clipboard-data me-2"></i>Audit Logs</a>
    <a href="/hospital_system/admin/reports.php"><i class="bi bi-bar-chart-line me-2"></i>Reports</a>
    <a href="/hospital_system/admin/settings.php"><i class="bi bi-gear me-2"></i>Settings</a>

  <?php elseif ($role === 'records'): ?>
    <a href="/hospital_system/records/dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Records Dashboard</a>
    <a href="/hospital_system/records/add_patient.php"><i class="bi bi-person-plus me-2"></i>Register Patient</a>
    <a href="/hospital_system/records/open_file.php"><i class="bi bi-folder-plus me-2"></i>Open File</a>
    <a href="/hospital_system/records/Close_file.php"><i class="bi bi-card-list me-2"></i>Close File</a>
    <a href="/hospital_system/records/manage_patients.php"><i class="bi bi-person-lines-fill me-2"></i>Manage Patients</a>
    <a href="/hospital_system/records/reports.php"><i class="bi bi-bar-chart-line me-2"></i>Reports</a>
    <a href="/hospital_system/records/profile.php"><i class="bi bi-person-circle me-2"></i>Profile</a>

  <?php elseif ($role === 'doctor'): ?>
    <a href="/hospital_system/doctor/dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Doctor Dashboard</a>
    <a href="/hospital_system/doctor/add_consultation.php"><i class="bi bi-card-list me-2"></i>Add Consultation</a>
    <a href="/hospital_system/doctor/assigned_files.php"><i class="bi bi-folder-check me-2"></i>Assigned Files</a>
    <!-- <a href="/hospital_system/doctor/edit_consultation.php"><i class="bi bi-card-list me-2"></i>Edit Consultation</a>
    <a href="/hospital_system/doctor/patient_history.php"><i class="bi bi-card-list me-2"></i>Patient History</a> -->
    <a href="/hospital_system/doctor/patient_list.php"><i class="bi bi-card-list me-2"></i>Patient List</a>
    <a href="/hospital_system/doctor/profile.php"><i class="bi bi-bar-chart-line me-2"></i>Profile</a>
    <a href="/hospital_system/doctor/reports.php"><i class="bi bi-bar-chart-line me-2"></i>Reports</a>
    <a href="/hospital_system/doctor/requests.php"><i class="bi bi-bar-chart-line me-2"></i>Requests</a>
    <a href="/hospital_system/doctor/review_file.php"><i class="bi bi-file-earmark-text me-2"></i>Review Files</a>
    
  <?php elseif ($role === 'lab'): ?>
    <a href="/hospital_system/lab/dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Lab Dashboard</a>
    <a href="/hospital_system/lab/add_result.php"><i class="bi bi-flask me-2"></i>Add Result</a>
    <a href="/hospital_system/lab/edit_result.php"><i class="bi bi-pencil-square me-2"></i>Edit Result</a>
    <a href="/hospital_system/lab/patient_history.php"><i class="bi bi-clock-history me-2"></i>Patient History</a>
    <a href="/hospital_system/lab/requested.php"><i class="bi bi-file-earmark-medical me-2"></i>Test Requests</a>
    <a href="/hospital_system/lab/test_catalog.php"><i class="bi bi-journal-text me-2"></i>Test Catalog</a>
    <a href="/hospital_system/lab/reports.php"><i class="bi bi-bar-chart-line me-2"></i>Reports</a>

  <?php elseif ($role === 'pharmacy'): ?>
    <a href="/hospital_system/pharmacy/dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Pharmacy Dashboard</a>
    <!-- <a href="/hospital_system/pharmacy/prescriptions.php"><i class="bi bi-capsule me-2"></i>Prescriptions</a> -->
    <a href="/hospital_system/pharmacy/add_prescription.php"><i class="bi bi-capsule me-2"></i>Add Prescription</a>
    <!-- <a href="/hospital_system/pharmacy/edit_prescription.php"><i class="bi bi-capsule me-2"></i>Edit Prescription</a> -->
    <a href="/hospital_system/pharmacy/dispense.php"><i class="bi bi-truck me-2"></i>Dispense</a>
    <a href="/hospital_system/pharmacy/history.php"><i class="bi bi-truck me-2"></i>History</a>
    <a href="/hospital_system/pharmacy/manage_stock.php"><i class="bi bi-box-seam me-2"></i>Manage Stock</a>
    <a href="/hospital_system/pharmacy/patient_history.php"><i class="bi bi-box-seam me-2"></i>Patient History</a>
    <a href="/hospital_system/pharmacy/reports.php"><i class="bi bi-bar-chart-line me-2"></i>Reports</a>

  <?php elseif ($role === 'environment'): ?>
    <a href="/hospital_system/environment/dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Environment Dashboard</a>
    <a href="/hospital_system/environment/add_case.php"><i class="bi bi-shield-plus me-2"></i>Add Cases</a>
    <a href="/hospital_system/environment/add_immunization.php"><i class="bi bi-shield-plus me-2"></i>Add Immunizations</a>
    <a href="/hospital_system/environment/cases_list.php"><i class="bi bi-shield-plus me-2"></i>Cases List</a>
    <a href="/hospital_system/environment/immunization_history.php"><i class="bi bi-shield-plus me-2"></i>Immunizations History</a>
    <a href="/hospital_system/environment/immunization_reports.php"><i class="bi bi-shield-plus me-2"></i>Immunization Report</a>
    <a href="/hospital_system/environment/immunization_requests.php"><i class="bi bi-shield-plus me-2"></i>Immun Requests</a>
    <!-- <a href="/hospital_system/environment/immunization.php"><i class="bi bi-shield-plus me-2"></i>Immunization</a> -->
    <!-- <a href="/hospital_system/environment/log_case.php"><i class="bi bi-pencil-square me-2"></i>Log Case</a> -->
    <!-- <a href="/hospital_system/environment/patient_history.php"><i class="bi bi-pencil-square me-2"></i>Patient History</a> -->
    <a href="/hospital_system/environment/community_reports.php"><i class="bi bi-shield-plus me-2"></i>Community Reports</a>
  <?php else: ?>
    <a href="/hospital_system/index.php"><i class="bi bi-house-door me-2"></i>Home</a>
    <a href="/hospital_system/auth/login.php"><i class="bi bi-box-arrow-in-right me-2"></i>Login</a>
  <?php endif; ?>

  <?php if ($role !== 'guest'): ?>
    <a href="/hospital_system/auth/logout.php" class="text-danger"><i class="bi bi-box-arrow-right me-2"></i>Logout</a>
  <?php endif; ?>
</div>

<div class="content">
  <button class="btn btn-secondary menu-toggle" onclick="toggleSidebar()">☰ Menu</button>
  <script>
    function toggleSidebar(){ document.getElementById('sidebar').classList.toggle('active'); }
  </script>

<!-- Bootstrap JS (with Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
