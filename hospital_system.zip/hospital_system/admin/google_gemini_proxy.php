<?php
header("Content-Type: application/json");

// Set your API key securely (never expose it on frontend)
$api_key = "AIzaSyDtGNYrAE8Xs6rWlG6aYPQ97yBLUL9q7R0"; // Replace this

if (!$api_key) {
    echo json_encode(["error" => "API key not set"]);
    exit;
}

$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['query']) || trim($input['query']) === '') {
    http_response_code(400);
    echo json_encode(["error" => "Missing query"]);
    exit;
}

$query = trim($input['query']);

// Google Gemini Pro API endpoint
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" . urlencode($api_key);

$payload = [
    "contents" => [
        [
            "parts" => [
                ["text" => $query]
            ]
        ]
    ]
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
    CURLOPT_POSTFIELDS => json_encode($payload)
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    $error_message = curl_error($ch);
    curl_close($ch);
    echo json_encode(["error" => "cURL error: $error_message"]);
    exit;
}
curl_close($ch);

$data = json_decode($response, true);

// Debug log (optional - comment out in production)
file_put_contents(__DIR__ . '/gemini_debug.log', json_encode([
    'query' => $query,
    'http_code' => $http_code,
    'response' => $data
], JSON_PRETTY_PRINT), FILE_APPEND);

if ($http_code !== 200 || !isset($data['candidates'][0]['content']['parts'][0]['text'])) {
    echo json_encode([
        "error" => "Invalid API response",
        "status" => $http_code,
        "raw" => $data
    ]);
    exit;
}

echo json_encode([
    "result" => $data['candidates'][0]['content']['parts'][0]['text']
]);
?>
