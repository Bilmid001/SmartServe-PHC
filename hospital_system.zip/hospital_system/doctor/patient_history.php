<?php
// doctor/patient_history.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$pid = $_GET['id'] ?? 0;

// Fetch patient info
$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = :id");
$stmt->execute([':id' => $pid]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    die("❌ Patient not found");
}

// Fetch consultations
$stmt = $pdo->prepare("
    SELECT * 
    FROM consultations 
    WHERE patient_id = :pid
    ORDER BY created_at DESC
");
$stmt->execute([':pid' => $pid]);
$consultations = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Consultation History";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-4">Consultation History - <?= htmlspecialchars($patient['fullname']) ?></h2>

  <?php if ($consultations): ?>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Date</th>
          <th>Reason</th>
          <th>Diagnosis</th>
          <th>Treatment</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($consultations as $c): ?>
          <tr>
            <td><?= htmlspecialchars($c['created_at']) ?></td>
            <td><?= htmlspecialchars($c['notes']) ?></td>
            <td><?= htmlspecialchars($c['diagnosis']) ?></td>
            <td><?= htmlspecialchars($c['treatment']) ?></td>
            <td>
              <?php if ($c['status'] === 'completed'): ?>
                <span class="badge bg-success">Completed</span>
              <?php else: ?>
                <span class="badge bg-warning">Pending</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="alert alert-info">No consultations found for this patient.</div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
