<?php
// doctor/requests.php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$stmt = $pdo->query("
    SELECT c.*, p.fullname, p.phone, p.gender, p.dob
    FROM consultations c
    JOIN patients p ON c.patient_id = p.id
    WHERE c.status = 'pending'
    ORDER BY c.created_at DESC
");
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Pending Consultations";
include __DIR__ . '/../includes/header.php';
?>
<div class="container">
  <h2 class="mb-4">Pending Consultations</h2>
  <?php if ($requests): ?>
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Patient</th>
          <th>Phone</th>
          <th>Gender</th>
          <th>DOB</th>
          <th>Reason / Notes</th>
          <th>Date Requested</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($requests as $r): ?>
          <tr>
            <td><?= htmlspecialchars($r['fullname']) ?></td>
            <td><?= htmlspecialchars($r['phone']) ?></td>
            <td><?= htmlspecialchars($r['gender']) ?></td>
            <td><?= htmlspecialchars($r['dob']) ?></td>
            <td><?= htmlspecialchars($r['notes']) ?></td>
            <td><?= htmlspecialchars($r['created_at']) ?></td>
            <td>
              <a href="edit_consultation.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-primary">Review</a>
              <a href="patient_history.php?id=<?= $r['patient_id'] ?>" class="btn btn-sm btn-info">History</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="alert alert-info">No pending consultations found.</div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
