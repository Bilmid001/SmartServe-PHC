<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $pdo->prepare("UPDATE patients SET status='closed', updated_at=NOW() WHERE id=?");
    $stmt->execute([$id]);
}

header("Location: dashboard.php");
exit;
