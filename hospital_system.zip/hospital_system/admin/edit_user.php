<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    die("User not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $role = $_POST['role'];
    $password = $_POST['password'];

    if ($password) {
        $password = password_hash($password, PASSWORD_BCRYPT);
        $update = $pdo->prepare("UPDATE users SET username=?, role=?, password=? WHERE id=?");
        $ok = $update->execute([$username, $role, $password, $id]);
    } else {
        $update = $pdo->prepare("UPDATE users SET username=?, role=? WHERE id=?");
        $ok = $update->execute([$username, $role, $id]);
    }

    if ($ok) {
        header("Location: users.php");
        exit;
    } else {
        $error = "Error updating user.";
    }
}
?>

<div class="container">
  <h2 class="mb-4">Edit User</h2>
  <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
  <form method="post">
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">New Password (leave blank to keep current)</label>
      <input type="password" name="password" class="form-control">
    </div>
    <div class="mb-3">
      <label class="form-label">Role</label>
      <select name="role" class="form-select" required>
        <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
        <option value="doctor" <?= $user['role']=='doctor'?'selected':'' ?>>Doctor</option>
        <option value="lab" <?= $user['role']=='lab'?'selected':'' ?>>Lab</option>
        <option value="pharmacy" <?= $user['role']=='pharmacy'?'selected':'' ?>>Pharmacy</option>
        <option value="immunization" <?= $user['role']=='immunization'?'selected':'' ?>>Immunization</option>
        <option value="environmental" <?= $user['role']=='environmental'?'selected':'' ?>>Environmental</option>
        <option value="records" <?= $user['role']=='records'?'selected':'' ?>>Records</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary">Update User</button>
    <a href="users.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>
